import React, { useState } from 'react';
import { 
  Database, 
  CheckCircle2, 
  AlertCircle, 
  Copy, 
  ExternalLink, 
  Clipboard, 
  RefreshCw, 
  Zap, 
  Eye, 
  EyeOff, 
  Server, 
  Code, 
  ShieldCheck,
  ArrowRight,
  Terminal
} from 'lucide-react';
import { 
  DEFAULT_SUPABASE_URL, 
  DEFAULT_SUPABASE_ANON_KEY, 
  getSavedCredentials, 
  getCurrentSupabaseConfig, 
  testSupabaseConnection, 
  applySupabaseCredentialsGlobally 
} from '../lib/supabase';
import { useStore } from '../store';
import { RECOMMENDED_SUPABASE_SQL } from '../components/SupabaseConnectModal';

export default function SupabaseSetup() {
  const { addToast, updatePlatformSettings } = useStore();
  const saved = getSavedCredentials();
  
  const [url, setUrl] = useState(saved.url);
  const [anonKey, setAnonKey] = useState(saved.anonKey);
  const [showKey, setShowKey] = useState(false);
  
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{
    tested: boolean;
    success: boolean;
    latencyMs: number;
    message: string;
    projectRef?: string;
  } | null>(null);

  const [isApplying, setIsApplying] = useState(false);
  const [appliedSuccess, setAppliedSuccess] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedEnv, setCopiedEnv] = useState(false);

  const currentConfig = getCurrentSupabaseConfig();

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const result = await testSupabaseConnection(url, anonKey);
      setTestResult({
        tested: true,
        success: result.success,
        latencyMs: result.latencyMs,
        message: result.message,
        projectRef: result.projectRef
      });
      if (result.success) {
        addToast(`Supabase reachable! Latency: ${result.latencyMs}ms`, 'success', 'Connection Verified');
      } else {
        addToast(result.message, 'error', 'Connection Test Failed');
      }
    } catch (err: any) {
      setTestResult({
        tested: true,
        success: false,
        latencyMs: 0,
        message: err?.message || 'Failed to ping Supabase endpoint'
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handlePasteUrl = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setUrl(text.trim());
        addToast('Pasted Supabase Project URL', 'info', 'Clipboard');
      }
    } catch {
      addToast('Please paste manually using Ctrl+V or right-click', 'info');
    }
  };

  const handlePasteKey = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setAnonKey(text.trim());
        addToast('Pasted Supabase Anon Key', 'info', 'Clipboard');
      }
    } catch {
      addToast('Please paste manually using Ctrl+V or right-click', 'info');
    }
  };

  const handleApplyGlobally = () => {
    if (!url.trim() || !anonKey.trim()) {
      addToast('Please provide both Supabase Project URL and Anon Key', 'error', 'Missing Credentials');
      return;
    }

    setIsApplying(true);
    try {
      applySupabaseCredentialsGlobally(url, anonKey);
      updatePlatformSettings({
        supabase_url: url.trim(),
        supabase_anon_key: anonKey.trim()
      });

      setAppliedSuccess(true);
      addToast('Supabase credentials successfully connected globally to your website!', 'success', 'Globally Connected');
      setTimeout(() => {
        setIsApplying(false);
      }, 500);
    } catch (err: any) {
      setIsApplying(false);
      addToast(err?.message || 'Failed to apply credentials', 'error', 'Configuration Error');
    }
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(RECOMMENDED_SUPABASE_SQL);
    setCopiedCode(true);
    addToast('SQL schema copied to clipboard! Paste in Supabase SQL Editor.', 'success', 'Copied');
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const envSnippet = `VITE_SUPABASE_URL="${url.trim()}"\nVITE_SUPABASE_ANON_KEY="${anonKey.trim()}"`;

  return (
    <div className="max-w-5xl mx-auto py-8 px-4 space-y-8 animate-in fade-in duration-300">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-cyan-800 rounded-3xl p-6 sm:p-10 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center space-x-2 bg-white/15 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider text-emerald-200">
            <Database className="w-3.5 h-3.5" />
            <span>Global Database Integration</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-black tracking-tight">
            Connect Your Supabase Project
          </h1>
          <p className="text-white/80 text-sm sm:text-base leading-relaxed">
            Paste your Supabase credentials to link and sync your entire Mega Marketplace globally. This configures live authentication, product databases, orders, and real-time vendor updates.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <div className="bg-black/25 backdrop-blur-xs rounded-xl px-4 py-2 border border-white/10 flex items-center space-x-2.5">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-300"></span>
              </span>
              <span className="text-xs font-semibold">
                Status: <strong className="text-emerald-300 font-mono">{currentConfig.projectRef}</strong> (Connected)
              </span>
            </div>

            <a 
              href="https://supabase.com/dashboard" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1.5 text-xs font-bold bg-white text-emerald-900 hover:bg-emerald-50 px-4 py-2 rounded-xl shadow-xs transition-colors"
            >
              <span>Open Supabase Dashboard</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Ambient background decoration */}
        <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-white/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Form: Paste & Apply */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-black text-slate-900 flex items-center space-x-2">
              <Server className="w-5 h-5 text-emerald-600" />
              <span>Paste Supabase Credentials</span>
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Enter your project URL and anonymous API key to bind the marketplace client globally.
            </p>
          </div>

          {/* Project URL */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-extrabold text-slate-700 uppercase tracking-wider flex items-center space-x-1">
                <span>Supabase Project URL</span>
                <span className="text-rose-500">*</span>
              </label>
              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={handlePasteUrl}
                  className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center space-x-1 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 transition-colors"
                >
                  <Clipboard className="w-3 h-3" />
                  <span>Paste URL</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setUrl(DEFAULT_SUPABASE_URL);
                    setAnonKey(DEFAULT_SUPABASE_ANON_KEY);
                    addToast('Restored provided Supabase credentials', 'info');
                  }}
                  className="text-xs text-slate-400 hover:text-slate-600 underline"
                >
                  Reset Default
                </button>
              </div>
            </div>
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://ugkvfehugcakdqbikdyx.supabase.co"
              className="w-full text-xs font-mono px-4 py-3 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
            />
            <p className="text-[11px] text-slate-500">
              Your Supabase base URL, formatted as <code>https://[project-id].supabase.co</code>
            </p>
          </div>

          {/* Anon Key */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-extrabold text-slate-700 uppercase tracking-wider flex items-center space-x-1">
                <span>Supabase Anon / Public Key</span>
                <span className="text-rose-500">*</span>
              </label>
              <button
                type="button"
                onClick={handlePasteKey}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center space-x-1 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 transition-colors"
              >
                <Clipboard className="w-3 h-3" />
                <span>Paste Key</span>
              </button>
            </div>
            <div className="relative">
              <textarea
                rows={3}
                value={anonKey}
                onChange={(e) => setAnonKey(e.target.value)}
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                className={`w-full text-xs font-mono px-4 py-3 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all pr-10 ${
                  !showKey ? 'filter blur-[1.5px] hover:blur-none transition-all' : ''
                }`}
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                title={showKey ? 'Hide key' : 'Show key'}
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[11px] text-slate-500">
              The public safe-to-expose anonymous client key provided in Supabase API settings.
            </p>
          </div>

          {/* Test results banner */}
          {testResult && (
            <div
              className={`rounded-2xl p-4 border text-xs flex items-start space-x-3 animate-in fade-in duration-200 ${
                testResult.success 
                  ? 'bg-emerald-50/90 border-emerald-300 text-emerald-950' 
                  : 'bg-rose-50/90 border-rose-300 text-rose-950'
              }`}
            >
              {testResult.success ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              )}
              <div className="space-y-1">
                <div className="font-bold flex items-center space-x-2">
                  <span>{testResult.success ? 'Supabase Connection Live' : 'Connection Failed'}</span>
                  {testResult.latencyMs > 0 && (
                    <span className="bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded-full text-[10px] font-mono">
                      {testResult.latencyMs}ms response time
                    </span>
                  )}
                </div>
                <p className="opacity-90">{testResult.message}</p>
              </div>
            </div>
          )}

          {appliedSuccess && (
            <div className="bg-emerald-600 text-white rounded-2xl p-4 text-xs flex items-center space-x-3 shadow-md">
              <CheckCircle2 className="w-5 h-5 text-white shrink-0" />
              <div>
                <strong className="block font-bold">Successfully Connected Globally!</strong>
                <span>All requests and marketplace features are synchronized with this Supabase database.</span>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isTesting || !url.trim() || !anonKey.trim()}
              className="w-full sm:w-auto px-5 py-3 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-bold flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isTesting ? 'animate-spin' : ''}`} />
              <span>{isTesting ? 'Testing Latency...' : 'Test Connection Latency'}</span>
            </button>

            <button
              type="button"
              onClick={handleApplyGlobally}
              disabled={isApplying || !url.trim() || !anonKey.trim()}
              className="w-full sm:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-black shadow-lg shadow-emerald-600/25 flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
            >
              <Zap className="w-4 h-4 text-emerald-200" />
              <span>{isApplying ? 'Applying Globally...' : 'Apply & Connect Globally'}</span>
            </button>
          </div>
        </div>

        {/* Right Column: Step-by-step & Schema */}
        <div className="space-y-6">
          {/* Quick Steps Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-sm font-black text-slate-900 flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>3-Step Quick Setup</span>
            </h3>
            <ol className="space-y-3 text-xs text-slate-600">
              <li className="flex items-start space-x-2.5">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 font-black flex items-center justify-center text-[10px] shrink-0 mt-0.5">1</span>
                <span>Open your Supabase Project at <strong>supabase.com</strong>.</span>
              </li>
              <li className="flex items-start space-x-2.5">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 font-black flex items-center justify-center text-[10px] shrink-0 mt-0.5">2</span>
                <span>Navigate to <strong>Project Settings → API</strong>. Copy URL & anon key.</span>
              </li>
              <li className="flex items-start space-x-2.5">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 font-black flex items-center justify-center text-[10px] shrink-0 mt-0.5">3</span>
                <span>Paste here and click <strong>"Apply & Connect Globally"</strong>.</span>
              </li>
            </ol>
          </div>

          {/* SQL Tables Script Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-slate-900 flex items-center space-x-2">
                <Code className="w-4 h-4 text-emerald-600" />
                <span>Supabase SQL Tables</span>
              </h3>
              <button
                onClick={handleCopySql}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center space-x-1"
              >
                {copiedCode ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCode ? 'Copied!' : 'Copy SQL'}</span>
              </button>
            </div>
            <p className="text-xs text-slate-500">
              Need tables for products, vendors, and orders? Run this script in your Supabase SQL editor.
            </p>
            <div className="bg-slate-950 rounded-xl p-3 max-h-48 overflow-y-auto border border-slate-800">
              <pre className="text-[10px] font-mono text-emerald-400">
                {RECOMMENDED_SUPABASE_SQL.slice(0, 450)}...
              </pre>
            </div>
          </div>

          {/* .env Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-slate-900 flex items-center space-x-2">
                <Terminal className="w-4 h-4 text-emerald-600" />
                <span>.env Format</span>
              </h3>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(envSnippet);
                  setCopiedEnv(true);
                  addToast('Copied .env values to clipboard', 'success');
                  setTimeout(() => setCopiedEnv(false), 2000);
                }}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center space-x-1"
              >
                {copiedEnv ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedEnv ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>
            <div className="bg-slate-950 rounded-xl p-3 border border-slate-800">
              <pre className="text-[11px] font-mono text-emerald-400 whitespace-pre-wrap break-all">
                {envSnippet}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
