import React, { useState } from 'react';
import { useStore } from '../store';
import { 
  Briefcase, 
  Users, 
  ShieldCheck, 
  CheckCircle2, 
  Send, 
  Wifi, 
  Laptop, 
  Clock, 
  Sparkles, 
  AlertCircle,
  ArrowRight,
  MessageSquare,
  Lock
} from 'lucide-react';
import { Link } from 'react-router-dom';

export default function JoinTeam() {
  const { teamApplications, submitTeamApplication } = useStore();

  const acceptedCount = teamApplications.filter(a => a.status === 'accepted').length;
  const isCapReached = acceptedCount >= 7;

  const [applicantName, setApplicantName] = useState('');
  const [email, setEmail] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [desiredRole, setDesiredRole] = useState<'bookkeeper' | 'money_checker' | 'ad_manager' | 'customer_support' | 'sales_agent'>('bookkeeper');
  const [experienceSummary, setExperienceSummary] = useState('');
  const [remoteReadiness, setRemoteReadiness] = useState('');
  const [portfolioUrl, setPortfolioUrl] = useState('');
  const [submittedSuccess, setSubmittedSuccess] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');

    if (!applicantName.trim() || !email.trim() || !whatsapp.trim() || !experienceSummary.trim()) {
      setSubmitError('Please fill in all mandatory application fields.');
      return;
    }

    const res = submitTeamApplication({
      applicant_name: applicantName.trim(),
      email: email.trim(),
      whatsapp: whatsapp.trim(),
      desired_role: desiredRole,
      experience_summary: experienceSummary.trim(),
      remote_readiness: remoteReadiness.trim() || 'Equipped with workstation, internet and backup power.',
      portfolio_url: portfolioUrl.trim() || undefined
    });

    if (res.success) {
      setSubmittedSuccess(true);
    } else {
      setSubmitError(res.message);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 space-y-8">
      {/* Top Banner / Hero */}
      <div className="bg-gradient-to-tr from-slate-950 via-slate-900 to-blue-950 text-white rounded-3xl p-8 sm:p-10 border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-4 max-w-2xl">
          <div className="inline-flex items-center space-x-2 bg-blue-500/20 border border-blue-400/30 px-3 py-1 rounded-full text-blue-300 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Mega Remote Operations Fellowship</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight">
            Join Our Executive Remote Team
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            We are hiring certified, high-standard remote specialists to oversee book keeping, payment verifications, customer communications, and automated video advertising.
          </p>

          {/* Strict 7 Applicants Cap Indicator */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <div className="bg-slate-900/90 border border-slate-700/80 px-4 py-2.5 rounded-2xl flex items-center space-x-3">
              <Users className="w-5 h-5 text-emerald-400" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-black block tracking-wider">
                  Community Quota Limit
                </span>
                <span className="text-sm font-black text-white">
                  {acceptedCount} of 7 Maximum Slots Filled
                </span>
              </div>
            </div>

            <div className="bg-blue-900/40 border border-blue-700/50 px-4 py-2.5 rounded-2xl flex items-center space-x-2 text-xs font-bold text-blue-200">
              <Lock className="w-4 h-4 text-amber-400" />
              <span>Dedicated Role PIN Access Dashboard</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3 Core Responsibilities Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-2">
          <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
            01
          </div>
          <h3 className="font-black text-sm text-slate-900">Chief Bookkeeper (/@admin)</h3>
          <p className="text-xs text-slate-500">
            Audit seller ledgers, inventory transactions, reconcile platform records, and generate financial reports.
          </p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-2">
          <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            02
          </div>
          <h3 className="font-black text-sm text-slate-900">Payment Checker (/$admin)</h3>
          <p className="text-xs text-slate-500">
            Verify customer bank transfers, approve seller payout deductions (₦50 fee tracking), and monitor wallet deposits.
          </p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-2">
          <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
            03
          </div>
          <h3 className="font-black text-sm text-slate-900">Ad & Broadcast Manager (/%admin)</h3>
          <p className="text-xs text-slate-500">
            Operate the Video Lab ad studio, automate scheduled client commercial posts, and maintain flowing ticker news.
          </p>
        </div>
      </div>

      {/* Application Form or Success State */}
      <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-sm space-y-6">
        {submittedSuccess ? (
          <div className="py-12 text-center max-w-md mx-auto space-y-4 animate-in fade-in zoom-in-95">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto shadow-md">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">
              Application Successfully Dispatched!
            </h2>
            <p className="text-xs text-slate-500 leading-relaxed">
              The Super Admin has received your submission. Upon evaluation, you will receive an acceptance message directly to your WhatsApp (<strong className="text-slate-800">{whatsapp}</strong>) or email with your generated security PIN to unlock your dedicated panel.
            </p>
            <div className="pt-4 flex justify-center">
              <Link
                to="/"
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-3 rounded-2xl text-xs transition"
              >
                Return to Homepage
              </Link>
            </div>
          </div>
        ) : isCapReached ? (
          <div className="py-12 text-center max-w-md mx-auto space-y-4">
            <div className="w-14 h-14 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mx-auto">
              <AlertCircle className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-black text-slate-900">Remote Fellowship Cap Reached</h3>
            <p className="text-xs text-slate-500">
              All 7 remote positions for this phase have been accepted. Please monitor announcements on the flowing ticker for future openings.
            </p>
            <Link to="/" className="inline-block bg-slate-900 text-white px-5 py-2.5 rounded-xl text-xs font-bold">
              Explore Marketplace
            </Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="border-b border-slate-100 pb-4">
              <h2 className="text-lg font-black text-slate-900">Standard Remote Candidate Profile</h2>
              <p className="text-xs text-slate-500">
                Please provide accurate information. Submissions with verified WhatsApp and email are reviewed within 4 hours.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Full Legal Name *</label>
                <input
                  type="text"
                  required
                  value={applicantName}
                  onChange={(e) => setApplicantName(e.target.value)}
                  placeholder="e.g. Samuel Adekunle"
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Official Email Address *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="samuel@example.com"
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Active WhatsApp Phone Number *</label>
                <input
                  type="tel"
                  required
                  value={whatsapp}
                  onChange={(e) => setWhatsapp(e.target.value)}
                  placeholder="+234 812 345 6789"
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-medium"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Admin will message you on this WhatsApp with your access PIN.
                </span>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Target Role Applied For *</label>
                <select
                  value={desiredRole}
                  onChange={(e) => setDesiredRole(e.target.value as any)}
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-bold"
                >
                  <option value="bookkeeper">Chief Bookkeeper (/@admin)</option>
                  <option value="money_checker">Payment / Money Checker (/$admin)</option>
                  <option value="ad_manager">Ad & Broadcast Manager (/%admin)</option>
                  <option value="customer_support">Customer Concierge & WhatsApp Messenger</option>
                  <option value="sales_agent">Field Sales & Merchant Onboarding Agent</option>
                </select>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Experience & Competency Summary *</label>
                <textarea
                  rows={3}
                  required
                  value={experienceSummary}
                  onChange={(e) => setExperienceSummary(e.target.value)}
                  placeholder="Summarize your experience handling accounts, fintech transfers, social advertising or client management..."
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-medium"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Remote Equipment & Power Setup</label>
                  <input
                    type="text"
                    value={remoteReadiness}
                    onChange={(e) => setRemoteReadiness(e.target.value)}
                    placeholder="e.g. Core i7 Laptop, fiber Wi-Fi + 1KVA solar inverter backup"
                    className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Portfolio / LinkedIn / CV Link</label>
                  <input
                    type="url"
                    value={portfolioUrl}
                    onChange={(e) => setPortfolioUrl(e.target.value)}
                    placeholder="https://linkedin.com/in/yourprofile"
                    className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-medium"
                  />
                </div>
              </div>
            </div>

            {submitError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{submitError}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-2xl text-xs sm:text-sm shadow-lg shadow-blue-600/30 active:scale-95 transition-all flex items-center justify-center space-x-2"
            >
              <Send className="w-4 h-4" />
              <span>Submit Application to Super Admin Panel</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
