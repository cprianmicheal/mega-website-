import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api';
import { Product } from '../types';
import { formatCurrency } from '../lib/utils';
import { useStore } from '../store';
import { 
  Star, 
  Store, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Heart, 
  Share2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  Check,
  MapPin,
  Sparkles,
  ExternalLink,
  MessageSquare
} from 'lucide-react';

export default function ProductDetails() {
  const { slug } = useParams<{ slug: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'desc' | 'specs' | 'reviews'>('desc');
  const [addedToast, setAddedToast] = useState(false);

  const { addToCart, wishlist, toggleWishlist, addJobInquiry, user, addToast, platformSettings } = useStore();
  const [showJobModal, setShowJobModal] = useState(false);
  const [jobApplicantName, setJobApplicantName] = useState(user?.full_name || '');
  const [jobApplicantPhone, setJobApplicantPhone] = useState(user?.phone || '');
  const [jobApplicantEmail, setJobApplicantEmail] = useState(user?.email || '');
  const [jobResumeNotes, setJobResumeNotes] = useState('');
  const [jobPortfolioUrl, setJobPortfolioUrl] = useState('');
  const [jobSent, setJobSent] = useState(false);

  useEffect(() => {
    async function loadProduct() {
      if (!slug) return;
      try {
        setLoading(true);
        const data = await api.products.getBySlug(slug);
        setProduct(data);
      } catch (err) {
        console.error('Failed to load product', err);
      } finally {
        setLoading(false);
      }
    }
    loadProduct();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 text-center">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Product Not Found</h2>
        <p className="text-slate-500 mb-6 text-sm">The item you are looking for might have been sold out or unlisted.</p>
        <Link to="/explore" className="bg-blue-600 text-white font-bold px-6 py-3 rounded-xl text-sm">
          Browse All Products
        </Link>
      </div>
    );
  }

  const isBookmarked = wishlist.some(item => item.id === product.id);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2500);
  };

  const discountPercent = product.discount_price
    ? Math.round(((product.price - product.discount_price) / product.price) * 100)
    : null;

  return (
    <div className="px-4 py-6 md:py-10 max-w-7xl mx-auto">
      {/* Toast */}
      {addedToast && (
        <div className="fixed top-20 right-4 z-50 bg-blue-600 text-white px-5 py-3 rounded-2xl shadow-xl flex items-center space-x-2 text-xs sm:text-sm font-bold animate-in slide-in-from-top">
          <Check className="w-4 h-4" />
          <span>Added {quantity} unit(s) of {product.title} to your cart!</span>
        </div>
      )}

      {/* Breadcrumb */}
      <nav className="flex items-center space-x-2 text-xs font-semibold text-slate-500 mb-6">
        <Link to="/" className="hover:text-blue-600">Home</Link>
        <span>/</span>
        <Link to="/explore" className="hover:text-blue-600">Marketplace</Link>
        <span>/</span>
        <span className="text-slate-900 line-clamp-1">{product.title}</span>
      </nav>

      {/* Product Primary Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
        {/* Left: Gallery (5 cols) */}
        <div className="lg:col-span-6 space-y-4">
          {/* Product Video Preview if available */}
          {product.video_url && (
            <div className="rounded-3xl overflow-hidden bg-slate-950 border border-slate-800 shadow-md p-2">
              <div className="flex items-center space-x-2 px-3 py-2 text-xs font-bold text-slate-300">
                <span>📹 Verified Product Video Demonstration</span>
              </div>
              {product.video_url.includes('youtube.com') || product.video_url.includes('youtu.be') || product.video_url.includes('vimeo.com') ? (
                <iframe
                  src={product.video_url.replace('watch?v=', 'embed/').replace('youtu.be/', 'youtube.com/embed/')}
                  className="w-full h-64 sm:h-80 rounded-2xl"
                  title="Product Video"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <video
                  src={product.video_url}
                  controls
                  autoPlay
                  muted
                  loop
                  className="w-full h-64 sm:h-80 object-cover rounded-2xl"
                />
              )}
            </div>
          )}

          <div className="aspect-square rounded-3xl overflow-hidden bg-white border border-slate-200 relative shadow-sm">
            <img
              src={product.images[selectedImage] || product.images[0]}
              alt={product.title}
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800';
              }}
              className="w-full h-full object-cover"
            />
            {discountPercent && (
              <span className="absolute top-4 left-4 bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-md">
                -{discountPercent}% OFF
              </span>
            )}
            <button
              onClick={() => toggleWishlist(product)}
              className={`absolute top-4 right-4 w-10 h-10 rounded-full flex items-center justify-center transition-all shadow-md ${
                isBookmarked ? 'bg-rose-50 text-rose-600' : 'bg-white/90 text-slate-400 hover:text-rose-500'
              }`}
            >
              <Heart className={`w-5 h-5 ${isBookmarked ? 'fill-rose-600' : ''}`} />
            </button>
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex space-x-3 overflow-x-auto pb-2">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(idx)}
                  className={`w-20 h-20 rounded-2xl overflow-hidden border-2 transition-all shrink-0 bg-white ${
                    selectedImage === idx ? 'border-blue-600 shadow-md' : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Product Details & Buying Controls (7 cols) */}
        <div className="lg:col-span-6 flex flex-col justify-between">
          <div className="space-y-4">
            {/* Store & Category */}
            <div className="flex items-center space-x-2 text-xs font-semibold text-slate-500">
              <span className="px-2.5 py-1 bg-blue-50 text-blue-700 rounded-lg">
                {product.category || 'Electronics'}
              </span>
              <span>•</span>
              <div className="flex items-center space-x-1 text-slate-700">
                <Store className="w-3.5 h-3.5 text-blue-600" />
                <span>{product.store?.name || 'Verified Merchant Store'}</span>
                {product.store?.is_verified && <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />}
              </div>
            </div>

            {/* Title */}
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight leading-snug">
              {product.title}
            </h1>

            {/* Rating */}
            <div className="flex items-center space-x-3 text-xs">
              <div className="flex items-center text-amber-500 font-bold bg-amber-50 px-2 py-1 rounded-md">
                <Star className="w-4 h-4 fill-current mr-1" />
                <span>{product.rating || '4.9'}</span>
              </div>
              <span className="text-slate-400">({product.reviews_count || 84} customer reviews)</span>
              <span className="text-slate-300">|</span>
              <span className="text-green-600 font-bold">In Stock ({product.stock} units available)</span>
            </div>

            {/* Price Box */}
            <div className="bg-slate-50 p-5 rounded-3xl border border-slate-200/80 flex items-baseline space-x-3">
              <span className="text-3xl sm:text-4xl font-black text-slate-900">
                {formatCurrency(product.discount_price || product.price)}
              </span>
              {product.discount_price && (
                <span className="text-base text-slate-400 line-through">
                  {formatCurrency(product.price)}
                </span>
              )}
            </div>

            {/* Short Description */}
            <p className="text-sm text-slate-600 leading-relaxed">
              {product.description}
            </p>

            {/* Value Guarantees */}
            <div className="grid grid-cols-2 gap-3 pt-2 text-xs text-slate-600">
              <div className="flex items-center space-x-2 bg-white p-3 rounded-2xl border border-slate-200">
                <Truck className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Nationwide Courier Dispatch</span>
              </div>
              <div className="flex items-center space-x-2 bg-white p-3 rounded-2xl border border-slate-200">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                <span>100% Escrow Buyer Protection</span>
              </div>
            </div>
          </div>

          {/* Quantity & CTA Buttons */}
          <div className="pt-6 border-t border-slate-200 mt-6 space-y-4">
            <div className="flex items-center space-x-4">
              <span className="text-xs font-bold text-slate-700">Quantity:</span>
              <div className="flex items-center space-x-3 bg-slate-100 rounded-2xl px-3 py-1.5 border border-slate-200">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-7 h-7 flex items-center justify-center rounded-xl bg-white text-slate-700 shadow-xs active:scale-95"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="font-bold text-sm w-6 text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="w-7 h-7 flex items-center justify-center rounded-xl bg-white text-slate-700 shadow-xs active:scale-95"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {product.listing_type === 'job' ? (
              <div className="space-y-3">
                <button
                  onClick={() => setShowJobModal(true)}
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-4 rounded-2xl shadow-lg shadow-purple-600/20 active:scale-95 transition-all flex items-center justify-center space-x-2 text-sm"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Apply for this Job Position</span>
                </button>
              </div>
            ) : (
              <div className="flex space-x-3">
                <button
                  onClick={handleAddToCart}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-600/20 active:scale-95 transition-all flex items-center justify-center space-x-2 text-sm"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add to Cart ({formatCurrency((product.discount_price || product.price) * quantity)})</span>
                </button>

                <button
                  onClick={() => toggleWishlist(product)}
                  className={`p-4 rounded-2xl border-2 transition-all ${
                    isBookmarked
                      ? 'border-rose-300 bg-rose-50 text-rose-600'
                      : 'border-slate-200 hover:border-slate-300 bg-white text-slate-600'
                  }`}
                  title={isBookmarked ? 'Remove from wishlist' : 'Save to wishlist'}
                >
                  <Heart className={`w-5 h-5 ${isBookmarked ? 'fill-rose-600' : ''}`} />
                </button>
              </div>
            )}

            {/* Direct External Website Pass-through & WhatsApp contact */}
            {(product.website_url || product.contact_whatsapp) && (
              <div className="pt-2 flex flex-wrap items-center gap-2">
                {product.website_url && (
                  <a
                    href={product.website_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 px-4 rounded-2xl text-xs flex items-center justify-center space-x-2 transition"
                  >
                    <span>Visit Merchant Website Directly</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
                {product.contact_whatsapp && (
                  <a
                    href={`https://wa.me/${product.contact_whatsapp.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                      `Hello, I saw your listing "${product.title}" on Mega Marketplace and I want to order/inquire.`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-2xl text-xs flex items-center justify-center space-x-2 transition shadow-xs"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>WhatsApp Product Poster (+{product.contact_whatsapp.replace(/[^0-9]/g, '')})</span>
                  </a>
                )}
              </div>
            )}

            {/* PRODUCT POSTER SETTLEMENT ACCOUNT & ZERO-WALLET POLICY BADGE */}
            {product.poster_account_number && (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 flex items-center space-x-1.5">
                    <ShieldCheck className="w-4 h-4 text-blue-600" />
                    <span>Direct Poster Payment Account</span>
                  </span>
                  <span className="text-[10px] font-bold text-blue-700 bg-blue-100/70 px-2 py-0.5 rounded-full">
                    Zero Wallet Required
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] pt-1">
                  <span className="text-slate-500 font-medium">Bank & Account:</span>
                  <span className="font-bold text-slate-900">
                    {product.poster_account_bank || 'Bank'} • <span className="font-mono text-blue-600">{product.poster_account_number}</span>
                  </span>
                </div>
                {product.poster_account_name && (
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-500 font-medium">Poster Name:</span>
                    <span className="font-bold text-slate-700">{product.poster_account_name}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Tabs: Specifications & Reviews */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex space-x-4 border-b border-slate-200 pb-3 mb-6">
          {[
            { key: 'desc', label: 'Item Overview' },
            { key: 'specs', label: 'Tech Specifications' },
            { key: 'reviews', label: `Verified Reviews (${product.reviews_count || 84})` }
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as any)}
              className={`text-xs sm:text-sm font-bold pb-2 transition-colors ${
                activeTab === tab.key
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === 'desc' && (
          <div className="text-xs sm:text-sm text-slate-600 space-y-4 leading-relaxed">
            <p>{product.description}</p>
            <p>All devices and retail goods listed on Mega Marketplace undergo verified authenticity checks before seller disbursement.</p>
          </div>
        )}

        {activeTab === 'specs' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl flex justify-between">
              <span className="text-slate-500">Condition</span>
              <span className="font-bold text-slate-900">Brand New / Sealed</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl flex justify-between">
              <span className="text-slate-500">Warranty</span>
              <span className="font-bold text-slate-900">12 Months Official Merchant Warranty</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl flex justify-between">
              <span className="text-slate-500">Origin</span>
              <span className="font-bold text-slate-900">Original Manufacturer Authenticated</span>
            </div>
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-2xl text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">Emeka O. (Verified Buyer)</span>
                <span className="text-slate-400 text-[10px]">2 days ago</span>
              </div>
              <div className="flex text-amber-500 my-1">
                {'★'.repeat(5)}
              </div>
              <p className="text-slate-600">Arrived in pristine condition in Lagos within 24 hours. The packaging was immaculate.</p>
            </div>
          </div>
        )}
      </div>

      {/* Direct Job Application Modal */}
      {showJobModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            {jobSent ? (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-1">Application Sent to Poster!</h3>
                  <p className="text-xs text-slate-500">
                    Your candidate details and resume notes have been sent directly to <strong>{product.store?.name || 'the job poster'}</strong>. They will contact you shortly.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setJobSent(false);
                    setShowJobModal(false);
                    setJobResumeNotes('');
                    setJobPortfolioUrl('');
                  }}
                  className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl text-xs"
                >
                  Done
                </button>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!jobApplicantName.trim() || !jobApplicantPhone.trim() || !jobResumeNotes.trim()) {
                    addToast('Please enter your name, phone number, and experience notes.', 'error');
                    return;
                  }
                  addJobInquiry({
                    job_id: product.id,
                    job_title: product.title,
                    poster_name: product.store?.name || 'Marketplace Employer',
                    poster_contact: product.contact_whatsapp || platformSettings?.official_drop_phone || platformSettings?.admin_whatsapp_number || '0704409544',
                    applicant_name: jobApplicantName.trim(),
                    applicant_phone: jobApplicantPhone.trim(),
                    applicant_email: jobApplicantEmail.trim() || 'candidate@megamarket.ng',
                    resume_notes: jobResumeNotes.trim(),
                    portfolio_url: jobPortfolioUrl.trim() || undefined,
                    status: 'new'
                  });
                  setJobSent(true);
                }}
                className="space-y-4 text-xs"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold text-slate-900">Apply for this Job</h3>
                    <span className="text-[10px] bg-purple-100 text-purple-800 font-bold px-2 py-0.5 rounded-full">
                      Direct Application
                    </span>
                  </div>
                  <p className="text-slate-500 mt-1">
                    Role: <strong className="text-slate-800">{product.title}</strong> • Employer: <strong className="text-slate-800">{product.store?.name || 'Verified Merchant'}</strong>
                  </p>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Your Full Name</label>
                    <input
                      type="text"
                      required
                      value={jobApplicantName}
                      onChange={(e) => setJobApplicantName(e.target.value)}
                      placeholder="e.g. Kalu Johnson"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium focus:border-blue-600 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Phone / WhatsApp</label>
                      <input
                        type="tel"
                        required
                        value={jobApplicantPhone}
                        onChange={(e) => setJobApplicantPhone(e.target.value)}
                        placeholder="080 3456 7890"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium focus:border-blue-600 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Email Address</label>
                      <input
                        type="email"
                        required
                        value={jobApplicantEmail}
                        onChange={(e) => setJobApplicantEmail(e.target.value)}
                        placeholder="kalu@example.com"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium focus:border-blue-600 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Experience & Resume Notes</label>
                    <textarea
                      rows={3}
                      required
                      value={jobResumeNotes}
                      onChange={(e) => setJobResumeNotes(e.target.value)}
                      placeholder="Detail your background, relevant qualifications, and work history..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium focus:border-blue-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Portfolio or CV URL (Optional)</label>
                    <input
                      type="url"
                      value={jobPortfolioUrl}
                      onChange={(e) => setJobPortfolioUrl(e.target.value)}
                      placeholder="https://drive.google.com/... or LinkedIn"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex space-x-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowJobModal(false)}
                    className="flex-1 bg-slate-100 text-slate-700 font-semibold py-3 rounded-xl hover:bg-slate-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-xl shadow-md shadow-purple-600/20 active:scale-95 transition"
                  >
                    Send Application to Employer
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
