import React, { useState, useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useStore } from '../store';
import { ProductCard } from '../components/ProductCard';
import { UserAvatar } from '../components/UserAvatar';
import { Search, SlidersHorizontal, ShieldCheck, Star, MapPin, Store as StoreIcon, Sparkles, Phone, ArrowUpRight } from 'lucide-react';
import { ServiceItem, Store } from '../types';
import { formatCurrency } from '../lib/utils';

export default function Explore() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';

  const products = useStore(state => state.products);
  const deletedProductIds = useStore(state => state.deletedProductIds) || [];
  const stores = useStore(state => state.stores);
  const services = useStore(state => state.services);
  const addToCart = useStore(state => state.addToCart);
  const addServiceBooking = useStore(state => state.addServiceBooking);
  const addJobInquiry = useStore(state => state.addJobInquiry);
  const user = useStore(state => state.user);
  const addToast = useStore(state => state.addToast);
  const platformSettings = useStore(state => state.platformSettings);

  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [activeTab, setActiveTab] = useState<'all' | 'products' | 'services' | 'stores'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [onlyVerified, setOnlyVerified] = useState(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price_low' | 'price_high' | 'rating'>('featured');
  const [selectedServiceForBooking, setSelectedServiceForBooking] = useState<ServiceItem | null>(null);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);

  // Service Booking inputs
  const [bookingDate, setBookingDate] = useState('2026-09-15');
  const [bookingAddress, setBookingAddress] = useState('');
  const [bookingNotes, setBookingNotes] = useState('');
  const [bookingName, setBookingName] = useState(user?.full_name || '');
  const [bookingPhone, setBookingPhone] = useState(user?.phone || '');

  // Job Application Modal state
  const [selectedJobForApplication, setSelectedJobForApplication] = useState<{ id: string; title: string; poster: string; contact?: string } | null>(null);
  const [jobApplicantName, setJobApplicantName] = useState(user?.full_name || '');
  const [jobApplicantPhone, setJobApplicantPhone] = useState(user?.phone || '');
  const [jobApplicantEmail, setJobApplicantEmail] = useState(user?.email || '');
  const [jobResumeNotes, setJobResumeNotes] = useState('');
  const [jobPortfolioUrl, setJobPortfolioUrl] = useState('');
  const [jobSubmitted, setJobSubmitted] = useState(false);

  const categories = ['All', 'Electronics', 'Fashion', 'Home & Living', 'Tech & Digital', 'Creative & Media', 'Repairs & Installation'];

  // Filtered Products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      // Must not be deleted and must be approved by admin / money checker
      if (deletedProductIds.includes(p.id)) return false;
      if (p.is_approved === false) return false;

      const matchesSearch = !searchQuery.trim() || 
        p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.tags?.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCat = selectedCategory === 'All' || p.category === selectedCategory;
      const matchesVerified = !onlyVerified || p.store?.is_verified;

      return matchesSearch && matchesCat && matchesVerified;
    }).sort((a, b) => {
      // Prioritize boosted / upper products controlled from admin panel
      if (a.is_boosted && !b.is_boosted) return -1;
      if (!a.is_boosted && b.is_boosted) return 1;
      if (sortBy === 'price_low') return (a.discount_price || a.price) - (b.discount_price || b.price);
      if (sortBy === 'price_high') return (b.discount_price || b.price) - (a.discount_price || a.price);
      if (sortBy === 'rating') return (b.rating || 0) - (a.rating || 0);
      if (a.is_featured && !b.is_featured) return -1;
      if (!a.is_featured && b.is_featured) return 1;
      return 0;
    });
  }, [products, deletedProductIds, searchQuery, selectedCategory, onlyVerified, sortBy]);

  // Filtered Services
  const filteredServices = useMemo(() => {
    return services.filter(s => {
      const matchesSearch = !searchQuery.trim() ||
        s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.provider_name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCat = selectedCategory === 'All' || s.category.includes(selectedCategory);
      return matchesSearch && matchesCat;
    });
  }, [services, searchQuery, selectedCategory]);

  // Filtered Stores
  const filteredStores = useMemo(() => {
    return stores.filter(st => {
      const matchesSearch = !searchQuery.trim() ||
        st.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        st.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesSearch;
    });
  }, [stores, searchQuery]);

  return (
    <div className="px-4 py-6 md:py-10 max-w-7xl mx-auto">
      {/* Header / Search Controls */}
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-2">
          Universal Marketplace Search
        </h1>
        <p className="text-sm text-slate-500 mb-6">
          Find verified retail goods, artisanal fashion, and certified professional services across Nigeria.
        </p>

        {/* Big Search Input */}
        <div className="relative flex items-center">
          <Search className="w-5 h-5 text-blue-600 absolute left-4" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setSearchParams(e.target.value ? { q: e.target.value } : {});
            }}
            placeholder="Search by keywords, model (e.g. MacBook, Nike, Inverter)..."
            className="w-full bg-white text-slate-900 font-medium pl-12 pr-12 py-4 rounded-2xl border border-slate-200 shadow-sm focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 focus:outline-none transition-all text-sm sm:text-base"
          />
          {searchQuery && (
            <button
              onClick={() => { setSearchQuery(''); setSearchParams({}); }}
              className="absolute right-4 text-xs font-semibold text-slate-400 hover:text-slate-700 bg-slate-100 px-2 py-1 rounded-md"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Tabs (All, Products, Services, Stores) */}
      <div className="flex items-center space-x-2 border-b border-slate-200 pb-3 mb-6 overflow-x-auto no-scrollbar">
        {[
          { key: 'all', label: 'All Results' },
          { key: 'products', label: `Products (${filteredProducts.length})` },
          { key: 'services', label: `Services (${filteredServices.length})` },
          { key: 'stores', label: `Verified Stores (${filteredStores.length})` },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as any)}
            className={`text-xs sm:text-sm font-bold px-4 py-2 rounded-xl transition-all whitespace-nowrap ${
              activeTab === tab.key
                ? 'bg-blue-600 text-white shadow-xs shadow-blue-600/20'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/60'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Categories & Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        {/* Horizontal Category Badges */}
        <div className="flex space-x-2 overflow-x-auto no-scrollbar py-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`text-xs font-semibold px-3.5 py-1.5 rounded-full transition-all whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Sort & Verified Toggle */}
        <div className="flex items-center space-x-3">
          <label className="flex items-center space-x-2 cursor-pointer bg-white px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50">
            <input
              type="checkbox"
              checked={onlyVerified}
              onChange={(e) => setOnlyVerified(e.target.checked)}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
            />
            <span className="flex items-center text-blue-600">
              <ShieldCheck className="w-3.5 h-3.5 mr-1" />
              Verified Only
            </span>
          </label>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-white text-xs font-semibold text-slate-700 px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-500"
          >
            <option value="featured">Sort: Recommended</option>
            <option value="price_low">Price: Low to High</option>
            <option value="price_high">Price: High to Low</option>
            <option value="rating">Highest Rated</option>
          </select>
        </div>
      </div>

      {/* Main Results Display */}
      {(activeTab === 'all' || activeTab === 'products') && (
        <div className="mb-12">
          {activeTab === 'all' && (
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-900">Products ({filteredProducts.length})</h2>
              {filteredProducts.length > 4 && (
                <button onClick={() => setActiveTab('products')} className="text-xs font-bold text-blue-600 hover:underline">
                  View All Products →
                </button>
              )}
            </div>
          )}

          {filteredProducts.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center border border-slate-200">
              <p className="text-slate-500 text-sm">No products found matching your filters.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {(activeTab === 'all' ? filteredProducts.slice(0, 8) : filteredProducts).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Services Section */}
      {filteredServices.length > 0 && (activeTab === 'all' || activeTab === 'services') && (
        <div className="mb-12">
          {activeTab === 'all' && (
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-900">Certified Services ({filteredServices.length})</h2>
              {filteredServices.length > 3 && (
                <button onClick={() => setActiveTab('services')} className="text-xs font-bold text-blue-600 hover:underline">
                  View All Services →
                </button>
              )}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredServices.map((service) => (
              <div key={service.id} className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-sm hover:shadow-md hover:border-blue-200 transition-all flex flex-col justify-between">
                <div>
                  <div className="aspect-[16/9] rounded-2xl overflow-hidden mb-4 bg-slate-100 relative">
                    <img 
                      src={service.image} 
                      alt={service.title} 
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&q=80&w=1000';
                      }}
                      className="w-full h-full object-cover" 
                    />
                    <span className="absolute top-3 left-3 bg-blue-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                      {service.category}
                    </span>
                  </div>

                  <div className="flex items-center space-x-2.5 mb-2">
                    <UserAvatar src={service.provider_avatar} alt={service.provider_name} className="w-7 h-7 rounded-full border border-blue-200" />
                    <span className="text-xs font-semibold text-slate-700">{service.provider_name}</span>
                    {service.is_verified && (
                      <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                    )}
                  </div>

                  <h3 className="font-bold text-base text-slate-900 mb-2 leading-snug">{service.title}</h3>
                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mb-4">{service.description}</p>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-400 block">{service.pricing_unit}</span>
                    <span className="text-base font-extrabold text-blue-600">{formatCurrency(service.price)}</span>
                  </div>

                  <button
                    onClick={() => setSelectedServiceForBooking(service)}
                    className="bg-slate-900 hover:bg-blue-600 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-colors active:scale-95 flex items-center space-x-1.5"
                  >
                    <span>Book Service</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty State for Services tab when no services exist */}
      {activeTab === 'services' && filteredServices.length === 0 && (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200/80 mb-12 shadow-xs">
          <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShieldCheck className="w-8 h-8 text-slate-400" />
          </div>
          <h3 className="text-lg font-bold text-slate-800 mb-1">No Services Currently Listed</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-6">
            All empty demo services have been removed to prevent booking unfulfilled bookings. Certified service providers can publish verified offerings directly.
          </p>
          <Link
            to="/sell?type=service"
            className="inline-flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-5 py-3 rounded-xl transition shadow-xs"
          >
            <span>List a Verified Service</span>
            <ArrowUpRight className="w-4 h-4" />
          </Link>
        </div>
      )}

      {/* Stores Section */}
      {(activeTab === 'all' || activeTab === 'stores') && (
        <div className="mb-12">
          {activeTab === 'all' && (
            <h2 className="text-lg font-bold text-slate-900 mb-4">Top Rated Stores ({filteredStores.length})</h2>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredStores.map((store) => (
              <div key={store.id} className="bg-white rounded-3xl overflow-hidden border border-slate-200/90 shadow-sm hover:border-blue-300 transition-all">
                <div className="h-28 bg-slate-200 relative overflow-hidden">
                  <img 
                    src={store.cover_url} 
                    alt={store.name} 
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=1200';
                    }}
                    className="w-full h-full object-cover" 
                  />
                </div>
                <div className="p-5 relative pt-0">
                  <div className="-mt-8 mb-3 flex justify-between items-end">
                    <img 
                      src={store.logo_url} 
                      alt={store.name} 
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = 'https://ui-avatars.com/api/?name=Store&background=random';
                      }}
                      className="w-16 h-16 rounded-2xl border-4 border-white shadow-md object-cover bg-white" 
                    />
                    <span className="text-xs font-bold bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full flex items-center">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400 mr-1" />
                      {store.rating || 4.9}
                    </span>
                  </div>

                  <div className="flex items-center space-x-1.5 mb-1">
                    <h3 className="font-bold text-base text-slate-900">{store.name}</h3>
                    {store.is_verified && <ShieldCheck className="w-4 h-4 text-blue-600" />}
                  </div>

                  <p className="text-xs text-slate-500 mb-4 line-clamp-2">{store.description}</p>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-500 pt-3 border-t border-slate-100">
                    <span className="flex items-center text-[11px] truncate">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 mr-1 shrink-0" />
                      <span className="truncate">{store.location || 'Ankpa, Kogi State, Nigeria'}</span>
                    </span>

                    {/* Direct TikTok Account Link */}
                    {store.tiktok_url ? (
                      <a
                        href={store.tiktok_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="inline-flex items-center space-x-1.5 bg-black hover:bg-slate-900 text-white font-bold px-3 py-1.5 rounded-xl text-[11px] border border-pink-500/30 transition-all shadow-xs group w-fit"
                        title={`Open ${store.name} TikTok: ${store.tiktok_handle || '@store'}`}
                      >
                        <span className="w-3.5 h-3.5 rounded-sm bg-gradient-to-tr from-[#00f2fe] to-[#fe0979] flex items-center justify-center text-[9px] font-black">
                          ♪
                        </span>
                        <span>{store.tiktok_followers || store.followers_count || '1K+'} Followers</span>
                      </a>
                    ) : (
                      <span className="font-semibold text-blue-600">{store.followers_count || 500}+ Followers</span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Service Booking Modal */}
      {selectedServiceForBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            {bookingConfirmed ? (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-1">Booking Message Sent!</h3>
                  <p className="text-xs text-slate-500">
                    A direct booking message has been dispatched to <strong>{selectedServiceForBooking.provider_name}</strong>. Their team will contact you directly on <strong>{bookingPhone || 'your phone'}</strong>.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-left text-xs space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">Booking Details</span>
                  <p className="font-semibold text-slate-800">{selectedServiceForBooking.title}</p>
                  <p className="text-slate-500">Date: {bookingDate} • Fee: {formatCurrency(selectedServiceForBooking.price)}</p>
                  <p className="text-slate-500 truncate">Location: {bookingAddress || 'Lagos / On-Site'}</p>
                </div>

                <div className="flex gap-2">
                  <a
                    href={`https://wa.me/2347044095544?text=${encodeURIComponent(
                      `Hello ${selectedServiceForBooking.provider_name}, I just placed a booking for "${selectedServiceForBooking.title}" on Mega Marketplace. Preferred date: ${bookingDate}. Location: ${bookingAddress || 'On-site'}. Notes: ${bookingNotes || 'Please contact me.'}`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-xl text-xs flex items-center justify-center space-x-1.5 transition"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>WhatsApp Provider</span>
                  </a>
                  <button
                    onClick={() => {
                      setBookingConfirmed(false);
                      setSelectedServiceForBooking(null);
                      setBookingAddress('');
                      setBookingNotes('');
                    }}
                    className="flex-1 bg-slate-100 text-slate-800 font-bold py-3 rounded-xl text-xs hover:bg-slate-200"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!bookingName.trim() || !bookingPhone.trim()) {
                    addToast('Please enter your contact name and phone number.', 'error');
                    return;
                  }
                  addServiceBooking({
                    service_id: selectedServiceForBooking.id,
                    service_title: selectedServiceForBooking.title,
                    provider_name: selectedServiceForBooking.provider_name,
                    provider_phone: selectedServiceForBooking.provider_name ? (platformSettings?.official_drop_phone || platformSettings?.admin_whatsapp_number || '0704409544') : '0704409544',
                    customer_name: bookingName.trim(),
                    customer_phone: bookingPhone.trim(),
                    preferred_date: bookingDate,
                    service_address: bookingAddress.trim() || 'Nigeria / On-site',
                    service_notes: bookingNotes.trim() || 'Client requested professional service booking.',
                    estimated_fee: selectedServiceForBooking.price,
                    status: 'pending'
                  });
                  setBookingConfirmed(true);
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-bold text-slate-900">Book Service Appointment</h3>
                  <span className="text-xs bg-blue-50 text-blue-700 font-bold px-2 py-0.5 rounded-full">
                    Direct Message
                  </span>
                </div>
                <p className="text-xs text-slate-500 mb-4">{selectedServiceForBooking.title}</p>
                
                <div className="space-y-3 mb-6 text-sm">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">Your Full Name</label>
                      <input
                        type="text"
                        required
                        value={bookingName}
                        onChange={(e) => setBookingName(e.target.value)}
                        placeholder="e.g. David Adeleke"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-medium focus:border-blue-600 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">Your Phone / WhatsApp</label>
                      <input
                        type="tel"
                        required
                        value={bookingPhone}
                        onChange={(e) => setBookingPhone(e.target.value)}
                        placeholder="080 1234 5678"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-medium focus:border-blue-600 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">Preferred Date</label>
                    <input
                      type="date"
                      value={bookingDate}
                      onChange={(e) => setBookingDate(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-medium focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">Service Location / Address</label>
                    <input
                      type="text"
                      value={bookingAddress}
                      onChange={(e) => setBookingAddress(e.target.value)}
                      placeholder="e.g. 14 Admiralty Way, Lekki Phase 1 / Ankpa, Kogi"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-medium focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">Service Notes & Specific Requests</label>
                    <textarea
                      rows={2}
                      value={bookingNotes}
                      onChange={(e) => setBookingNotes(e.target.value)}
                      placeholder="Explain specific project requirements (e.g. 5kVA solar inverter, 4 bedrooms)..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-medium focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-slate-100 mb-6">
                  <span className="text-xs text-slate-500">Service Estimate:</span>
                  <span className="text-lg font-extrabold text-blue-600">{formatCurrency(selectedServiceForBooking.price)}</span>
                </div>

                <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={() => setSelectedServiceForBooking(null)}
                    className="flex-1 bg-slate-100 text-slate-700 font-semibold py-3 rounded-xl text-xs hover:bg-slate-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 text-white font-bold py-3 rounded-xl text-xs hover:bg-blue-700 shadow-md shadow-blue-600/20 active:scale-95 transition"
                  >
                    Send Booking to Provider
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Job Application Direct Message Modal */}
      {selectedJobForApplication && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            {jobSubmitted ? (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-1">Application Sent to Employer!</h3>
                  <p className="text-xs text-slate-500">
                    Your candidate details and resume notes have been sent directly to <strong>{selectedJobForApplication.poster}</strong> for the role of <strong>{selectedJobForApplication.title}</strong>.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setJobSubmitted(false);
                    setSelectedJobForApplication(null);
                    setJobResumeNotes('');
                    setJobPortfolioUrl('');
                  }}
                  className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl text-xs"
                >
                  Done
                </button>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!jobApplicantName.trim() || !jobApplicantPhone.trim() || !jobResumeNotes.trim()) {
                    addToast('Please provide your name, phone, and brief experience summary.', 'error');
                    return;
                  }
                  addJobInquiry({
                    job_id: selectedJobForApplication.id,
                    job_title: selectedJobForApplication.title,
                    poster_name: selectedJobForApplication.poster,
                    poster_contact: selectedJobForApplication.contact || platformSettings?.official_drop_phone || platformSettings?.admin_whatsapp_number || '0704409544',
                    applicant_name: jobApplicantName.trim(),
                    applicant_phone: jobApplicantPhone.trim(),
                    applicant_email: jobApplicantEmail.trim() || 'applicant@megamarket.ng',
                    resume_notes: jobResumeNotes.trim(),
                    portfolio_url: jobPortfolioUrl.trim() || undefined,
                    status: 'new'
                  });
                  setJobSubmitted(true);
                }}
                className="space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold text-slate-900">Apply for Job Position</h3>
                    <span className="text-[10px] bg-purple-100 text-purple-800 font-bold px-2 py-0.5 rounded-full">
                      Direct Application
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Role: <strong className="text-slate-800">{selectedJobForApplication.title}</strong> • Posted by: <strong className="text-slate-800">{selectedJobForApplication.poster}</strong>
                  </p>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Your Full Name</label>
                    <input
                      type="text"
                      required
                      value={jobApplicantName}
                      onChange={(e) => setJobApplicantName(e.target.value)}
                      placeholder="e.g. Kalu Johnson"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium focus:border-blue-600 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Phone / WhatsApp</label>
                      <input
                        type="tel"
                        required
                        value={jobApplicantPhone}
                        onChange={(e) => setJobApplicantPhone(e.target.value)}
                        placeholder="08034567890"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium focus:border-blue-600 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Email</label>
                      <input
                        type="email"
                        required
                        value={jobApplicantEmail}
                        onChange={(e) => setJobApplicantEmail(e.target.value)}
                        placeholder="kalu@sample.com"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium focus:border-blue-600 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Experience & Cover Summary</label>
                    <textarea
                      rows={3}
                      required
                      value={jobResumeNotes}
                      onChange={(e) => setJobResumeNotes(e.target.value)}
                      placeholder="Outline your qualifications, years of experience, and why you are the best fit for this role..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium focus:border-blue-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Resume / Portfolio Link (Optional)</label>
                    <input
                      type="url"
                      value={jobPortfolioUrl}
                      onChange={(e) => setJobPortfolioUrl(e.target.value)}
                      placeholder="https://linkedin.com/in/... or Google Drive Link"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex space-x-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setSelectedJobForApplication(null)}
                    className="flex-1 bg-slate-100 text-slate-700 font-semibold py-3 rounded-xl text-xs hover:bg-slate-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl text-xs shadow-md shadow-blue-600/20 active:scale-95 transition"
                  >
                    Submit Application to Poster
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
