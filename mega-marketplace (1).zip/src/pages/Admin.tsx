import React, { useState } from 'react';
import { useStore } from '../store';
import { formatCurrency } from '../lib/utils';
import { ImageDropzone } from '../components/ImageDropzone';
import { UserAvatar } from '../components/UserAvatar';
import { NEUTRAL_AVATAR_PRESETS } from '../services/mockData';
import { Order, Profile, PlatformSettings, AIWhatsappAlert } from '../types';
import { 
  Shield, 
  ShieldCheck, 
  Trash2, 
  Lock, 
  Unlock, 
  CheckCircle2, 
  AlertCircle, 
  TrendingUp, 
  Package, 
  Store as StoreIcon, 
  DollarSign, 
  Layers, 
  Sparkles, 
  ArrowLeft,
  Truck,
  Eye,
  AlertTriangle,
  Settings,
  Users,
  MessageSquare,
  Edit3,
  Camera,
  Upload,
  Save,
  Check,
  RefreshCw,
  Clock,
  Send,
  ExternalLink,
  ChevronRight,
  MapPin,
  Phone,
  Briefcase
} from 'lucide-react';
import { TeamLogin } from '../components/TeamLogin';
import { applySupabaseCredentialsGlobally, testSupabaseConnection } from '../lib/supabase';

export default function Admin() {
  const { 
    products, 
    stores, 
    orders, 
    registeredUsers,
    isAdminAuthenticated, 
    verifyAdminPassword, 
    logoutAdmin,
    services,
    deleteService,
    deleteProduct,
    deleteRegisteredUser,
    factoryResetApp,
    updateOrderStatus,
    updateOrderRecord,
    approveSellerPayout,
    platformSettings,
    updatePlatformSettings,
    aiAlerts,
    sendWhatsappAlert,
    updateUserRoleAndBalance,
    phoneDropAlerts,
    broadcastPhoneDropAlert,
    deletePhoneDropAlert,
    approveProductListing,
    approveSellerAccount,
    currency,
    addToast
  } = useStore();

  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState(false);
  const [activeAdminTab, setActiveAdminTab] = useState<'overview' | 'sales_editor' | 'settings' | 'ai_whatsapp' | 'users' | 'inventory' | 'team_login' | 'phone_drops' | 'approvals'>('overview');
  const [catalogTab, setCatalogTab] = useState<'products' | 'services'>('products');

  // Phone Drop Broadcast State
  const [dropTitle, setDropTitle] = useState('');
  const [dropMessage, setDropMessage] = useState('');
  const [dropPhone, setDropPhone] = useState(platformSettings.official_drop_phone || platformSettings.admin_whatsapp_number || '0704409544');
  const [dropImage, setDropImage] = useState('https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=300');

  // Admin Profile Image State
  const [adminAvatar, setAdminAvatar] = useState(platformSettings.admin_avatar_url || '');
  const [adminName, setAdminName] = useState(platformSettings.admin_name || 'Cyprian O.');
  const [adminEmail, setAdminEmail] = useState(platformSettings.admin_email || 'admin@megamarket.ng');
  const [whatsappNum, setWhatsappNum] = useState(platformSettings.admin_whatsapp_number || '0704409544');
  const [officialDropPhone, setOfficialDropPhone] = useState(platformSettings.official_drop_phone || '0704409544');
  const [platformLocation, setPlatformLocation] = useState(platformSettings.platform_location || 'Ankpa, Kogi State, Nigeria');
  const [supabaseUrl, setSupabaseUrl] = useState(platformSettings.supabase_url || 'https://ugkvfehugcakdqbikdyx.supabase.co');
  const [supabaseKey, setSupabaseKey] = useState(platformSettings.supabase_anon_key || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVna3ZmZWh1Z2Nha2RxYmlrZHl4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA5MjI4NjAsImV4cCI6MjEwNjQ5ODg2MH0.IzeQYl5RG9mDUnh1InFPw_ZAp-xvory2Z9C6XE_dSqw');
  const [paystackKey, setPaystackKey] = useState(platformSettings.paystack_public_key || '');
  const [autoApprove, setAutoApprove] = useState(platformSettings.auto_approve_first_time_sellers);
  const [baseFee, setBaseFee] = useState(platformSettings.base_platform_fee.toString());
  const [highThreshold, setHighThreshold] = useState(platformSettings.high_value_threshold.toString());
  const [highFeePercent, setHighFeePercent] = useState(platformSettings.high_value_fee_percent.toString());

  // Edit Order Record Modal State
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [editOrderNumber, setEditOrderNumber] = useState('');
  const [editCustomerName, setEditCustomerName] = useState('');
  const [editCustomerPhone, setEditCustomerPhone] = useState('');
  const [editTotalAmount, setEditTotalAmount] = useState('');
  const [editDeliveryFee, setEditDeliveryFee] = useState('');
  const [editPlatformFee, setEditPlatformFee] = useState('');
  const [editStatus, setEditStatus] = useState<Order['status']>('paid');
  const [editPaymentStatus, setEditPaymentStatus] = useState<Order['payment_status']>('paid');
  const [editTrackingNumber, setEditTrackingNumber] = useState('');
  const [editCourierName, setEditCourierName] = useState('');

  // AI WhatsApp Simulator input
  const [testAiMsg, setTestAiMsg] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const ok = verifyAdminPassword(passwordInput);
    if (!ok) {
      setAuthError(true);
    } else {
      setAuthError(false);
      setPasswordInput('');
    }
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const hasApiKeysChanged = 
      supabaseUrl !== platformSettings.supabase_url || 
      supabaseKey !== platformSettings.supabase_anon_key || 
      paystackKey !== platformSettings.paystack_public_key;

    // Apply Supabase credentials globally
    if (supabaseUrl && supabaseKey) {
      applySupabaseCredentialsGlobally(supabaseUrl, supabaseKey);
    }

    updatePlatformSettings({
      admin_avatar_url: adminAvatar,
      admin_name: adminName,
      admin_email: adminEmail,
      admin_whatsapp_number: whatsappNum || officialDropPhone || '0704409544',
      official_drop_phone: officialDropPhone || whatsappNum || '0704409544',
      platform_location: platformLocation,
      supabase_url: supabaseUrl,
      supabase_anon_key: supabaseKey,
      paystack_public_key: paystackKey,
      auto_approve_first_time_sellers: autoApprove,
      base_platform_fee: parseFloat(baseFee) || 500,
      high_value_threshold: parseFloat(highThreshold) || 100000,
      high_value_fee_percent: parseFloat(highFeePercent) || 2.5
    });

    addToast("Platform settings, Drop Phone Number (0704409544), and Supabase credentials saved and connected globally!", "success", "Settings Saved");
  };

  const openOrderEditor = (order: Order) => {
    setEditingOrder(order);
    setEditOrderNumber(order.order_number);
    setEditCustomerName(order.customer_name);
    setEditCustomerPhone(order.customer_phone);
    setEditTotalAmount(order.total_amount.toString());
    setEditDeliveryFee((order.delivery_fee || 3000).toString());
    setEditPlatformFee((order.platform_fee || 500).toString());
    setEditStatus(order.status);
    setEditPaymentStatus(order.payment_status);
    setEditTrackingNumber(order.tracking_number || '');
    setEditCourierName(order.courier_name || 'GIG Express Logistics');
  };

  const handleSaveOrderEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingOrder) return;

    const totalNum = parseFloat(editTotalAmount) || editingOrder.total_amount;
    const feeNum = parseFloat(editPlatformFee) || 500;
    const sellerPayout = Math.max(0, totalNum - feeNum);

    updateOrderRecord(editingOrder.id, {
      customer_name: editCustomerName,
      customer_phone: editCustomerPhone,
      total_amount: totalNum,
      delivery_fee: parseFloat(editDeliveryFee) || 0,
      platform_fee: feeNum,
      seller_payout_amount: sellerPayout,
      status: editStatus,
      payment_status: editPaymentStatus,
      tracking_number: editTrackingNumber,
      courier_name: editCourierName
    });

    setEditingOrder(null);
  };

  const handleSendTestAiWhatsapp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testAiMsg.trim()) return;
    sendWhatsappAlert(testAiMsg.trim(), 'SUSPICIOUS_ACTIVITY', 'high');
    setTestAiMsg('');
    addToast(`AI alert dispatched to WhatsApp: ${whatsappNum}`, 'success');
  };

  const handleBroadcastDrop = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dropTitle || !dropMessage) {
      addToast('Please provide title and message for the phone drop.', 'error');
      return;
    }
    broadcastPhoneDropAlert({
      title: dropTitle,
      message: dropMessage,
      recipientPhone: dropPhone || officialDropPhone || whatsappNum || '0704409544',
      channel: 'WHATSAPP',
      productTitle: dropTitle,
      productPrice: 25000,
      productImage: dropImage,
      locationTag: platformSettings.platform_location || 'Ankpa, Kogi State, Nigeria'
    });
    setDropTitle('');
    setDropMessage('');
    addToast('Phone drop posted and broadcasted live to all devices!', 'success');
  };

  // If not logged in as Admin, show high-security Login Portal
  if (!isAdminAuthenticated) {
    return (
      <div className="min-h-[75vh] flex items-center justify-center px-4">
        <div className="bg-white w-full max-w-md rounded-3xl p-8 border border-slate-200 shadow-xl text-center">
          <div className="w-16 h-16 rounded-3xl bg-slate-900 text-amber-400 flex items-center justify-center mx-auto mb-5 shadow-lg">
            <Lock className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight mb-2">Super Admin Control Center</h2>
          <p className="text-xs text-slate-500 mb-6">
            Enter administrator master password (<span className="font-mono font-bold text-blue-600">Cyprian123</span>) to manage sales records, platform settings & AI WhatsApp monitoring.
          </p>

          <form onSubmit={handleLogin} className="space-y-4 text-xs">
            <div className="text-left">
              <input
                type="password"
                required
                value={passwordInput}
                onChange={(e) => {
                  setPasswordInput(e.target.value);
                  setAuthError(false);
                }}
                placeholder="Enter password (Cyprian123)..."
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-3.5 text-sm font-semibold text-slate-900 focus:border-blue-600 focus:outline-none transition-all"
              />
              {authError && (
                <p className="text-xs text-rose-600 font-bold mt-2 flex items-center">
                  <AlertCircle className="w-4 h-4 mr-1" />
                  Incorrect administrator password.
                </p>
              )}
            </div>

            <button
              type="submit"
              className="w-full bg-slate-900 hover:bg-black text-white font-bold py-3.5 rounded-2xl text-sm transition-all shadow-md active:scale-95 flex items-center justify-center space-x-2"
            >
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              <span>Authenticate & Enter</span>
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Calculate totals
  const totalVolume = orders.reduce((acc, o) => acc + o.total_amount, 0);
  const totalPlatformFees = orders.reduce((acc, o) => acc + (o.platform_fee || 500), 0);
  const pendingOrders = orders.filter(o => o.status !== 'delivered' && o.status !== 'cancelled');
  const deliveredOrders = orders.filter(o => o.status === 'delivered');

  // Traffic & Analytics data for chart
  const weeklyTraffic = [
    { day: 'Mon', visits: 1240, sales: 8, height: '40%' },
    { day: 'Tue', visits: 1890, sales: 14, height: '60%' },
    { day: 'Wed', visits: 2450, sales: 22, height: '75%' },
    { day: 'Thu', visits: 2100, sales: 18, height: '68%' },
    { day: 'Fri', visits: 3820, sales: 36, height: '95%' },
    { day: 'Sat', visits: 4100, sales: 42, height: '100%' },
    { day: 'Sun', visits: 3150, sales: 29, height: '82%' },
  ];

  return (
    <div className="py-4 md:py-6 space-y-8 max-w-7xl mx-auto">
      {/* Top Admin Bar with Profile & Quick Settings */}
      <div className="bg-slate-950 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <div className="relative group cursor-pointer" onClick={() => setActiveAdminTab('settings')}>
            <img
              src={platformSettings.admin_avatar_url || adminAvatar}
              alt="Admin Profile"
              className="w-16 h-16 rounded-2xl object-cover border-2 border-blue-500 shadow-lg"
            />
            <div className="absolute inset-0 bg-black/50 rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <Camera className="w-5 h-5 text-white" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl sm:text-2xl font-black text-white">{platformSettings.admin_name || 'Cyprian O.'}</h2>
              <span className="bg-blue-500/20 text-blue-400 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full border border-blue-500/30">
                Super Admin
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              WhatsApp Emergency Hotline: <strong className="text-green-400">{platformSettings.admin_whatsapp_number || '07044095544'}</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3 w-full md:w-auto justify-end">
          <button
            onClick={() => setActiveAdminTab('ai_whatsapp')}
            className="bg-green-600/20 hover:bg-green-600/30 border border-green-500/40 text-green-300 font-bold px-4 py-2.5 rounded-2xl text-xs flex items-center space-x-2 transition-all"
          >
            <MessageSquare className="w-4 h-4 text-green-400" />
            <span>AI WhatsApp Overseer ({aiAlerts.length})</span>
          </button>

          <button
            onClick={logoutAdmin}
            className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2.5 rounded-2xl text-xs border border-slate-700 transition-all flex items-center space-x-1.5"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Lock Session</span>
          </button>
        </div>
      </div>

      {/* Admin KPI Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-bold block mb-1">Gross Merchandise Volume</span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 leading-none">
              {formatCurrency(totalVolume, currency)}
            </span>
            <span className="text-[11px] text-green-600 font-semibold block mt-1.5">Across all store checkouts</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-bold block mb-1">Platform Revenue Fees</span>
            <span className="text-xl sm:text-2xl font-black text-blue-600 leading-none">
              {formatCurrency(totalPlatformFees, currency)}
            </span>
            <span className="text-[11px] text-slate-400 block mt-1.5">₦500 Base + 2.5% High-Val</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-bold block mb-1">Pending In-Transit Orders</span>
            <span className="text-xl sm:text-2xl font-black text-amber-600 leading-none">
              {pendingOrders.length} Orders
            </span>
            <span className="text-[11px] text-slate-500 block mt-1.5">{deliveredOrders.length} delivered & confirmed</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-bold block mb-1">Total Registered Accounts</span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 leading-none">
              {registeredUsers.length} Users
            </span>
            <span className="text-[11px] text-green-600 font-bold block mt-1.5">{stores.length} Verified Stores</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex bg-white p-1.5 rounded-2xl border border-slate-200 text-xs font-bold space-x-1 overflow-x-auto">
        <button
          onClick={() => setActiveAdminTab('overview')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeAdminTab === 'overview' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Analytics & Traffic Overview
        </button>

        <button
          onClick={() => setActiveAdminTab('sales_editor')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeAdminTab === 'sales_editor' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Orders & Sales Records Editor ({orders.length})
        </button>

        <button
          onClick={() => setActiveAdminTab('settings')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeAdminTab === 'settings' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Platform Settings & Auto-Accept
        </button>

        <button
          onClick={() => setActiveAdminTab('ai_whatsapp')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeAdminTab === 'ai_whatsapp' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          AI Guardian WhatsApp Logs ({aiAlerts.length})
        </button>

        <button
          onClick={() => setActiveAdminTab('users')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeAdminTab === 'users' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Users & Business Accounts ({registeredUsers.length})
        </button>

        <button
          onClick={() => setActiveAdminTab('team_login')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeAdminTab === 'team_login' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Team Login
        </button>

        <button
          onClick={() => setActiveAdminTab('inventory')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeAdminTab === 'inventory' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Catalog & Services ({products.length} Items / {services.length} Services)
        </button>

        <button
          onClick={() => setActiveAdminTab('phone_drops')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeAdminTab === 'phone_drops' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Phone Drops & SMS ({phoneDropAlerts.length})
        </button>

        <button
          onClick={() => setActiveAdminTab('approvals')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeAdminTab === 'approvals' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Approvals & Products ({products.filter(p => !p.is_approved).length} Pending)
        </button>
      </div>

      {/* PHONE DROPS & SMS MANAGER TAB */}
      {activeAdminTab === 'phone_drops' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
            <h3 className="text-lg font-black text-slate-900 mb-2">Phone Drops & SMS Campaign Manager</h3>
            <p className="text-xs text-slate-500 mb-6">
              Post and control live phone drop alerts. Whatever you post here reflects immediately across all subscriber devices and notifications.
            </p>

            <form onSubmit={handleBroadcastDrop} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Drop Title / Product</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. ⚡ FLASH DROP: iPhone 15 Pro Max"
                    value={dropTitle}
                    onChange={(e) => setDropTitle(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Recipient Phone / WhatsApp</label>
                  <input
                    type="text"
                    required
                    value={dropPhone}
                    onChange={(e) => setDropPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Drop Message / Notification Content</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Enter details about this drop..."
                  value={dropMessage}
                  onChange={(e) => setDropMessage(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-3.5 rounded-xl shadow-md transition-all active:scale-95 flex items-center space-x-2"
              >
                <Send className="w-4 h-4" />
                <span>Broadcast Live Phone Drop</span>
              </button>
            </form>
          </div>

          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
            <h3 className="text-lg font-black text-slate-900 mb-4">Active Broadcasted Phone Drops ({phoneDropAlerts.length})</h3>
            <div className="space-y-3">
              {phoneDropAlerts.map((drop) => (
                <div key={drop.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
                  <div className="flex items-center space-x-4">
                    {drop.productImage && (
                      <img src={drop.productImage} alt="" className="w-12 h-12 rounded-xl object-cover" />
                    )}
                    <div>
                      <h4 className="font-bold text-slate-900">{drop.title}</h4>
                      <p className="text-xs text-slate-500 mt-0.5">{drop.message}</p>
                      <span className="text-[10px] text-blue-600 font-bold mt-1 inline-block">Channel: {drop.channel} • {drop.timestamp}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => deletePhoneDropAlert(drop.id)}
                    className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-all"
                    title="Delete Drop"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* APPROVALS & PRODUCTS TAB */}
      {activeAdminTab === 'approvals' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
            <h3 className="text-lg font-black text-slate-900 mb-2">Merchant & Product Approval Center</h3>
            <p className="text-xs text-slate-500 mb-6">
              Review and approve seller accounts and product listings. Unapproved products display "Waiting for admin approval because payment hasn't been made or approved."
            </p>

            <div className="space-y-6">
              <div>
                <h4 className="font-bold text-slate-900 mb-3 text-sm">Registered Sellers ({registeredUsers.length})</h4>
                <div className="space-y-3">
                  {registeredUsers.map((u) => (
                    <div key={u.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center">
                          {u.full_name[0]}
                        </div>
                        <div>
                          <h5 className="font-bold text-slate-900">{u.full_name} ({u.role})</h5>
                          <p className="text-xs text-slate-500">{u.email || u.phone} • {u.business_name || 'No business name'}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                          u.is_seller_approved ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                        }`}>
                          {u.is_seller_approved ? 'Approved Merchant' : 'Awaiting Approval'}
                        </span>
                        <button
                          onClick={() => approveSellerAccount(u.id, !u.is_seller_approved)}
                          className={`px-4 py-2 rounded-xl text-xs font-bold text-white transition-all ${
                            u.is_seller_approved ? 'bg-rose-600 hover:bg-rose-700' : 'bg-emerald-600 hover:bg-emerald-700'
                          }`}
                        >
                          {u.is_seller_approved ? 'Revoke' : 'Approve Seller'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 mb-3 text-sm">All Product Listings ({products.length})</h4>
                <div className="space-y-3">
                  {products.map((p) => (
                    <div key={p.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
                      <div className="flex items-center space-x-4">
                        <img src={p.images[0]} alt="" className="w-12 h-12 rounded-xl object-cover" />
                        <div>
                          <h5 className="font-bold text-slate-900">{p.title}</h5>
                          <p className="text-xs text-slate-500">₦{p.price.toLocaleString()} • Category: {p.category}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                          p.is_approved ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                        }`}>
                          {p.is_approved ? 'Live & Approved' : 'Waiting for Admin Approval'}
                        </span>
                        <button
                          onClick={() => approveProductListing(p.id, !p.is_approved)}
                          className={`px-4 py-2 rounded-xl text-xs font-bold text-white transition-all ${
                            p.is_approved ? 'bg-amber-600 hover:bg-amber-700' : 'bg-blue-600 hover:bg-blue-700'
                          }`}
                        >
                          {p.is_approved ? 'Set Pending' : 'Approve Listing'}
                        </button>
                        <button
                          onClick={() => deleteProduct(p.id)}
                          className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-all"
                          title="Delete Product"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 1: ANALYTICS & TRAFFIC OVERVIEW */}
      {activeAdminTab === 'overview' && (
        <div className="space-y-6">
          {/* Traffic and Conversion Chart */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
              <div>
                <h3 className="text-lg font-black text-slate-900">Weekly Traffic & Buyer Engagement</h3>
                <p className="text-xs text-slate-500">Live visitor sessions and checkout conversions across all regions.</p>
              </div>
              <div className="flex items-center space-x-3 text-xs font-bold">
                <span className="flex items-center text-blue-600">
                  <span className="w-3 h-3 rounded-full bg-blue-600 mr-1.5" />
                  Visitor Sessions
                </span>
                <span className="flex items-center text-emerald-600">
                  <span className="w-3 h-3 rounded-full bg-emerald-500 mr-1.5" />
                  Orders Placed
                </span>
              </div>
            </div>

            {/* Custom Responsive SVG & Bar Chart */}
            <div className="h-64 flex items-end justify-between gap-2 sm:gap-6 pt-8 pb-2 border-b border-slate-100">
              {weeklyTraffic.map((item, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group">
                  <div className="text-[10px] text-slate-400 font-bold opacity-0 group-hover:opacity-100 transition-opacity mb-1">
                    {item.visits} visits ({item.sales} sales)
                  </div>
                  <div className="w-full max-w-[48px] bg-slate-100 rounded-2xl overflow-hidden h-full flex items-end">
                    <div
                      style={{ height: item.height }}
                      className="w-full bg-gradient-to-t from-blue-700 via-blue-500 to-indigo-500 rounded-2xl group-hover:from-blue-600 group-hover:to-indigo-400 transition-all duration-500"
                    />
                  </div>
                  <span className="text-xs font-bold text-slate-600 mt-2">{item.day}</span>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <span className="text-slate-400 font-bold block mb-1">Avg. Conversion Rate</span>
                <span className="text-lg font-black text-slate-900">4.82%</span>
                <span className="text-[11px] text-green-600 font-semibold block mt-0.5">↑ 1.2% this week</span>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <span className="text-slate-400 font-bold block mb-1">Total Active Sessions</span>
                <span className="text-lg font-black text-slate-900">18,750 Visitors</span>
                <span className="text-[11px] text-blue-600 font-semibold block mt-0.5">Top: Lagos, Abuja, Port Harcourt</span>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <span className="text-slate-400 font-bold block mb-1">Auto Escrow Fulfillment</span>
                <span className="text-lg font-black text-slate-900">99.4% On-Time</span>
                <span className="text-[11px] text-green-600 font-semibold block mt-0.5">Zero unresolved disputes</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ORDERS & SALES RECORDS EDITOR (WITH EDITING MODAL) */}
      {activeAdminTab === 'sales_editor' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-lg font-black text-slate-900">Sales Records & Delivery Tracking</h3>
              <p className="text-xs text-slate-500">
                Full super admin controls to modify sales records, adjust delivery tracking numbers, and release escrow settlements.
              </p>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="divide-y divide-slate-100 text-xs">
              {orders.map((ord) => {
                const isDelivered = ord.status === 'delivered';
                const isPaid = ord.payment_status === 'paid';

                return (
                  <div key={ord.id} className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4 hover:bg-slate-50 transition-colors">
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-black text-sm text-slate-900">{ord.order_number}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase ${
                          isDelivered ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                        }`}>
                          Status: {ord.status.replace('_', ' ')}
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase ${
                          isPaid ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          Payment: {ord.payment_status}
                        </span>
                      </div>

                      <p className="text-slate-600">
                        Buyer: <strong className="text-slate-900">{ord.customer_name}</strong> • Phone: <strong>{ord.customer_phone}</strong>
                      </p>

                      <p className="text-[11px] text-slate-500">
                        Delivery Address: {typeof ord.shipping_address === 'string' ? ord.shipping_address : `${ord.shipping_address.street}, ${ord.shipping_address.city}`}
                      </p>

                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 pt-1">
                        <span>Courier: <strong>{ord.courier_name || 'GIG Logistics'}</strong></span>
                        <span>•</span>
                        <span>Tracking Code: <strong className="font-mono text-blue-600">{ord.tracking_number}</strong></span>
                      </div>
                    </div>

                    {/* Financial Summary & Actions */}
                    <div className="flex flex-col sm:flex-row lg:flex-col items-start lg:items-end justify-between gap-3 shrink-0">
                      <div className="text-left lg:text-right">
                        <span className="font-black text-base text-slate-900 block">
                          Total: {formatCurrency(ord.total_amount, currency)}
                        </span>
                        <span className="text-[11px] text-slate-400 block font-mono">
                          Platform Fee: ₦{(ord.platform_fee || 500).toLocaleString()} • Payout: ₦{(ord.seller_payout_amount || ord.total_amount - 500).toLocaleString()}
                        </span>
                      </div>

                      <div className="flex items-center space-x-2">
                        {!isDelivered && (
                          <button
                            onClick={() => approveSellerPayout(ord.id)}
                            className="bg-green-600 hover:bg-green-700 text-white font-bold px-3 py-1.5 rounded-xl text-xs shadow-xs active:scale-95 flex items-center space-x-1"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Release Escrow Payout</span>
                          </button>
                        )}

                        <button
                          onClick={() => openOrderEditor(ord)}
                          className="bg-slate-900 hover:bg-black text-white font-bold px-3 py-1.5 rounded-xl text-xs shadow-xs active:scale-95 flex items-center space-x-1"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit Record</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: PLATFORM SETTINGS & AUTO-ACCEPT POSTS */}
      {activeAdminTab === 'settings' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-3xl space-y-6 text-xs">
          <div>
            <h3 className="text-lg font-black text-slate-900">Platform Management & Policy Configuration</h3>
            <p className="text-xs text-slate-500">Configure global platform fee schedules, profile details, and automatic post approval.</p>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-5">
            {/* Admin Profile Details */}
            <div className="space-y-4 pb-6 border-b border-slate-100">
              <h4 className="font-black text-sm text-slate-900 flex items-center space-x-2">
                <Camera className="w-4 h-4 text-blue-600" />
                <span>Super Admin Identity & Profile Photo</span>
              </h4>

              {/* Live Preview with Drag & Drop */}
              <div className="flex flex-col sm:flex-row items-center gap-5 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <div className="relative shrink-0">
                  <UserAvatar
                    src={adminAvatar}
                    alt="Admin Avatar"
                    className="w-20 h-20 rounded-2xl border-2 border-blue-600 shadow-md"
                  />
                  <div className="absolute -bottom-1 -right-1 bg-blue-600 text-white p-1 rounded-full text-xs shadow-xs">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                </div>

                <div className="flex-1 w-full space-y-1 text-center sm:text-left">
                  <span className="font-black text-sm text-slate-900 block">{adminName}</span>
                  <span className="text-xs text-slate-500 font-medium block">
                    Chief Platform Overseer • {platformLocation}
                  </span>
                  <span className="inline-flex items-center text-[10px] font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-full">
                    <Sparkles className="w-3 h-3 mr-1" />
                    Drag & Drop Enabled
                  </span>
                </div>
              </div>

              {/* Drag and Drop Image Uploader */}
              <ImageDropzone
                value={adminAvatar}
                onChange={setAdminAvatar}
                label="Upload / Drop Custom Admin Profile Picture"
                placeholderText="Drag & drop admin image here from PC or phone"
                helperText="Supports high-res PNG, JPG, WEBP. Drag file directly or click to pick."
              />

              {/* Neutral Preset Avatars for 1-Click Change */}
              <div className="space-y-2 pt-2">
                <span className="font-bold text-slate-700 text-xs block">Or Pick a Natural / Neutral Avatar Preset</span>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {NEUTRAL_AVATAR_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => setAdminAvatar(preset.url)}
                      className={`p-1.5 rounded-xl border flex flex-col items-center transition-all ${
                        adminAvatar === preset.url
                          ? 'border-blue-600 bg-blue-50/80 shadow-xs'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <img src={preset.url} alt={preset.name} className="w-10 h-10 rounded-lg object-cover mb-1" />
                      <span className="text-[9px] font-medium text-slate-600 line-clamp-1">{preset.name.split(' ')[0]}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Admin Name</label>
                  <input
                    type="text"
                    value={adminName}
                    onChange={(e) => setAdminName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Admin Email</label>
                  <input
                    type="email"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="font-bold text-slate-700 block mb-1">Platform Operations Primary Location</label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-rose-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={platformLocation}
                      onChange={(e) => setPlatformLocation(e.target.value)}
                      placeholder="e.g. Ankpa, Kogi State, Nigeria"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Developer Keys & External APIs Setup */}
            <div className="space-y-4 pb-6 border-b border-slate-100">
              <h4 className="font-black text-sm text-slate-900 flex items-center space-x-2">
                <Shield className="w-4 h-4 text-blue-600" />
                <span>Developer API Integrations (Supabase & Paystack)</span>
              </h4>
              <p className="text-[11px] text-slate-500 mb-2">
                Paste your API keys below to connect your external database and payment gateway to the application.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="font-bold text-slate-700 block mb-1">Supabase Project URL</label>
                  <input
                    type="url"
                    value={supabaseUrl}
                    onChange={(e) => setSupabaseUrl(e.target.value)}
                    placeholder="https://your-project.supabase.co"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="font-bold text-slate-700 block mb-1">Supabase Anon/Public Key</label>
                  <input
                    type="password"
                    value={supabaseKey}
                    onChange={(e) => setSupabaseKey(e.target.value)}
                    placeholder="eyJh..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="font-bold text-slate-700 block mb-1">Paystack Public Key</label>
                  <input
                    type="text"
                    value={paystackKey}
                    onChange={(e) => setPaystackKey(e.target.value)}
                    placeholder="pk_test_..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Auto-Accept First Time Sellers Settings */}
            <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-between">
              <div>
                <h5 className="font-bold text-blue-950">Auto-Approve First-Time Merchant Listings</h5>
                <p className="text-slate-600 text-[11px] mt-0.5">
                  When enabled, products and stores submitted by first-time registered sellers will immediately publish LIVE without requiring manual approval.
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0 ml-4">
                <input
                  type="checkbox"
                  checked={autoApprove}
                  onChange={(e) => setAutoApprove(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            {/* Platform Fees & WhatsApp Emergency Configuration */}
            <div className="space-y-3">
              <h4 className="font-black text-sm text-slate-900">Financial Fee & Security Rules</h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Base Platform Fee (NGN)</label>
                  <input
                    type="number"
                    value={baseFee}
                    onChange={(e) => setBaseFee(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">High-Value Threshold (NGN)</label>
                  <input
                    type="number"
                    value={highThreshold}
                    onChange={(e) => setHighThreshold(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">High-Value Fee (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={highFeePercent}
                    onChange={(e) => setHighFeePercent(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Official Phone Drop & Inquiry Line</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-blue-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={officialDropPhone}
                      onChange={(e) => {
                        setOfficialDropPhone(e.target.value);
                        setDropPhone(e.target.value);
                      }}
                      placeholder="0704409544"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block font-medium">Controls where all customer drops & website inquiries route to (Default: 0704409544).</span>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Default WhatsApp Emergency & AI Dispatch</label>
                  <div className="relative">
                    <MessageSquare className="w-4 h-4 text-green-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={whatsappNum}
                      onChange={(e) => setWhatsappNum(e.target.value)}
                      placeholder="0704409544"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block font-medium">Automated WhatsApp AI guardian target for high-value orders & alerts.</span>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-3 rounded-xl shadow-md transition-all active:scale-95 flex items-center space-x-2"
            >
              <Save className="w-4 h-4" />
              <span>Save Admin Settings</span>
            </button>

            {/* Factory Reset Section */}
            <div className="pt-6 border-t border-slate-200 mt-6 space-y-3">
              <h4 className="font-black text-sm text-rose-700 flex items-center space-x-2">
                <RefreshCw className="w-4 h-4 text-rose-600" />
                <span>Master Factory Reset</span>
              </h4>
              <p className="text-[11px] text-slate-500">
                Restores application to initial factory default state, clearing custom cache and resetting test data.
              </p>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('WARNING: Are you sure you want to perform a full factory reset? All app data will be restored to default.')) {
                    factoryResetApp();
                  }
                }}
                className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-5 py-2.5 rounded-xl text-xs shadow-md transition-all active:scale-95 flex items-center space-x-2"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Perform Factory Reset</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 4: AI GUARDIAN WHATSAPP DISPATCH LOGS */}
      {activeAdminTab === 'ai_whatsapp' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-green-950 text-white p-6 sm:p-8 rounded-3xl border border-green-600/40 shadow-xl">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-2xl bg-green-500 text-slate-950 flex items-center justify-center font-black">
                <MessageSquare className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="bg-green-500/20 text-green-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-green-500/30">
                    Live Overseer Connected
                  </span>
                  <span className="text-xs text-slate-300">Default Target: {whatsappNum}</span>
                </div>
                <h3 className="text-lg font-black text-white mt-0.5">AI Marketplace Security Overseer</h3>
                <p className="text-xs text-slate-300">
                  Monitors orders {`>`} ₦100,000, dispute requests, new merchant setups, and automatically alerts your phone.
                </p>
              </div>
            </div>

            {/* Test WhatsApp Dispatcher */}
            <form onSubmit={handleSendTestAiWhatsapp} className="mt-6 pt-4 border-t border-white/10 flex gap-2">
              <input
                type="text"
                value={testAiMsg}
                onChange={(e) => setTestAiMsg(e.target.value)}
                placeholder="Test AI security broadcast message to WhatsApp..."
                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none"
              />
              <button
                type="submit"
                className="bg-green-500 hover:bg-green-400 text-slate-950 font-black px-4 py-2 rounded-xl text-xs shrink-0 flex items-center space-x-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send Alert</span>
              </button>
            </form>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-100 font-bold text-xs text-slate-700">
              Recent Automated AI Dispatches to WhatsApp ({whatsappNum})
            </div>
            <div className="divide-y divide-slate-100 text-xs">
              {aiAlerts.map((alert) => (
                <div key={alert.id} className="p-4 flex items-start space-x-3.5">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                    alert.severity === 'high' ? 'bg-rose-100 text-rose-600' : 'bg-green-100 text-green-700'
                  }`}>
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">{alert.category.replace(/_/g, ' ')}</span>
                      <span className="text-[11px] text-slate-400">{alert.timestamp}</span>
                    </div>
                    <p className="text-slate-600 mt-1 leading-relaxed">{alert.message}</p>
                    <span className="text-[10px] text-green-600 font-semibold mt-1 inline-flex items-center">
                      <Check className="w-3 h-3 mr-1" />
                      Dispatched to WhatsApp ({whatsappNum})
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB: TEAM LOGIN */}
      {activeAdminTab === 'team_login' && (
        <div className="max-w-md mx-auto py-10">
          <h3 className="text-xl font-black text-slate-900 mb-6 text-center">Staff & Team Login</h3>
          <TeamLogin />
        </div>
      )}

      {/* TAB 5: USERS & BUSINESS ACCOUNTS */}
      {activeAdminTab === 'users' && (
        <div className="space-y-4">
          <h3 className="text-lg font-black text-slate-900">User Accounts & Merchant Roles</h3>
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="divide-y divide-slate-100 text-xs">
              {registeredUsers.map((usr) => (
                <div key={usr.id} className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center space-x-3.5">
                    <UserAvatar
                      src={usr.avatar_url}
                      alt={usr.full_name}
                      className="w-12 h-12 rounded-2xl border border-slate-200"
                    />
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-slate-900 text-sm">{usr.full_name}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase ${
                          usr.role === 'admin' ? 'bg-purple-100 text-purple-800' :
                          usr.role === 'seller' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-800'
                        }`}>
                          {usr.role}
                        </span>
                      </div>
                      <p className="text-slate-500 text-[11px]">
                        Email: {usr.email || 'N/A'} • Phone: {usr.phone || 'N/A'}
                      </p>
                      {usr.business_name && (
                        <p className="text-blue-600 font-semibold text-[11px]">
                          Business: {usr.business_name}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <span className="font-mono font-bold text-slate-700">
                      Balance: ₦{(usr.wallet_balance || 0).toLocaleString()}
                    </span>

                    <button
                      onClick={() => {
                        const newRole = usr.role === 'seller' ? 'customer' : 'seller';
                        updateUserRoleAndBalance(usr.id, newRole);
                      }}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 font-bold hover:bg-slate-50 text-[11px]"
                    >
                      Toggle {usr.role === 'seller' ? 'to Customer' : 'to Seller'}
                    </button>

                    <button
                      onClick={() => {
                        deleteRegisteredUser(usr.id);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 hover:bg-rose-100 font-bold text-[11px] flex items-center space-x-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: CATALOG & SERVICES MODERATION */}
      {activeAdminTab === 'inventory' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-black text-slate-900">Marketplace Catalog & Services Moderation</h3>
              <p className="text-xs text-slate-500">
                Manage all live retail products and professional services posted across the platform. You can delete or moderate any service directly from here.
              </p>
            </div>

            {/* Catalog Type Switcher */}
            <div className="flex bg-slate-100 p-1 rounded-2xl text-xs font-bold shrink-0 self-start sm:self-auto">
              <button
                type="button"
                onClick={() => setCatalogTab('products')}
                className={`px-4 py-2 rounded-xl transition-all ${
                  catalogTab === 'products'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                Products ({products.length})
              </button>
              <button
                type="button"
                onClick={() => setCatalogTab('services')}
                className={`px-4 py-2 rounded-xl transition-all ${
                  catalogTab === 'services'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                Services ({services.length})
              </button>
            </div>
          </div>

          {/* SUB-TAB: PRODUCTS */}
          {catalogTab === 'products' && (
            <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-xs font-bold text-slate-700">
                <span>Active Physical & Digital Goods ({products.length})</span>
                <span className="text-slate-400 font-normal">Instant live updates</span>
              </div>
              <div className="divide-y divide-slate-100 text-xs">
                {products.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 font-medium">No products listed in catalog.</div>
                ) : (
                  products.map((prod) => (
                    <div key={prod.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/50 transition-colors">
                      <div className="flex items-center space-x-3.5">
                        <img src={prod.images[0]} alt={prod.title} className="w-14 h-14 rounded-2xl object-cover border border-slate-200 shrink-0" />
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-bold text-slate-900 text-sm">{prod.title}</span>
                            {prod.is_boosted && (
                              <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-bold">Featured</span>
                            )}
                          </div>
                          <span className="text-slate-500 block text-xs mt-0.5">
                            {formatCurrency(prod.price, currency)} • Stock: {prod.stock} {prod.store?.name ? `• Store: ${prod.store.name}` : ''}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => deleteProduct(prod.id)}
                        className="text-rose-600 hover:bg-rose-50 px-3.5 py-2 rounded-xl border border-rose-200 font-bold self-end sm:self-auto flex items-center space-x-1.5 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Remove Product</span>
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* SUB-TAB: SERVICES (MODERATE & DELETE SERVICES) */}
          {catalogTab === 'services' && (
            <div className="space-y-4">
              <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
                <div className="p-4 bg-indigo-50/60 border-b border-indigo-100 flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-2">
                    <Briefcase className="w-4 h-4 text-indigo-600" />
                    <span className="font-black text-indigo-950">Active Professional Services ({services.length})</span>
                  </div>
                  <span className="text-indigo-600 text-[11px] font-bold">Delete any service to remove from website immediately</span>
                </div>

                <div className="divide-y divide-slate-100 text-xs">
                  {services.length === 0 ? (
                    <div className="p-12 text-center text-slate-400 font-medium">
                      No services currently listed. Professional service providers can list them from the Sell portal.
                    </div>
                  ) : (
                    services.map((srv) => (
                      <div key={srv.id} className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50/50 transition-colors">
                        <div className="flex items-start sm:items-center space-x-4">
                          <img
                            src={srv.image}
                            alt={srv.title}
                            className="w-16 h-16 rounded-2xl object-cover border border-slate-200 shrink-0 shadow-xs"
                          />
                          <div className="space-y-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-bold text-slate-900 text-sm">{srv.title}</span>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200">
                                {srv.category}
                              </span>
                              {srv.is_verified && (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-green-50 text-green-700 flex items-center">
                                  <ShieldCheck className="w-3 h-3 mr-0.5" /> Verified
                                </span>
                              )}
                            </div>

                            <p className="text-xs text-slate-500 line-clamp-1 max-w-xl">{srv.description}</p>

                            <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-600 pt-0.5">
                              <span className="font-black text-blue-600 text-xs">
                                {formatCurrency(srv.price, currency)} <span className="font-normal text-slate-400">/{srv.pricing_unit}</span>
                              </span>
                              <span>• Provider: <strong className="text-slate-800">{srv.provider_name}</strong></span>
                              <span className="flex items-center">
                                <MapPin className="w-3 h-3 text-slate-400 mr-0.5" />
                                {srv.location}
                              </span>
                              <span>• Rating: ⭐ {srv.rating} ({srv.reviews_count} reviews)</span>
                            </div>
                          </div>
                        </div>

                        {/* DELETE SERVICE BUTTON */}
                        <div className="flex items-center space-x-2 self-end md:self-auto shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              deleteService(srv.id);
                            }}
                            className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 font-bold px-4 py-2.5 rounded-xl transition-all flex items-center space-x-1.5 shadow-xs active:scale-95 text-xs"
                            title="Delete this service from the website"
                          >
                            <Trash2 className="w-4 h-4 text-rose-600" />
                            <span>Delete Service</span>
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* EDIT SALES RECORD MODAL */}
      {editingOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-lg rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95 my-auto max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center space-x-2">
                <Edit3 className="w-5 h-5 text-blue-600" />
                <h3 className="text-lg font-black text-slate-900">Edit Sales Record: {editingOrder.order_number}</h3>
              </div>
              <button
                onClick={() => setEditingOrder(null)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveOrderEdit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Customer Full Name</label>
                  <input
                    type="text"
                    value={editCustomerName}
                    onChange={(e) => setEditCustomerName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Customer Phone</label>
                  <input
                    type="text"
                    value={editCustomerPhone}
                    onChange={(e) => setEditCustomerPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Total Amount (NGN)</label>
                  <input
                    type="number"
                    value={editTotalAmount}
                    onChange={(e) => setEditTotalAmount(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Delivery Fee (NGN)</label>
                  <input
                    type="number"
                    value={editDeliveryFee}
                    onChange={(e) => setEditDeliveryFee(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Platform Fee (NGN)</label>
                  <input
                    type="number"
                    value={editPlatformFee}
                    onChange={(e) => setEditPlatformFee(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Order Delivery Status</label>
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  >
                    <option value="paid">Paid & Preparing</option>
                    <option value="in_transit">In Transit (Dispatched)</option>
                    <option value="delivered">Delivered to Customer</option>
                    <option value="cancelled">Cancelled / Refunded</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Payment Status</label>
                  <select
                    value={editPaymentStatus}
                    onChange={(e) => setEditPaymentStatus(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  >
                    <option value="paid">Paid</option>
                    <option value="pending">Pending Payment</option>
                    <option value="failed">Failed</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Tracking Number</label>
                  <input
                    type="text"
                    value={editTrackingNumber}
                    onChange={(e) => setEditTrackingNumber(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Courier Service</label>
                  <input
                    type="text"
                    value={editCourierName}
                    onChange={(e) => setEditCourierName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingOrder(null)}
                  className="flex-1 bg-slate-100 text-slate-700 font-bold py-3 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-md"
                >
                  Save Record Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
