import React, { useState } from 'react';
import { useStore } from '../store';
import { Product, ServiceItem, Store, BankAccountDetails, CurrencyCode } from '../types';
import { formatCurrency } from '../lib/utils';
import { ImageDropzone } from '../components/ImageDropzone';
import { 
  PackagePlus, 
  Store as StoreIcon, 
  Sparkles, 
  Briefcase, 
  TrendingUp, 
  ShoppingBag, 
  DollarSign, 
  ShieldCheck, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Truck,
  Building,
  CreditCard,
  Layers,
  ArrowRight,
  AlertCircle,
  HelpCircle,
  Clock,
  MapPin,
  Lock
} from 'lucide-react';

export default function Sell() {
  const { 
    products, 
    stores, 
    services, 
    orders, 
    addProduct, 
    addStore, 
    addService, 
    updateService,
    deleteService,
    deleteProduct, 
    user, 
    isAuthenticated,
    currency,
    recordAdminFee,
    updateUserProfile,
    addToast
  } = useStore();

  if (!isAuthenticated) {
    return (
      <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 pt-24 min-h-screen">
        <div className="bg-white rounded-3xl p-8 sm:p-12 text-center border border-slate-200 shadow-sm flex flex-col items-center justify-center">
          <div className="w-20 h-20 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mb-6">
            <Lock className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-black text-slate-900 mb-4">Seller Account Required</h2>
          <p className="text-slate-500 mb-8 max-w-md mx-auto leading-relaxed">
            Please create an account or sign in to access the Mega Marketplace seller dashboard. You need an active profile to manage inventory and receive payouts.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button 
              onClick={() => window.location.href = '/account?mode=signup&role=seller'}
              className="px-6 py-3.5 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all shadow-md shadow-blue-600/20 active:scale-95 flex items-center space-x-2 text-sm"
            >
              <span>Create Seller Account & Begin Sales</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button 
              onClick={() => window.location.href = '/account?mode=login'}
              className="px-6 py-3.5 bg-slate-100 text-slate-800 font-bold rounded-2xl hover:bg-slate-200 transition-all text-sm"
            >
              Existing Seller Sign In
            </button>
          </div>
        </div>
      </div>
    );
  }

  const [activeTab, setActiveTab] = useState<'manage' | 'products' | 'services' | 'store' | 'payouts'>('manage');
  const [activeModal, setActiveModal] = useState<'product' | 'service' | 'store' | null>(null);

  // New Product Form State
  const [newTitle, setNewTitle] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [newDiscountPrice, setNewDiscountPrice] = useState('');
  const [newCategory, setNewCategory] = useState('Electronics');
  const [newCurrency, setNewCurrency] = useState<CurrencyCode>('NGN');
  const [newStock, setNewStock] = useState('10');
  const [newDescription, setNewDescription] = useState('');
  const [newImageUrl, setNewImageUrl] = useState('');
  const [newDeliveryType, setNewDeliveryType] = useState<'doorstep' | 'pickup' | 'nationwide'>('doorstep');
  const [newDeliveryNotes, setNewDeliveryNotes] = useState('');
  const [newListingType, setNewListingType] = useState<'product' | 'service' | 'job' | 'business_listing' | 'sales_agent'>('product');
  const [newWebsiteUrl, setNewWebsiteUrl] = useState('');
  const [newVideoUrl, setNewVideoUrl] = useState('');
  const [newContactWhatsapp, setNewContactWhatsapp] = useState(user.phone || '');
  const [newPosterBank, setNewPosterBank] = useState(user.bank_details?.bank_name || 'Guaranty Trust Bank (GTBank)');
  const [newPosterAccountNumber, setNewPosterAccountNumber] = useState(user.bank_details?.account_number || '');
  const [newPosterAccountName, setNewPosterAccountName] = useState(user.bank_details?.account_name || user.full_name || '');
  const [acceptListingFee, setAcceptListingFee] = useState(true);
  const [boostUpperProduct, setBoostUpperProduct] = useState(false);

  // New Service Form State
  const [serviceTitle, setServiceTitle] = useState('');
  const [serviceCategory, setServiceCategory] = useState('Tech & Digital');
  const [servicePrice, setServicePrice] = useState('');
  const [servicePricingUnit, setServicePricingUnit] = useState('per project');
  const [serviceDesc, setServiceDesc] = useState('');
  const [serviceLocation, setServiceLocation] = useState('Lagos & Remote');
  const [serviceImage, setServiceImage] = useState('');

  // New Store / Business Form State
  const [storeName, setStoreName] = useState(user.business_name || '');
  const [storeDesc, setStoreDesc] = useState('');
  const [storeLocation, setStoreLocation] = useState('Lagos, Nigeria');
  const [storeBrandColor, setStoreBrandColor] = useState('from-blue-700 via-indigo-900 to-slate-950');
  const [bankName, setBankName] = useState(user.bank_details?.bank_name || 'Guaranty Trust Bank (GTBank)');
  const [accountNumber, setAccountNumber] = useState(user.bank_details?.account_number || '');
  const [accountName, setAccountName] = useState(user.bank_details?.account_name || user.full_name);

  // Stats Calculations
  const sellerProducts = products.filter(p => p.store?.owner_id === user.id);
  const totalStockCount = sellerProducts.reduce((acc, p) => acc + p.stock, 0);
  const sellerOrders = orders;
  const totalSellerSales = sellerOrders.reduce((acc, ord) => acc + (ord.seller_payout_amount || ord.total_amount), 0);
  const pendingEscrow = sellerOrders
    .filter(o => o.status !== 'delivered' && o.status !== 'cancelled')
    .reduce((acc, ord) => acc + (ord.seller_payout_amount || ord.total_amount), 0);

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newPrice) {
      addToast('Please provide product title and selling price.', 'error');
      return;
    }

    const slug = newTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') + '-' + Date.now().toString().slice(-4);
    
    const created: Product = {
      id: `prod-${Date.now()}`,
      store_id: stores[0]?.id || 'store-1',
      title: newTitle,
      slug,
      category: newCategory,
      description: newDescription || 'Premium quality verified item directly from store inventory.',
      price: parseFloat(newPrice),
      currency: newCurrency,
      discount_price: newDiscountPrice ? parseFloat(newDiscountPrice) : undefined,
      stock: parseInt(newStock) || 5,
      delivery_type: newDeliveryType,
      delivery_notes: newDeliveryNotes || 'Dispatched in security protective packaging with tracking.',
      website_url: newWebsiteUrl.trim() || undefined,
      video_url: newVideoUrl.trim() || undefined,
      listing_type: newListingType,
      contact_whatsapp: newContactWhatsapp.trim() || user.phone || '234704409544',
      poster_account_bank: newPosterBank || user.bank_details?.bank_name || 'Guaranty Trust Bank (GTBank)',
      poster_account_number: newPosterAccountNumber || user.bank_details?.account_number || '0123456789',
      poster_account_name: newPosterAccountName || user.bank_details?.account_name || user.full_name,
      images: [
        newImageUrl || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=1000'
      ],
      is_published: false, // Strict approval enforcement
      is_approved: false,  // Strict approval enforcement
      is_boosted: boostUpperProduct,
      is_featured: boostUpperProduct,
      paid_admin_fee: boostUpperProduct ? 550 : 50,
      rating: 5.0,
      reviews_count: 1,
      store: stores[0] || {
        id: 'store-1',
        owner_id: user.id,
        name: user.business_name || user.full_name + ' Store',
        description: 'Verified Merchant Outlet',
        is_verified: true,
        status: 'active',
        created_at: new Date().toISOString()
      },
      created_at: new Date().toISOString(),
    };

    // Deduct/Record platform post charge (₦50 standard or ₦550 boosted) to admin revenue
    const feeCharged = boostUpperProduct ? 550 : 50;
    recordAdminFee(feeCharged, `Listing Charge: ${newTitle} (${boostUpperProduct ? 'Boosted Upper' : 'Standard'})`);
    addProduct(created);
    addToast('Product submitted! Awaiting Money Checker/Admin payment verification.', 'success');
    setActiveModal(null);
    setNewTitle('');
    setNewPrice('');
    setNewDiscountPrice('');
    setNewDescription('');
    setNewImageUrl('');
    setNewDeliveryNotes('');
    setNewWebsiteUrl('');
    setNewVideoUrl('');
    setNewContactWhatsapp('');
    setNewPosterAccountNumber('');
    setNewPosterAccountName('');
    setBoostUpperProduct(false);
  };

  const handleCreateService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceTitle || !servicePrice) {
      addToast('Please enter service title and price.', 'error');
      return;
    }

    const createdService: ServiceItem = {
      id: `srv-${Date.now()}`,
      provider_name: user.business_name || user.full_name,
      provider_avatar: user.avatar_url || '',
      title: serviceTitle,
      category: serviceCategory,
      description: serviceDesc || 'Professional verified commercial and individual service offerings.',
      price: parseFloat(servicePrice),
      pricing_unit: servicePricingUnit,
      location: serviceLocation,
      rating: 5.0,
      reviews_count: 1,
      is_verified: true,
      image: serviceImage || 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=1000',
      available_days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    };

    addService(createdService);
    setActiveModal(null);
    setServiceTitle('');
    setServicePrice('');
    setServiceDesc('');
  };

  const handleCreateStore = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeName) {
      addToast('Please enter your business store name.', 'error');
      return;
    }

    const createdStore: Store = {
      id: `store-${Date.now()}`,
      owner_id: user.id,
      name: storeName,
      description: storeDesc || 'Authorized supplier of authentic merchandise.',
      logo_url: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&q=80&w=300',
      cover_url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=1200',
      is_verified: true,
      location: storeLocation,
      brand_color: storeBrandColor,
      status: 'active',
      rating: 5.0,
      reviews_count: 0,
      followers_count: 1,
      created_at: new Date().toISOString(),
    };

    // Update user profile bank and business details
    const bankDetails: BankAccountDetails = {
      bank_name: bankName,
      account_number: accountNumber,
      account_name: accountName,
      is_verified: true
    };

    updateUserProfile({
      business_name: storeName,
      bank_details: bankDetails,
      role: 'seller'
    });

    addStore(createdStore);
    setActiveModal(null);
  };

  const nigerianBanks = [
    'Access Bank',
    'Guaranty Trust Bank (GTBank)',
    'Zenith Bank',
    'United Bank for Africa (UBA)',
    'First Bank of Nigeria',
    'Kuda Microfinance Bank',
    'Opay / Paycom',
    'Moniepoint Microfinance Bank',
    'Stanbic IBTC Bank',
    'Fidelity Bank'
  ];

  return (
    <div className="py-4 md:py-6 space-y-8 max-w-7xl mx-auto">
      {/* Seller Portal Header Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-blue-950 to-indigo-950 text-white rounded-3xl p-6 sm:p-10 border border-blue-600/30 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center space-x-2 bg-blue-500/20 backdrop-blur-xs border border-blue-400/30 px-3 py-1 rounded-full text-xs font-bold text-blue-200">
              <StoreIcon className="w-3.5 h-3.5 text-blue-300" />
              <span>Merchant & Business Command Center</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-black tracking-tight">
              Sell Products, Offer Services & Receive Direct Payouts
            </h1>
            <p className="text-xs sm:text-sm text-blue-200/90 leading-relaxed font-medium">
              Manage your verified inventory, configure delivery specifications, set up direct bank settlements, and access 100% automated escrow protection.
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap gap-2.5 shrink-0">
            <button
              onClick={() => setActiveModal('product')}
              className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-3 rounded-2xl text-xs shadow-lg shadow-blue-600/20 active:scale-95 transition-all flex items-center space-x-1.5"
            >
              <PackagePlus className="w-4 h-4" />
              <span>+ List Product</span>
            </button>

            <button
              onClick={() => setActiveModal('service')}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-4 py-3 rounded-2xl text-xs shadow-md active:scale-95 transition-all flex items-center space-x-1.5"
            >
              <Briefcase className="w-4 h-4" />
              <span>+ Offer Service</span>
            </button>

            <button
              onClick={() => setActiveModal('store')}
              className="bg-white hover:bg-slate-100 text-slate-950 font-bold px-4 py-3 rounded-2xl text-xs shadow-md active:scale-95 transition-all flex items-center space-x-1.5"
            >
              <Building className="w-4 h-4 text-blue-600" />
              <span>Create Store</span>
            </button>
          </div>
        </div>
      </div>

      {/* Seller Financial KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-bold block mb-1">Total Merchant Revenue</span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 leading-none">
              {formatCurrency(totalSellerSales, currency)}
            </span>
            <span className="text-[11px] text-green-600 font-semibold block mt-1.5">100% Escrow Protected</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-bold block mb-1">Pending Escrow Release</span>
            <span className="text-xl sm:text-2xl font-black text-amber-600 leading-none">
              {formatCurrency(pendingEscrow, currency)}
            </span>
            <span className="text-[11px] text-slate-400 block mt-1.5">Auto-release upon delivery</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-bold block mb-1">Live Active Listings</span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 leading-none">
              {sellerProducts.length} Items
            </span>
            <span className="text-[11px] text-slate-500 block mt-1.5">{totalStockCount} units available</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <ShoppingBag className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-bold block mb-1">Direct Settlement Bank</span>
            <span className="text-xs font-bold text-slate-900 leading-tight block truncate max-w-[130px]">
              {user.bank_details?.bank_name || 'GTBank'}
            </span>
            <span className="text-[11px] text-green-600 font-bold block mt-1.5">
              Acct: ••••{user.bank_details?.account_number ? user.bank_details.account_number.slice(-4) : '6789'}
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-green-50 text-green-600 flex items-center justify-center">
            <CreditCard className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="flex bg-white p-1.5 rounded-2xl border border-slate-200 text-xs font-bold space-x-1 overflow-x-auto">
        <button
          onClick={() => setActiveTab('manage')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'manage' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Catalog & Inventory ({products.length})
        </button>
        <button
          onClick={() => setActiveTab('services')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'services' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Services Offered ({services.length})
        </button>
        <button
          onClick={() => setActiveTab('store')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'store' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          My Store & Bank Payout Details
        </button>
        <button
          onClick={() => setActiveTab('payouts')}
          className={`px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'payouts' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Orders & Bank Ledger ({orders.length})
        </button>
      </div>

      {/* TAB 1: MANAGE PRODUCTS CATALOG */}
      {activeTab === 'manage' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-black text-lg text-slate-900">Your Active Products</h3>
            <button
              onClick={() => setActiveModal('product')}
              className="bg-blue-600 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-xs flex items-center space-x-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New Listing</span>
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="divide-y divide-slate-100">
              {products.map((prod) => (
                <div key={prod.id} className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <img
                      src={prod.images[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=300'}
                      alt={prod.title}
                      className="w-16 h-16 rounded-2xl object-cover border border-slate-200 shrink-0 bg-slate-100"
                    />
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-50 text-blue-700 rounded-md">
                          {prod.category}
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-green-50 text-green-700 rounded-md flex items-center space-x-1">
                          <Truck className="w-3 h-3" />
                          <span className="capitalize">{prod.delivery_type || 'doorstep'}</span>
                        </span>
                      </div>
                      <h4 className="font-bold text-sm text-slate-900 mt-1 line-clamp-1">{prod.title}</h4>
                      <div className="flex items-center space-x-2 text-xs text-slate-500 mt-0.5">
                        <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
                          Seller: {prod.store?.name || user?.business_name || user?.full_name || "Verified Merchant"}
                        </span>
                        <span>•</span>
                        <span className="font-black text-slate-900">
                          {formatCurrency(prod.discount_price || prod.price, currency)}
                        </span>
                        <span>•</span>
                        <span>Stock: <strong className="text-slate-800">{prod.stock} units</strong></span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1.5 line-clamp-2 max-w-xl bg-slate-50/80 p-2 rounded-xl border border-slate-100">
                        <span className="font-bold text-slate-700">Description: </span>
                        {prod.description || "Premium merchant product listed for instant ordering."}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 self-end sm:self-center">
                    <button
                      onClick={() => deleteProduct(prod.id)}
                      className="p-2 rounded-xl text-rose-600 hover:bg-rose-50 border border-rose-200 text-xs font-bold flex items-center space-x-1 transition-colors"
                      title="Remove product"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SERVICES OFFERED */}
      {activeTab === 'services' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-black text-lg text-slate-900">Commercial & Professional Services</h3>
            <button
              onClick={() => setActiveModal('service')}
              className="bg-indigo-600 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-xs flex items-center space-x-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>List New Service</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {services.map((srv) => (
              <div key={srv.id} className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
                <div>
                  <img src={srv.image} alt={srv.title} className="w-full h-36 object-cover rounded-2xl mb-3" />
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded-md">
                    {srv.category}
                  </span>
                  <h4 className="font-bold text-sm text-slate-900 mt-1">{srv.title}</h4>
                  <p className="text-xs text-slate-500 line-clamp-2 mt-1">{srv.description}</p>
                </div>
                <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="font-black text-sm text-blue-600 block">
                      {formatCurrency(srv.price, currency)} <span className="text-[10px] text-slate-400 font-normal">/{srv.pricing_unit}</span>
                    </span>
                    <span className="text-[11px] text-slate-500 font-medium flex items-center mt-0.5">
                      <MapPin className="w-3 h-3 mr-0.5 text-slate-400" />
                      {srv.location}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => deleteService(srv.id)}
                    className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-all border border-rose-200 shadow-xs"
                    title="Delete service listing"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: STORE & BANK PAYOUT SETTINGS */}
      {activeTab === 'store' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-3xl space-y-6">
          <div>
            <h3 className="text-lg font-black text-slate-900">Direct Bank Settlement & Store Profile</h3>
            <p className="text-xs text-slate-500">
              When customers complete orders, escrow payouts are dispatched directly into this verified Nigerian bank account.
            </p>
          </div>

          <form onSubmit={handleCreateStore} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Business Store Name</label>
                <input
                  type="text"
                  required
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  placeholder="e.g. Apex Tech & Gadgets Ltd"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Store Physical Location</label>
                <input
                  type="text"
                  value={storeLocation}
                  onChange={(e) => setStoreLocation(e.target.value)}
                  placeholder="e.g. Victoria Island, Lagos"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Store Description / Specialty</label>
              <textarea
                rows={2}
                value={storeDesc}
                onChange={(e) => setStoreDesc(e.target.value)}
                placeholder="Describe your brand and product authenticity guarantee..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>

            {/* Direct Bank Account Details for Payouts */}
            <div className="pt-4 border-t border-slate-100 space-y-3">
              <div className="flex items-center space-x-2 text-slate-900 font-black text-sm">
                <CreditCard className="w-4 h-4 text-blue-600" />
                <span>Direct Bank Payout Details (NUBAN)</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Bank Name</label>
                  <select
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  >
                    {nigerianBanks.map((b, idx) => (
                      <option key={idx} value={b}>{b}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">10-Digit Account Number</label>
                  <input
                    type="text"
                    maxLength={10}
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    placeholder="0123456789"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-mono font-bold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Account Beneficiary Name</label>
                  <input
                    type="text"
                    value={accountName}
                    onChange={(e) => setAccountName(e.target.value)}
                    placeholder="Account Name"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-[11px] font-semibold flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Direct Bank Account is automatically verified with Central Bank NIBSS settlement network.</span>
              </div>
            </div>

            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-3.5 rounded-xl shadow-md transition-all active:scale-95"
            >
              Save Store & Bank Details
            </button>
          </form>
        </div>
      )}

      {/* TAB 4: ORDERS & BANK LEDGER */}
      {activeTab === 'payouts' && (
        <div className="space-y-4">
          <h3 className="font-black text-lg text-slate-900">Seller Sales & Bank Settlement Ledger</h3>
          
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="divide-y divide-slate-100">
              {orders.map((ord) => (
                <div key={ord.id} className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-black text-slate-900 text-sm">{ord.order_number}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase ${
                        ord.status === 'delivered' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {ord.status.replace('_', ' ')}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 font-medium">
                      Customer: <strong>{ord.customer_name}</strong> ({ord.customer_phone})
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Destination: {typeof ord.shipping_address === 'string' ? ord.shipping_address : `${ord.shipping_address.street}, ${ord.shipping_address.city}`}
                    </p>
                  </div>

                  <div className="text-right flex flex-col items-end">
                    <span className="text-xs text-slate-400">Merchant Net Payout</span>
                    <span className="font-black text-base text-green-700">
                      {formatCurrency(ord.seller_payout_amount || (ord.total_amount - 500), currency)}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">Platform Fee: ₦{(ord.platform_fee || 500).toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: LIST NEW PRODUCT WITH DELIVERY SPECIFICATIONS */}
      {activeModal === 'product' && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-xl rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95 my-auto max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                  <PackagePlus className="w-4 h-4" />
                </div>
                <h3 className="text-lg font-black text-slate-900">List New Product on Marketplace</h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Product Title *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Apple MacBook Pro M3 or Nike Air Max"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Price (NGN) *</label>
                  <input
                    type="number"
                    required
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    placeholder="150000"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Currency *</label>
                  <select
                    value={newCurrency}
                    onChange={(e) => setNewCurrency(e.target.value as CurrencyCode)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  >
                    <option value="NGN">NGN</option>
                    <option value="USD">USD</option>
                    <option value="GBP">GBP</option>
                    <option value="EUR">EUR</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Discount Price (Optional)</label>
                  <input
                    type="number"
                    value={newDiscountPrice}
                    onChange={(e) => setNewDiscountPrice(e.target.value)}
                    placeholder="135000"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Stock Units</label>
                  <input
                    type="number"
                    value={newStock}
                    onChange={(e) => setNewStock(e.target.value)}
                    placeholder="10"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  >
                    <option value="Electronics">Electronics & Computing</option>
                    <option value="Fashion">Fashion & Footwear</option>
                    <option value="Home & Living">Home, Decor & Solar</option>
                    <option value="Automotive">Automotive & Accessories</option>
                    <option value="Beauty">Beauty & Personal Care</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Delivery Fulfillment Type</label>
                  <select
                    value={newDeliveryType}
                    onChange={(e) => setNewDeliveryType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  >
                    <option value="doorstep">Doorstep Express Delivery</option>
                    <option value="nationwide">Nationwide Courier Dispatch</option>
                    <option value="pickup">Store Pick-up Location</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-2">Product Image (Drag & Drop)</label>
                <ImageDropzone 
                  onChange={setNewImageUrl} 
                  value={newImageUrl} 
                  label="Drag & Drop Product Image Here"
                  className="h-48 w-full"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Delivery Instructions / Specifications</label>
                <input
                  type="text"
                  value={newDeliveryNotes}
                  onChange={(e) => setNewDeliveryNotes(e.target.value)}
                  placeholder="e.g. Delivery requires security signature. Customer specify color preference."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Listing Type</label>
                  <select
                    value={newListingType}
                    onChange={(e) => setNewListingType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  >
                    <option value="product">Retail Product Inventory</option>
                    <option value="job">Job Vacancy / Remote Work Offer</option>
                    <option value="business_listing">Registered Business Profile</option>
                    <option value="sales_agent">Social Sales Agent Offering</option>
                    <option value="service">Professional Service</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Contact WhatsApp for Applicants/Buyers</label>
                  <input
                    type="tel"
                    value={newContactWhatsapp}
                    onChange={(e) => setNewContactWhatsapp(e.target.value)}
                    placeholder="+234 812 000 3344"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">External Website URL (Optional)</label>
                <input
                  type="url"
                  value={newWebsiteUrl}
                  onChange={(e) => setNewWebsiteUrl(e.target.value)}
                  placeholder="https://yourbrandstore.com"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Product Video URL (Optional)</label>
                <input
                  type="url"
                  value={newVideoUrl}
                  onChange={(e) => setNewVideoUrl(e.target.value)}
                  placeholder="https://youtube.com/watch?v=..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
                <span className="text-[10px] text-slate-500 mt-0.5 block">
                  Add a link to your product video demonstration.
                </span>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Product Description</label>
                <textarea
                  rows={3}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Detail product features, specifications, and warranty..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              {/* SELLER DIRECT RECEIVING BANK ACCOUNT FOR BUYERS */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-slate-900 font-bold text-xs">
                    <CreditCard className="w-4 h-4 text-blue-600" />
                    <span>Your Settlement Account (Where Buyers Transfer Payment)</span>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    Displayed at Checkout
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Buyers will see these bank details directly at checkout to transfer the product amount, and then tap WhatsApp to message you with payment proof and delivery specifications.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Receiving Bank</label>
                    <select
                      value={newPosterBank}
                      onChange={(e) => setNewPosterBank(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                    >
                      <option value="Guaranty Trust Bank (GTBank)">GTBank</option>
                      <option value="United Bank for Africa (UBA)">UBA</option>
                      <option value="Zenith Bank">Zenith Bank</option>
                      <option value="Access Bank">Access Bank</option>
                      <option value="First Bank of Nigeria">First Bank</option>
                      <option value="Kuda Microfinance Bank">Kuda Bank</option>
                      <option value="OPay Digital Services">OPay</option>
                      <option value="Moniepoint Microfinance Bank">Moniepoint</option>
                      <option value="Fidelity Bank">Fidelity Bank</option>
                    </select>
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Account Number</label>
                    <input
                      type="text"
                      maxLength={10}
                      value={newPosterAccountNumber}
                      onChange={(e) => setNewPosterAccountNumber(e.target.value)}
                      placeholder="e.g. 0123456789"
                      className="w-full bg-white border border-slate-200 rounded-xl p-2.5 font-mono font-bold text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Account Name</label>
                    <input
                      type="text"
                      value={newPosterAccountName}
                      onChange={(e) => setNewPosterAccountName(e.target.value)}
                      placeholder="Account Holder Name"
                      className="w-full bg-white border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Platform Fee & Upper Product Boost Checkout Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
                    <span className="font-black text-amber-900 text-xs">
                      Platform Fee: {boostUpperProduct ? '₦550 (Boosted Upper Post)' : '₦50 (Standard Post)'}
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-amber-900 bg-amber-100 px-2.5 py-0.5 rounded-full font-mono border border-amber-300">
                    UBA: 2311406173 • CYPRIAN MICHAEL OJOCHOGWU
                  </span>
                </div>

                <p className="text-[11px] text-amber-800 leading-relaxed">
                  Every product post requires a base ₦50 fee payable to the official settlement account: <strong className="text-amber-950 font-bold">2311406173 UBA BANK CYPRIAN MICHAEL OJOCHOGWU</strong>. You can optionally boost your post to be automatically displayed at the very top as an Upper Product!
                </p>

                {/* Upper Product Boost Checkbox */}
                <div className="p-3 bg-white/80 rounded-xl border border-amber-300 space-y-1">
                  <label className="flex items-start space-x-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={boostUpperProduct}
                      onChange={(e) => setBoostUpperProduct(e.target.checked)}
                      className="w-4 h-4 accent-amber-600 rounded mt-0.5"
                    />
                    <div>
                      <span className="font-bold text-xs text-slate-900 block">
                        ★ Boost to Upper Products Feed (+₦500)
                      </span>
                      <span className="text-[10px] text-slate-500 block">
                        Promotes your post to the top of the Home & Explore pages, highlighted with an official verified badge and controlled directly from the Super Admin panel.
                      </span>
                    </div>
                  </label>
                </div>

                <label className="flex items-center space-x-2 pt-1 text-[11px] font-bold text-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={acceptListingFee}
                    onChange={(e) => setAcceptListingFee(e.target.checked)}
                    className="w-4 h-4 accent-blue-600 rounded"
                    required
                  />
                  <span>I agree to checkout {boostUpperProduct ? '₦550' : '₦50'} to Official Mega Store Account (2311406173 UBA BANK CYPRIAN MICHAEL OJOCHOGWU)</span>
                </label>
              </div>

              <div className="flex space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!acceptListingFee}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold py-3 rounded-xl shadow-md"
                >
                  Pay ₦50 & Publish Live
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: LIST NEW SERVICE */}
      {activeModal === 'service' && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-lg font-black text-slate-900">List Professional Service</h3>
              <button onClick={() => setActiveModal(null)} className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">✕</button>
            </div>

            <form onSubmit={handleCreateService} className="space-y-3.5 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Service Title *</label>
                <input
                  type="text"
                  required
                  value={serviceTitle}
                  onChange={(e) => setServiceTitle(e.target.value)}
                  placeholder="e.g. Solar Inverter Setup or Graphic Design"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Base Price (NGN) *</label>
                  <input
                    type="number"
                    required
                    value={servicePrice}
                    onChange={(e) => setServicePrice(e.target.value)}
                    placeholder="45000"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Pricing Unit</label>
                  <select
                    value={servicePricingUnit}
                    onChange={(e) => setServicePricingUnit(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  >
                    <option value="per project">per project</option>
                    <option value="per hour">per hour</option>
                    <option value="per session">per session</option>
                    <option value="starting inspection">starting inspection</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Service Category</label>
                <select
                  value={serviceCategory}
                  onChange={(e) => setServiceCategory(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                >
                  <option value="Tech & Digital">Tech & Digital</option>
                  <option value="Creative & Media">Creative & Media</option>
                  <option value="Repairs & Installation">Repairs & Solar Installation</option>
                  <option value="Beauty & Wellness">Beauty & Wellness</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Service Cover Image (Drag & Drop)</label>
                <ImageDropzone
                  value={serviceImage}
                  onChange={setServiceImage}
                  label="Drag & Drop Service Image Here"
                  className="h-36 w-full"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Service Description</label>
                <textarea
                  rows={3}
                  value={serviceDesc}
                  onChange={(e) => setServiceDesc(e.target.value)}
                  placeholder="Explain what is included and your standard turnaround time..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div className="flex space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="flex-1 bg-slate-100 text-slate-700 font-bold py-3 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl shadow-md"
                >
                  Publish Service
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CREATE BUSINESS STORE */}
      {activeModal === 'store' && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-lg font-black text-slate-900">Create Official Merchant Store</h3>
              <button onClick={() => setActiveModal(null)} className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">✕</button>
            </div>

            <form onSubmit={handleCreateStore} className="space-y-3.5 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Business Store Name *</label>
                <input
                  type="text"
                  required
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  placeholder="e.g. Apex Luxury Footwear"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Store Description</label>
                <textarea
                  rows={2}
                  value={storeDesc}
                  onChange={(e) => setStoreDesc(e.target.value)}
                  placeholder="Specializing in Italian leather and bespoke custom accessories..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Bank Name for Payouts</label>
                <select
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                >
                  {nigerianBanks.map((b, idx) => (
                    <option key={idx} value={b}>{b}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Account Number</label>
                  <input
                    type="text"
                    maxLength={10}
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    placeholder="0123456789"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-mono font-bold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Account Name</label>
                  <input
                    type="text"
                    value={accountName}
                    onChange={(e) => setAccountName(e.target.value)}
                    placeholder="Account Name"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="flex-1 bg-slate-100 text-slate-700 font-bold py-3 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-md"
                >
                  Launch Store
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
