import React, { useState } from 'react';
import { useStore } from '../store';
import { formatCurrency } from '../lib/utils';
import { Trash2, Plus, Minus, ArrowRight, ShoppingBag, Tag, Check, Heart, ShieldCheck } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

export default function Cart() {
  const navigate = useNavigate();
  const { 
    cart, 
    removeFromCart, 
    updateQuantity, 
    promoCode, 
    discountPercentage, 
    applyPromoCode, 
    removePromoCode,
    currency,
    toggleWishlist,
    wishlist
  } = useStore();

  const [inputCoupon, setInputCoupon] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);

  const subtotal = cart.reduce((acc, item) => {
    const price = item.product.discount_price || item.product.price;
    return acc + (price * item.quantity);
  }, 0);

  const discountAmount = discountPercentage > 0 ? (subtotal * discountPercentage) / 100 : 0;
  const deliveryFee = subtotal > 0 ? (subtotal > 100000 ? 0 : 3000) : 0;
  const total = subtotal - discountAmount + deliveryFee;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError(null);
    if (!inputCoupon.trim()) return;

    const res = applyPromoCode(inputCoupon.trim());
    if (!res.success) {
      setCouponError(res.message);
    } else {
      setInputCoupon('');
    }
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 text-center space-y-4">
        <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center shadow-xs">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-black text-slate-900 tracking-tight">Your Cart is Empty</h2>
        <p className="text-slate-500 max-w-sm text-xs">
          Discover verified consumer tech, footwear, fashion, and home products from authorized sellers.
        </p>
        <Link
          to="/explore"
          className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-8 py-3.5 rounded-2xl shadow-md shadow-blue-600/20 active:scale-95 transition-all flex items-center space-x-2 text-xs"
        >
          <span>Start Shopping</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="py-4 md:py-6 max-w-7xl mx-auto space-y-6">
      <div className="flex items-center space-x-2">
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">Shopping Cart</h1>
        <span className="bg-blue-100 text-blue-800 text-xs font-bold px-2.5 py-0.5 rounded-full">
          {cart.reduce((acc, i) => acc + i.quantity, 0)} Items
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Cart Items List */}
        <div className="lg:col-span-8 space-y-4">
          {cart.map((item) => {
            const isBookmarked = wishlist.some(w => w.id === item.product.id);

            return (
              <div
                key={item.product.id}
                className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4 bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs hover:border-blue-200 transition-all"
              >
                <img
                  src={item.product.images[0]}
                  alt={item.product.title}
                  className="w-20 h-20 sm:w-24 sm:h-24 object-cover rounded-2xl bg-slate-50 shrink-0"
                />

                <div className="flex-1 flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-sm sm:text-base text-slate-900 line-clamp-2 pr-2">
                        {item.product.title}
                      </h3>
                      <span className="text-xs text-slate-400">Sold by {item.product.store?.name || 'Verified Merchant'}</span>
                    </div>
                    
                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => toggleWishlist(item.product)}
                        className={`p-2 rounded-xl transition-colors shrink-0 ${
                          isBookmarked ? 'text-rose-600 bg-rose-50' : 'text-slate-400 hover:text-rose-600 hover:bg-slate-50'
                        }`}
                        title="Save to wishlist"
                      >
                        <Heart className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
                      </button>

                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors shrink-0"
                        title="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-100 sm:border-0 sm:pt-0">
                    <div className="font-black text-sm sm:text-base text-blue-600">
                      {formatCurrency(item.product.discount_price || item.product.price, currency)}
                    </div>

                    <div className="flex items-center space-x-3 bg-slate-100/80 rounded-xl px-2 py-1">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="w-6 h-6 flex items-center justify-center rounded-lg bg-white shadow-xs text-slate-700 hover:bg-slate-50"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold w-4 text-center">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="w-6 h-6 flex items-center justify-center rounded-lg bg-white shadow-xs text-slate-700 hover:bg-slate-50"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Order Summary & Coupon */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-black text-base text-slate-900">Summary</h3>

            {/* Promo Code Form */}
            <form onSubmit={handleApplyCoupon} className="space-y-2">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={inputCoupon}
                  onChange={(e) => setInputCoupon(e.target.value)}
                  placeholder="Coupon code (CYPRIAN2026)"
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs uppercase font-bold focus:border-blue-600 focus:outline-none"
                />
                <button
                  type="submit"
                  className="bg-slate-900 hover:bg-black text-white font-bold text-xs px-4 py-2 rounded-xl transition-all shadow-xs"
                >
                  Apply
                </button>
              </div>
              {couponError && <p className="text-[11px] text-rose-600 font-semibold">{couponError}</p>}
              {promoCode && (
                <div className="flex items-center justify-between text-xs bg-green-50 text-green-800 p-2.5 rounded-xl border border-green-200">
                  <span className="font-bold">{promoCode} ({discountPercentage}% Off)</span>
                  <button onClick={removePromoCode} className="text-rose-600 font-bold hover:underline">Remove</button>
                </div>
              )}
            </form>

            <div className="space-y-2.5 text-xs pt-2 border-t border-slate-100">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-bold text-slate-900">{formatCurrency(subtotal, currency)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-green-600 font-bold">
                  <span>Discount</span>
                  <span>-{formatCurrency(discountAmount, currency)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>Estimated Delivery</span>
                <span className="font-bold text-slate-900">
                  {deliveryFee === 0 ? 'FREE' : formatCurrency(deliveryFee, currency)}
                </span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-between items-end">
              <div>
                <span className="text-[10px] text-slate-400 block font-bold uppercase">Total</span>
                <span className="text-2xl font-black text-slate-900">{formatCurrency(total, currency)}</span>
              </div>
            </div>

            <button
              onClick={() => navigate('/checkout')}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-600/20 active:scale-95 transition-all flex items-center justify-center space-x-2 text-xs"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
