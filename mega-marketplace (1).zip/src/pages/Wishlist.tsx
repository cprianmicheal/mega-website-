import React from 'react';
import { useStore } from '../store';
import { ProductCard } from '../components/ProductCard';
import { Heart, ShoppingBag, ArrowRight, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Wishlist() {
  const { wishlist, clearWishlist, addToCart } = useStore();

  const handleAddAllToCart = () => {
    wishlist.forEach(product => {
      addToCart(product, 1);
    });
  };

  if (wishlist.length === 0) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 text-center">
        <div className="w-20 h-20 bg-rose-50 rounded-full flex items-center justify-center mb-5 text-rose-500 shadow-xs border border-rose-100">
          <Heart className="w-10 h-10 stroke-[1.8px]" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2 tracking-tight">Your wishlist is empty</h2>
        <p className="text-slate-500 mb-8 max-w-sm text-sm">
          Bookmark and save your favorite electronics, apparel, and services to keep track of price drops and availability.
        </p>
        <Link
          to="/explore"
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3.5 rounded-2xl transition-all shadow-md shadow-blue-600/20 active:scale-95 flex items-center space-x-2"
        >
          <span>Explore Marketplace</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="px-4 py-6 md:py-10 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center space-x-2.5 mb-1">
            <Heart className="w-6 h-6 text-rose-500 fill-rose-500" />
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">Saved Wishlist</h1>
          </div>
          <p className="text-sm text-slate-500">
            {wishlist.length} item{wishlist.length > 1 ? 's' : ''} saved across your shopping sessions.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-3">
          <button
            onClick={handleAddAllToCart}
            className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-xl shadow-xs transition-all active:scale-95"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Add All to Cart</span>
          </button>
          
          <button
            onClick={clearWishlist}
            className="flex items-center space-x-1.5 text-slate-500 hover:text-rose-600 bg-slate-100 hover:bg-rose-50 text-xs sm:text-sm font-semibold px-3.5 py-2.5 rounded-xl transition-all"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear</span>
          </button>
        </div>
      </div>

      {/* Grid of Wishlisted Products */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
        {wishlist.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
