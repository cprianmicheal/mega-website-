import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { ProductCard } from '../components/ProductCard';
import { UserAvatar } from '../components/UserAvatar';
import { VerifiedBrandsSlider } from '../components/VerifiedBrandsSlider';
import { VideoAdsShowcase } from '../components/VideoAdsShowcase';
import { 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  Truck, 
  CreditCard, 
  Store as StoreIcon, 
  Star, 
  Briefcase, 
  Flame, 
  Smartphone, 
  Laptop, 
  Shirt, 
  Home as HomeIcon,
  Search,
  Gift,
  Share2
} from 'lucide-react';
import { formatCurrency } from '../lib/utils';

export default function Home() {
  const navigate = useNavigate();
  const products = useStore((state) => state.products);
  const stores = useStore((state) => state.stores);
  const currency = useStore((state) => state.currency);
  const user = useStore((state) => state.user);

  const [homeSearch, setHomeSearch] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (homeSearch.trim()) {
      navigate(`/explore?q=${encodeURIComponent(homeSearch.trim())}`);
    }
  };

  const featuredProducts = [...products]
    .filter((p) => p.is_published)
    .sort((a, b) => {
      // Upper / Boosted products automatically controlled from admin panel shown at top
      if (a.is_boosted && !b.is_boosted) return -1;
      if (!a.is_boosted && b.is_boosted) return 1;
      if (a.is_featured && !b.is_featured) return -1;
      if (!a.is_featured && b.is_featured) return 1;
      return new Date(b.created_at || '').getTime() - new Date(a.created_at || '').getTime();
    })
    .slice(0, 8);

  const categoryCards = [
    { name: 'Electronics & Phones', icon: Smartphone, query: 'Electronics', count: '140+ items', color: 'from-blue-600 to-indigo-700' },
    { name: 'MacBooks & PCs', icon: Laptop, query: 'MacBook', count: '65+ items', color: 'from-blue-700 to-cyan-700' },
    { name: 'Fashion & Sneakers', icon: Shirt, query: 'Fashion', count: '90+ items', color: 'from-indigo-700 to-blue-600' },
    { name: 'Home, Decor & Solar', icon: HomeIcon, query: 'Home', count: '75+ items', color: 'from-blue-800 to-indigo-800' },
  ];

  return (
    <div className="py-4 md:py-6 space-y-12 max-w-7xl mx-auto">
      {/* Hero Section */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-tr from-slate-950 via-blue-950 to-blue-900 text-white p-6 sm:p-10 md:p-12 shadow-2xl border border-blue-800/40">
        {/* Background ambient lighting */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-64 h-64 bg-indigo-500/20 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl space-y-6">
          <div className="inline-flex items-center space-x-2 bg-blue-500/20 backdrop-blur-md border border-blue-400/30 px-3.5 py-1.5 rounded-full text-xs font-bold text-blue-200">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Nigeria's Premier Verified Multi-Vendor Network</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-[1.15]">
            Shop Verified Brands. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-300 via-blue-100 to-indigo-200">
              Zero Counterfeit Risk.
            </span>
          </h1>

          <p className="text-xs sm:text-base text-blue-100/90 leading-relaxed max-w-lg">
            Discover authentic laptops, smartphones, luxury footwear, clean solar systems, and professional services with escrow buyer protection and same-day delivery.
          </p>

          {/* Quick Hero Search Input */}
          <form onSubmit={handleSearch} className="flex items-center max-w-md bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-1.5">
            <Search className="w-5 h-5 text-blue-200 ml-3 shrink-0" />
            <input
              type="text"
              value={homeSearch}
              onChange={(e) => setHomeSearch(e.target.value)}
              placeholder="Search MacBook, Nike, Inverter, Photography..."
              className="w-full bg-transparent px-3 py-2 text-xs sm:text-sm text-white placeholder-blue-200/60 focus:outline-none"
            />
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-all shadow-md shrink-0 active:scale-95"
            >
              Search
            </button>
          </form>

          {/* Hero CTAs */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Link
              to="/explore"
              className="bg-white hover:bg-blue-50 text-blue-900 font-extrabold px-6 py-3.5 rounded-2xl text-xs sm:text-sm transition-all shadow-lg active:scale-95 flex items-center space-x-2"
            >
              <span>Explore Marketplace</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/sell"
              className="bg-blue-700/60 hover:bg-blue-700 text-white font-bold px-6 py-3.5 rounded-2xl text-xs sm:text-sm border border-blue-400/40 transition-all active:scale-95 flex items-center space-x-2"
            >
              <StoreIcon className="w-4 h-4 text-amber-300" />
              <span>Sell Products or Services</span>
            </Link>
          </div>
        </div>
      </div>

      {/* VERIFIED BRANDS SLIDER SHOWCASE (3 BRANDS WITH DISTINCT DESCRIPTIONS & COLOURS) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center space-x-2">
              <span>Verified Brand Showcase</span>
              <ShieldCheck className="w-5 h-5 text-blue-600" />
            </h2>
            <p className="text-xs text-slate-500">Certified flagship partner stores with authorized distributor warranties.</p>
          </div>
          <Link to="/explore" className="text-xs font-bold text-blue-600 hover:underline">
            All Brands →
          </Link>
        </div>

        <VerifiedBrandsSlider autoPlayInterval={6000} />
      </div>

      {/* Trust & Guarantee Badges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-sm text-slate-900">100% Escrow Protection</h4>
            <p className="text-xs text-slate-500">Payments are held securely until you receive and verify items.</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-sm text-slate-900">Door-to-Door Delivery</h4>
            <p className="text-xs text-slate-500">Live courier tracking across Lagos, Abuja, and nationwide.</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <CreditCard className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-sm text-slate-900">Direct Seller Settlements</h4>
            <p className="text-xs text-slate-500">Paystack instant card checkout & automated seller bank payouts.</p>
          </div>
        </div>
      </div>

      {/* Popular Departments */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">Popular Departments</h2>
            <p className="text-xs text-slate-500">Browse curated catalogs from top-tier merchants.</p>
          </div>
          <Link to="/explore" className="text-xs font-bold text-blue-600 hover:underline flex items-center space-x-1">
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categoryCards.map((cat, idx) => (
            <Link
              key={idx}
              to={`/explore?q=${cat.query}`}
              className={`bg-gradient-to-br ${cat.color} p-5 rounded-3xl text-white shadow-md hover:shadow-lg transition-all group flex flex-col justify-between h-36`}
            >
              <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-xs">
                <cat.icon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm sm:text-base group-hover:translate-x-1 transition-transform">{cat.name}</h3>
                <span className="text-[11px] text-blue-100 opacity-90">{cat.count}</span>
              </div>
            </Link>
          ))}
        </div>
      </div>



      {/* Referral & VIP Rewards Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-blue-950 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 border border-blue-600/30 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/20 shrink-0">
            <Gift className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="bg-amber-400/20 text-amber-300 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full border border-amber-400/30">
                Referral Program
              </span>
              <span className="text-xs text-slate-400">Earn ₦1,000 per invited friend</span>
            </div>
            <h3 className="text-lg sm:text-xl font-black text-white mt-1">
              Invite Friends with Code: <span className="text-amber-300 font-mono">{user.referral_code || 'CYPRIAN2026'}</span>
            </h3>
            <p className="text-xs text-slate-400">
              When friends sign up and make their first purchase, you instantly receive ₦1,000 cash credit in your wallet!
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <Link
            to="/account"
            className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-black px-5 py-3 rounded-2xl text-xs transition-all shadow-md active:scale-95 flex items-center space-x-2"
          >
            <Share2 className="w-4 h-4" />
            <span>Copy Referral Link</span>
          </Link>
        </div>
      </div>

      {/* Sponsored Video Lab Commercials Showcase */}
      <VideoAdsShowcase />

      {/* Trending Products Grid */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">Featured Marketplace Items</h2>
            <p className="text-xs text-slate-500">Directly sourced from verified partner retail merchants.</p>
          </div>
          <Link to="/explore" className="text-xs font-bold text-blue-600 hover:underline">
            Explore All ({products.length}) →
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}
