import React, { useState } from 'react';
import { useStore } from '../../store';
import { AdminSidebar } from '../../components/AdminSidebar';
import { VideoLabStudio } from '../../components/VideoLabStudio';
import { 
  Megaphone, 
  AlertCircle, 
  Lock, 
  Sparkles 
} from 'lucide-react';

export default function AdManagerPanel() {
  const { activeStaffRole, teamMembers, loginStaffWithPin } = useStore();

  const isAuthorized = activeStaffRole === 'ad_manager' || activeStaffRole === 'super_admin';
  const adMember = teamMembers.find(m => m.role === 'ad_manager');

  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');

  const handlePinLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const res = loginStaffWithPin('ad_manager', pinInput);
    if (!res.success) {
      setPinError(`Incorrect PIN. (Default Ad Manager PIN is ${adMember?.pin || '5566'})`);
    } else {
      setPinError('');
    }
  };

  if (!isAuthorized) {
    return (
      <div className="flex min-h-screen bg-slate-900">
        <AdminSidebar activeRole="ad_manager" />
        <main className="flex-1 p-6 sm:p-12 flex items-center justify-center">
          <div className="w-full max-w-md bg-white rounded-3xl p-8 border border-slate-200 shadow-2xl text-center space-y-6">
            <div className="w-14 h-14 rounded-2xl bg-purple-600 text-white flex items-center justify-center mx-auto shadow-lg">
              <Megaphone className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">Ad & Broadcast Manager (/%admin)</h2>
              <p className="text-xs text-slate-500 mt-1">
                Enter your 4-digit PIN (<strong className="font-mono text-purple-600">{adMember?.pin || '5566'}</strong>) to access the Video Lab ad studio and broadcast news tickers.
              </p>
            </div>

            <form onSubmit={handlePinLogin} className="space-y-4">
              <input
                type="password"
                maxLength={6}
                value={pinInput}
                onChange={(e) => {
                  setPinInput(e.target.value);
                  setPinError('');
                }}
                placeholder="••••"
                className="w-full text-center text-2xl tracking-[0.5em] font-mono py-3.5 px-4 rounded-2xl border-2 border-slate-200 focus:border-purple-600 focus:outline-none bg-slate-50 font-bold"
                autoFocus
              />

              {pinError && (
                <div className="p-3 bg-rose-50 text-rose-700 text-xs rounded-xl flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{pinError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3.5 rounded-2xl text-xs transition shadow-md shadow-purple-600/20"
              >
                Unlock Ad Manager Console
              </button>
            </form>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-slate-100">
      <AdminSidebar activeRole="ad_manager" />

      <main className="flex-1 p-6 sm:p-10 space-y-6 overflow-y-auto max-h-screen">
        <VideoLabStudio />
      </main>
    </div>
  );
}
