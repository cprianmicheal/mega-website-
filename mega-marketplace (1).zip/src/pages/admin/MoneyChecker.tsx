import React, { useState } from 'react';
import { useStore } from '../../store';
import { AdminSidebar } from '../../components/AdminSidebar';
import { 
  DollarSign, 
  CheckCircle2, 
  AlertCircle, 
  Search,
  Copy,
  Check,
  PackageCheck,
  Trash2,
  Clock,
  ShieldCheck,
  Store,
  ExternalLink
} from 'lucide-react';
import { formatCurrency } from '../../lib/utils';

export default function MoneyCheckerPanel() {
  const { 
    orders, 
    products,
    deletedProductIds = [],
    approveProductListing,
    deleteProduct,
    adminRevenueNgn, 
    currency, 
    activeStaffRole, 
    teamMembers, 
    loginStaffWithPin, 
    approveSellerPayout,
    addToast 
  } = useStore();

  const isAuthorized = activeStaffRole === 'money_checker' || activeStaffRole === 'super_admin';
  const moneyMember = teamMembers.find(m => m.role === 'money_checker');

  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [copiedAcc, setCopiedAcc] = useState(false);
  const [activeTab, setActiveTab] = useState<'pending_listings' | 'settlements' | 'live_products'>('pending_listings');
  const [searchTerm, setSearchTerm] = useState('');

  const handlePinLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const res = loginStaffWithPin('money_checker', pinInput);
    if (!res.success) {
      setPinError(`Incorrect PIN. (Default Money Checker PIN is ${moneyMember?.pin || '3344'})`);
    } else {
      setPinError('');
    }
  };

  const handleCopyUBA = () => {
    navigator.clipboard.writeText('2311406173');
    setCopiedAcc(true);
    setTimeout(() => setCopiedAcc(false), 2000);
    addToast('UBA Account Number (2311406173) copied!', 'success');
  };

  if (!isAuthorized) {
    return (
      <div className="flex min-h-screen bg-slate-900">
        <AdminSidebar activeRole="money_checker" />
        <main className="flex-1 p-6 sm:p-12 flex items-center justify-center">
          <div className="w-full max-w-md bg-white rounded-3xl p-8 border border-slate-200 shadow-2xl text-center space-y-6">
            <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-lg">
              <DollarSign className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">Money Checker Portal (/$admin)</h2>
              <p className="text-xs text-slate-500 mt-1">
                Enter your 4-digit PIN (<strong className="font-mono text-emerald-600">{moneyMember?.pin || '3344'}</strong>) to verify listing fees and approve product publications.
              </p>
            </div>

            <form onSubmit={handlePinLogin} className="space-y-4">
              <input
                type="password"
                maxLength={6}
                value={pinInput}
                onChange={(e) => {
                  setPinInput(e.target.value);
                  setPinError('');
                }}
                placeholder="••••"
                className="w-full text-center text-2xl tracking-[0.5em] font-mono py-3.5 px-4 rounded-2xl border-2 border-slate-200 focus:border-emerald-600 focus:outline-none bg-slate-50 font-bold"
                autoFocus
              />

              {pinError && (
                <div className="p-3 bg-rose-50 text-rose-700 text-xs rounded-xl flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{pinError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-2xl text-xs transition shadow-md shadow-emerald-600/20"
              >
                Unlock Payment & Money Checker Console
              </button>
            </form>
          </div>
        </main>
      </div>
    );
  }

  // Active products excluding deleted
  const validProducts = products.filter(p => !deletedProductIds.includes(p.id));
  const pendingProducts = validProducts.filter(p => !p.is_approved);
  const liveProducts = validProducts.filter(p => p.is_approved);

  const filteredPending = pendingProducts.filter(p => 
    p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.category?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.store?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex min-h-screen bg-slate-100">
      <AdminSidebar activeRole="money_checker" />

      <main className="flex-1 p-6 sm:p-10 space-y-6 overflow-y-auto max-h-screen">
        {/* Header */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                  Money Checker Authority
                </span>
                <span className="text-[10px] font-mono text-slate-400">/$admin</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Product Publishing & Revenue Verification
              </h1>
              <p className="text-xs text-slate-500">
                You must approve merchant payments before any product is published live to the marketplace.
              </p>
            </div>
          </div>

          <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-right">
            <span className="text-[10px] font-bold text-emerald-600 uppercase block">Verified Platform Revenue</span>
            <div className="text-xl font-black text-emerald-700">
              ₦{adminRevenueNgn.toLocaleString()}
            </div>
            <span className="text-[9px] text-slate-400">Cleared to UBA 2311406173</span>
          </div>
        </div>

        {/* Primary Admin Settlement Bank Card */}
        <div className="bg-gradient-to-r from-red-950 via-slate-900 to-slate-950 text-white p-6 sm:p-7 rounded-3xl border border-red-800/40 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="space-y-1">
            <span className="bg-red-500/20 text-red-300 text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full border border-red-500/30">
              Official Revenue Clearing Account
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-white mt-1">
              United Bank for Africa (UBA)
            </h3>
            <p className="text-xs text-slate-300">
              Beneficiary: <strong className="text-amber-300 font-bold">CYPRIAN MICHAEL OJOCHOGWU</strong>
            </p>
          </div>

          <div className="flex items-center space-x-3 bg-slate-900/90 border border-slate-700 p-3 rounded-2xl">
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-mono">Account Number</span>
              <span className="font-mono font-black text-xl text-amber-400 tracking-wider">
                2311406173
              </span>
            </div>
            <button
              onClick={handleCopyUBA}
              className="bg-red-600 hover:bg-red-500 text-white p-2.5 rounded-xl transition"
              title="Copy Account Number"
            >
              {copiedAcc ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Action Tabs */}
        <div className="flex items-center space-x-2 border-b border-slate-200 pb-3">
          <button
            onClick={() => setActiveTab('pending_listings')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center space-x-2 ${
              activeTab === 'pending_listings' 
                ? 'bg-emerald-600 text-white shadow-xs' 
                : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Listing Fee Approvals ({pendingProducts.length} Pending)</span>
          </button>

          <button
            onClick={() => setActiveTab('settlements')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center space-x-2 ${
              activeTab === 'settlements' 
                ? 'bg-emerald-600 text-white shadow-xs' 
                : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>Order Escrow Settlements ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('live_products')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center space-x-2 ${
              activeTab === 'live_products' 
                ? 'bg-emerald-600 text-white shadow-xs' 
                : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
            }`}
          >
            <PackageCheck className="w-4 h-4" />
            <span>Published Live Catalog ({liveProducts.length})</span>
          </button>
        </div>

        {/* TAB 1: PENDING PRODUCT PUBLISHING APPROVALS */}
        {activeTab === 'pending_listings' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-black text-slate-900">
                  Products Awaiting Money Checker Payment Approval
                </h3>
                <p className="text-xs text-slate-500">
                  Review the listing fee payment. Clicking "Approve & Publish Live" allows the product to appear in Explore.
                </p>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search product or seller..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-emerald-600"
                />
              </div>
            </div>

            {filteredPending.length === 0 ? (
              <div className="p-12 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
                <h4 className="font-bold text-slate-800 text-sm">All Product Payments Approved</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  There are no unapproved products waiting for payment verification. All submitted posts are cleared.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 uppercase text-[10px] font-black">
                      <th className="py-3 px-3">Product</th>
                      <th className="py-3 px-3">Merchant</th>
                      <th className="py-3 px-3">Selling Price</th>
                      <th className="py-3 px-3">Required Listing Fee</th>
                      <th className="py-3 px-3">Payment Status</th>
                      <th className="py-3 px-3 text-right">Money Checker Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredPending.map((p) => {
                      const requiredFee = p.is_boosted ? 550 : 50;
                      return (
                        <tr key={p.id} className="hover:bg-slate-50 transition">
                          <td className="py-3 px-3">
                            <div className="flex items-center space-x-3">
                              <img 
                                src={p.images[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=200'} 
                                alt="" 
                                className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0" 
                              />
                              <div>
                                <span className="font-bold text-slate-900 block line-clamp-1">{p.title}</span>
                                <span className="text-[10px] text-slate-400 font-mono">Category: {p.category}</span>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-3 font-semibold text-slate-700">
                            {p.store?.name || 'Verified Merchant Store'}
                          </td>
                          <td className="py-3 px-3 font-black text-slate-900">
                            {formatCurrency(p.price, currency)}
                          </td>
                          <td className="py-3 px-3 font-mono font-bold text-amber-700">
                            <span className="bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                              ₦{requiredFee.toLocaleString()} ({p.is_boosted ? 'Upper Boost' : 'Standard'})
                            </span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-full inline-flex items-center space-x-1">
                              <Clock className="w-3 h-3" />
                              <span>Awaiting Approval</span>
                            </span>
                          </td>
                          <td className="py-3 px-3 text-right">
                            <div className="flex items-center justify-end space-x-2">
                              <button
                                onClick={() => {
                                  approveProductListing(p.id, true);
                                }}
                                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1.5 rounded-xl text-xs transition shadow-xs flex items-center space-x-1"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Approve & Publish Live</span>
                              </button>
                              <button
                                onClick={() => {
                                  deleteProduct(p.id);
                                }}
                                className="bg-rose-50 hover:bg-rose-100 text-rose-700 p-1.5 rounded-xl transition"
                                title="Reject and Delete Product"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: ORDER ESCROW SETTLEMENTS */}
        {activeTab === 'settlements' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div>
              <h3 className="text-base font-black text-slate-900">Order Payments & Merchant Escrow Releases</h3>
              <p className="text-xs text-slate-500">
                Audits all customer payments and automatically deducts ₦50 platform charge into revenue on settlement.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 uppercase text-[10px] font-black">
                    <th className="py-3 px-3">Order Number</th>
                    <th className="py-3 px-3">Customer</th>
                    <th className="py-3 px-3">Gross Payment</th>
                    <th className="py-3 px-3">₦50 Admin Fee</th>
                    <th className="py-3 px-3">Net Seller Payout</th>
                    <th className="py-3 px-3">Status</th>
                    <th className="py-3 px-3 text-right">Release Escrow</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {orders.map((o) => (
                    <tr key={o.id} className="hover:bg-slate-50">
                      <td className="py-3 px-3 font-mono font-bold text-blue-600">{o.order_number}</td>
                      <td className="py-3 px-3 font-bold text-slate-900">{o.customer_name}</td>
                      <td className="py-3 px-3 font-black text-slate-900">{formatCurrency(o.total_amount, currency)}</td>
                      <td className="py-3 px-3 font-mono font-bold text-emerald-600">₦{(o.platform_fee || 50).toLocaleString()}</td>
                      <td className="py-3 px-3 font-black text-slate-700">
                        {formatCurrency(o.seller_payout_amount || (o.total_amount - 50), currency)}
                      </td>
                      <td className="py-3 px-3">
                        <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                          {o.payment_status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={() => {
                            approveSellerPayout(o.id);
                            addToast(`Payout for ${o.order_number} cleared with ₦50 platform fee deducted.`, 'success');
                          }}
                          className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold px-3 py-1.5 rounded-xl text-xs transition"
                        >
                          Verify & Clear
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: CURRENTLY LIVE PRODUCTS */}
        {activeTab === 'live_products' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div>
              <h3 className="text-base font-black text-slate-900">Approved Products Live on Marketplace</h3>
              <p className="text-xs text-slate-500">
                These items have had their listing fee confirmed and are currently visible to shoppers in Explore.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 uppercase text-[10px] font-black">
                    <th className="py-3 px-3">Product</th>
                    <th className="py-3 px-3">Merchant</th>
                    <th className="py-3 px-3">Price</th>
                    <th className="py-3 px-3">Listing Type</th>
                    <th className="py-3 px-3 text-right">Revoke / Delete</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {liveProducts.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50">
                      <td className="py-3 px-3">
                        <div className="flex items-center space-x-3">
                          <img src={p.images[0]} alt="" className="w-10 h-10 rounded-xl object-cover border" />
                          <div>
                            <span className="font-bold text-slate-900 block">{p.title}</span>
                            <span className="text-[10px] text-slate-400">{p.category}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-700">{p.store?.name || 'Verified Store'}</td>
                      <td className="py-3 px-3 font-black text-slate-900">{formatCurrency(p.price, currency)}</td>
                      <td className="py-3 px-3">
                        <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                          Live & Verified
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => approveProductListing(p.id, false)}
                            className="bg-amber-50 hover:bg-amber-100 text-amber-800 px-3 py-1.5 rounded-xl font-bold transition text-xs"
                          >
                            Revoke
                          </button>
                          <button
                            onClick={() => deleteProduct(p.id)}
                            className="bg-rose-50 hover:bg-rose-100 text-rose-700 p-1.5 rounded-xl transition"
                            title="Delete Product"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
