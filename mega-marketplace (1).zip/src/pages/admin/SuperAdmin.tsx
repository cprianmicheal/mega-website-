import React, { useState } from 'react';
import { useStore } from '../../store';
import { AdminSidebar } from '../../components/AdminSidebar';
import { ApplicationSignalsBarChart } from '../../components/ApplicationSignalsBarChart';
import { ImageDropzone } from '../../components/ImageDropzone';
import { TeamLogin } from '../../components/TeamLogin';
import { 
  Shield, 
  Trash2, 
  Users, 
  Package, 
  Key, 
  DollarSign, 
  Briefcase, 
  Eye, 
  Building2, 
  CheckCircle2, 
  XCircle, 
  MessageSquare, 
  ExternalLink, 
  Copy, 
  Check, 
  Plus, 
  Activity, 
  Lock, 
  Unlock, 
  Search,
  Sparkles,
  Camera,
  Layers,
  RotateCcw,
  Database,
  Megaphone,
  Send,
  Smartphone,
  Clipboard,
  Zap,
  EyeOff,
  RefreshCw,
  AlertCircle,
  CreditCard
} from 'lucide-react';
import { formatCurrency } from '../../lib/utils';
import { CurrencyCode } from '../../types';
import { 
  getSavedCredentials, 
  applySupabaseCredentialsGlobally, 
  testSupabaseConnection, 
  getCurrentSupabaseConfig, 
  DEFAULT_SUPABASE_URL, 
  DEFAULT_SUPABASE_ANON_KEY 
} from '../../lib/supabase';

export default function SuperAdminPanel() {
  const { 
    products, 
    deleteProduct, 
    registeredUsers, 
    deleteRegisteredUser, 
    updateUserRoleAndBalance,
    teamMembers, 
    updateTeamMemberPin,
    teamApplications, 
    reviewTeamApplication,
    adminRevenueNgn, 
    adminBankAccounts, 
    addAdminBankAccount, 
    deleteAdminBankAccount, 
    setPrimaryAdminBankAccount,
    platformSettings, 
    updatePlatformSettings,
    updateAllTeamPins,
    factoryResetApp,
    currency,
    addToast,
    activeStaffRole,
    isAdminAuthenticated,
    phoneDropAlerts,
    broadcastPhoneDropAlert,
    deletePhoneDropAlert
  } = useStore();

  const [activeTab, setActiveTab] = useState<'signals' | 'products' | 'customers' | 'phone_drops' | 'team_pins' | 'applications' | 'bank_accounts' | 'super_hand' | 'profile' | 'supabase'>('signals');

  // Phone Drop Broadcast State
  const [dropTitle, setDropTitle] = useState('');
  const [dropMessage, setDropMessage] = useState('');
  const [dropPhone, setDropPhone] = useState(platformSettings.official_drop_phone || platformSettings.admin_whatsapp_number || '0704409544');

  // Search filters
  const [productSearch, setProductSearch] = useState('');
  const [customerSearch, setCustomerSearch] = useState('');

  // PIN edit modal/state
  const [editingMemberId, setEditingMemberId] = useState<string | null>(null);
  const [newPinValue, setNewPinValue] = useState('');
  const [bulkPinValue, setBulkPinValue] = useState('');

  // Add Bank Account Form state
  const [newBankName, setNewBankName] = useState('');
  const [newAccNumber, setNewAccNumber] = useState('');
  const [newAccName, setNewAccName] = useState('CYPRIAN MICHAEL OJOCHOGWU');
  const [newGatewayLink, setNewGatewayLink] = useState('');
  const [newGatewayProvider, setNewGatewayProvider] = useState<'paystack' | 'flutterwave' | 'moniepoint' | 'opay' | 'kuda' | 'interswitch' | 'custom'>('paystack');
  const [showAddBank, setShowAddBank] = useState(false);

  // Profile Edit state
  const [adminName, setAdminName] = useState(platformSettings.admin_name || 'Cyprian O.');
  const [adminEmail, setAdminEmail] = useState(platformSettings.admin_email || 'support@megamarket.com');
  const [adminAvatar, setAdminAvatar] = useState(platformSettings.admin_avatar_url || '');
  const [newAdminPassword, setNewAdminPassword] = useState('');
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  // Supabase Global Setup state
  const savedSupabase = getSavedCredentials();
  const [superSupabaseUrl, setSuperSupabaseUrl] = useState(savedSupabase.url);
  const [superSupabaseKey, setSuperSupabaseKey] = useState(savedSupabase.anonKey);
  const [superShowKey, setSuperShowKey] = useState(false);
  const [superTesting, setSuperTesting] = useState(false);
  const [superTestResult, setSuperTestResult] = useState<{ success: boolean; latencyMs: number; message: string } | null>(null);

  const handleBroadcastPhoneDrop = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dropTitle.trim() || !dropMessage.trim()) {
      addToast('Please provide title and message for phone drop.', 'error');
      return;
    }
    broadcastPhoneDropAlert({
      title: dropTitle.trim(),
      message: dropMessage.trim(),
      recipientPhone: dropPhone.trim() || platformSettings.official_drop_phone || platformSettings.admin_whatsapp_number || '0704409544',
      channel: 'WHATSAPP',
      productTitle: dropTitle.trim(),
      productPrice: 35000,
      locationTag: platformSettings.platform_location || 'Ankpa, Kogi State, Nigeria'
    });
    setDropTitle('');
    setDropMessage('');
    addToast('Live phone drop alert broadcasted successfully!', 'success');
  };

  // Access Gate: If not authenticated as Super Admin, show TeamLogin Gateway
  const isSuperAdminAuthorized = isAdminAuthenticated || activeStaffRole === 'super_admin';

  const filteredProducts = products.filter(p => 
    p.title.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.category?.toLowerCase().includes(productSearch.toLowerCase())
  );

  const filteredUsers = registeredUsers.filter(u => 
    u.full_name.toLowerCase().includes(customerSearch.toLowerCase()) ||
    u.email?.toLowerCase().includes(customerSearch.toLowerCase()) ||
    u.phone?.includes(customerSearch)
  );

  const acceptedCount = teamApplications.filter(a => a.status === 'accepted').length;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLink(id);
    setTimeout(() => setCopiedLink(null), 2000);
    addToast('Copied to clipboard!', 'info');
  };

  const handleUpdatePin = (memberId: string) => {
    if (newPinValue.length < 4) {
      addToast('PIN must be at least 4 digits.', 'error');
      return;
    }
    updateTeamMemberPin(memberId, newPinValue);
    setEditingMemberId(null);
    setNewPinValue('');
  };

  const handleAddBankSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBankName || !newAccNumber) return;
    addAdminBankAccount({
      bank_name: newBankName,
      account_number: newAccNumber,
      account_name: newAccName || 'CYPRIAN MICHAEL OJOCHOGWU',
      is_primary: false,
      currency: 'NGN',
      gateway_api_link: newGatewayLink.trim() || undefined,
      gateway_provider: newGatewayLink.trim() ? newGatewayProvider : undefined,
      notes: newGatewayLink.trim() ? `Connected via ${newGatewayProvider.toUpperCase()} Gateway API: ${newGatewayLink.trim()}` : undefined
    });
    setNewBankName('');
    setNewAccNumber('');
    setNewGatewayLink('');
    setShowAddBank(false);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updatePlatformSettings({
      admin_name: adminName,
      admin_email: adminEmail,
      admin_avatar_url: adminAvatar
    });
    addToast('Super Admin profile updated successfully!', 'success');
  };

  if (!isSuperAdminAuthorized) {
    return (
      <div className="flex min-h-screen bg-slate-900">
        <AdminSidebar activeRole="super_admin" />
        <main className="flex-1 p-6 sm:p-12 flex flex-col items-center justify-center">
          <div className="w-full max-w-md bg-white rounded-3xl p-8 border border-slate-200 shadow-2xl text-center space-y-6">
            <div className="w-16 h-16 rounded-3xl bg-slate-950 text-amber-400 flex items-center justify-center mx-auto shadow-xl">
              <Shield className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">Super Admin Portal (/#admin)</h2>
              <p className="text-xs text-slate-500 mt-1">
                Enter your master PIN (<span className="font-mono font-bold text-blue-600">2026</span>) or administrator password (<span className="font-mono font-bold text-blue-600">Cyprian123</span>) to proceed.
              </p>
            </div>
            <TeamLogin />
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-slate-100">
      <AdminSidebar activeRole="super_admin" />

      <main className="flex-1 p-6 sm:p-10 space-y-8 overflow-y-auto max-h-screen">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center space-x-4">
            <img
              src={platformSettings.admin_avatar_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300'}
              alt="Admin"
              className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-400 shadow-md"
            />
            <div>
              <div className="flex items-center space-x-2">
                <span className="bg-amber-100 text-amber-800 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                  Super Admin
                </span>
                <span className="text-[10px] font-mono text-slate-400">/#admin</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {platformSettings.admin_name} Control Center
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                {platformSettings.admin_email} • Master Overseer & Multi-Role Governance
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                if (window.confirm('⚠️ FACTORY RESET WARNING:\n\nAre you sure you want to completely factory reset Mega Marketplace to original standard state?\n\nThis will clear current test data and restore verified standard products, accounts, and system tables.')) {
                  factoryResetApp();
                }
              }}
              className="bg-rose-50 hover:bg-rose-100 text-rose-700 px-3.5 py-2.5 rounded-2xl border border-rose-200 font-bold text-xs flex items-center space-x-1.5 transition active:scale-95 shadow-xs"
              title="Factory Reset Application"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Factory Reset App</span>
            </button>

            <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-right">
              <span className="text-[10px] font-bold text-emerald-600 uppercase block">Total Admin Revenue</span>
              <div className="text-lg font-black text-emerald-700">
                ₦{adminRevenueNgn.toLocaleString()}
              </div>
              <span className="text-[9px] text-slate-400">UBA 2311406173</span>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2 text-xs font-bold">
          {[
            { id: 'signals', label: 'Activity Bar Chart Signals', icon: Activity },
            { id: 'products', label: `Manage Products (${products.length})`, icon: Package },
            { id: 'customers', label: `Manage Customers (${registeredUsers.length})`, icon: Users },
            { id: 'phone_drops', label: `Phone Drops & SMS (${phoneDropAlerts.length})`, icon: Smartphone },
            { id: 'team_pins', label: 'Team Accounts & PINs', icon: Key },
            { id: 'applications', label: `Community Applicants (${acceptedCount}/7)`, icon: Briefcase },
            { id: 'bank_accounts', label: 'Revenue Bank Accounts', icon: Building2 },
            { id: 'super_hand', label: 'Super Hand Monitor', icon: Eye },
            { id: 'profile', label: 'Profile & Avatar Upload', icon: Camera },
            { id: 'supabase', label: 'Supabase SQL & Credentials', icon: Database },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2.5 rounded-2xl transition-all ${
                activeTab === tab.id
                  ? 'bg-slate-900 text-white shadow-md shadow-slate-900/20 font-black'
                  : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* TAB 1: ACTIVITY BAR CHART SIGNALS */}
        {activeTab === 'signals' && (
          <div className="space-y-6">
            <ApplicationSignalsBarChart />
          </div>
        )}

        {/* TAB 2: MANAGE PRODUCTS (DELETE PRODUCTS) */}
        {activeTab === 'products' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-lg font-black text-slate-900">Marketplace Inventory Control</h3>
                <p className="text-xs text-slate-500">
                  Super Admin power: Delete any product listing, remove fraudulent offers, or edit status.
                </p>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  placeholder="Search products..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-blue-600"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 uppercase text-[10px] font-black">
                    <th className="py-3 px-3">Product</th>
                    <th className="py-3 px-3">Category</th>
                    <th className="py-3 px-3">Price</th>
                    <th className="py-3 px-3">Stock</th>
                    <th className="py-3 px-3">External Website</th>
                    <th className="py-3 px-3 text-right">Delete Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredProducts.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-3">
                        <div className="flex items-center space-x-3">
                          <img
                            src={p.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=200'}
                            alt=""
                            className="w-10 h-10 rounded-xl object-cover border border-slate-200 shrink-0"
                          />
                          <div>
                            <span className="font-bold text-slate-900 block line-clamp-1">{p.title}</span>
                            <span className="text-[10px] font-mono text-slate-400">ID: {p.id}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-600">{p.category || 'General'}</td>
                      <td className="py-3 px-3 font-black text-slate-900">
                        {p.currency && p.currency !== 'NGN' ? `${p.currency} ` : ''}
                        {formatCurrency(p.price, currency)}
                      </td>
                      <td className="py-3 px-3 font-mono font-bold text-slate-700">{p.stock} units</td>
                      <td className="py-3 px-3">
                        {p.website_url ? (
                          <a
                            href={p.website_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline flex items-center space-x-1"
                          >
                            <span className="truncate max-w-[120px]">{p.website_url}</span>
                            <ExternalLink className="w-3 h-3 shrink-0" />
                          </a>
                        ) : (
                          <span className="text-slate-400">None</span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={() => {
                            deleteProduct(p.id);
                          }}
                          className="bg-rose-50 hover:bg-rose-100 text-rose-700 px-3 py-1.5 rounded-xl font-bold transition flex items-center space-x-1 ml-auto"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: MANAGE CUSTOMERS (DELETE CUSTOMERS) */}
        {activeTab === 'customers' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-lg font-black text-slate-900">Registered Users & Customers</h3>
                <p className="text-xs text-slate-500">
                  Super Admin control: Delete any customer/seller account, inspect wallet balance and role.
                </p>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={customerSearch}
                  onChange={(e) => setCustomerSearch(e.target.value)}
                  placeholder="Search user name or phone..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-blue-600"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 uppercase text-[10px] font-black">
                    <th className="py-3 px-3">User</th>
                    <th className="py-3 px-3">Contact</th>
                    <th className="py-3 px-3">Role</th>
                    <th className="py-3 px-3">Wallet</th>
                    <th className="py-3 px-3">Business</th>
                    <th className="py-3 px-3 text-right">Delete Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-3">
                        <div className="flex items-center space-x-3">
                          <img
                            src={u.avatar_url || 'https://ui-avatars.com/api/?name=User&background=random'}
                            alt=""
                            className="w-9 h-9 rounded-xl object-cover border border-slate-200 shrink-0"
                          />
                          <div>
                            <span className="font-bold text-slate-900 block">{u.full_name}</span>
                            <span className="text-[10px] font-mono text-slate-400">ID: {u.id}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <span className="block text-slate-700 font-medium">{u.email || 'No email'}</span>
                        <span className="text-slate-400 font-mono text-[11px]">{u.phone || 'No phone'}</span>
                      </td>
                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                          u.role === 'admin' ? 'bg-amber-100 text-amber-800' :
                          u.role === 'seller' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                        }`}>
                          {u.role}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono font-bold text-emerald-700">
                        ₦{(u.wallet_balance || 0).toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-slate-600 font-medium">
                        {u.business_name || 'Standard Account'}
                      </td>
                      <td className="py-3 px-3 text-right">
                        {u.id !== 'usr-1' ? (
                          <button
                            onClick={() => {
                              deleteRegisteredUser(u.id);
                            }}
                            className="bg-rose-50 hover:bg-rose-100 text-rose-700 px-3 py-1.5 rounded-xl font-bold transition flex items-center space-x-1 ml-auto"
                            title="Delete Customer Account"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete</span>
                          </button>
                        ) : (
                          <span className="text-slate-400 font-bold text-[10px]">Master Admin</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB: PHONE DROPS & SMS BROADCAST */}
        {activeTab === 'phone_drops' && (
          <div className="space-y-6">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
              <h3 className="text-lg font-black text-slate-900 mb-2">Live Phone Drops & SMS Campaign Broadcaster</h3>
              <p className="text-xs text-slate-500 mb-6">
                Broadcast live inventory drops, tech discounts, and instant SMS/WhatsApp alerts directly to all subscribed customer phone numbers.
              </p>

              <form onSubmit={handleBroadcastPhoneDrop} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Drop Title / Headline *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. ⚡ FLASH DROP: iPhone 15 Pro Max (512GB) in Stock"
                      value={dropTitle}
                      onChange={(e) => setDropTitle(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Target Phone / WhatsApp Number *</label>
                    <input
                      type="text"
                      required
                      value={dropPhone}
                      onChange={(e) => setDropPhone(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Broadcast Notification Message *</label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Enter the drop alert message broadcasted to subscriber phones..."
                    value={dropMessage}
                    onChange={(e) => setDropMessage(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-3.5 rounded-xl shadow-md transition-all active:scale-95 flex items-center space-x-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Broadcast Live Phone Drop Alert</span>
                </button>
              </form>
            </div>

            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
              <h3 className="text-lg font-black text-slate-900 mb-4">
                Active Live Phone Drop Alerts ({phoneDropAlerts.length})
              </h3>
              {phoneDropAlerts.length === 0 ? (
                <p className="text-xs text-slate-400">No active phone drops. Post one above to broadcast across devices.</p>
              ) : (
                <div className="space-y-3">
                  {phoneDropAlerts.map((drop) => (
                    <div key={drop.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm">{drop.title}</h4>
                        <p className="text-xs text-slate-500 mt-0.5">{drop.message}</p>
                        <span className="text-[10px] text-blue-600 font-bold mt-1 inline-block">
                          Channel: {drop.channel} • Recipient: {drop.recipientPhone} • {drop.timestamp}
                        </span>
                      </div>
                      <button
                        onClick={() => deletePhoneDropAlert(drop.id)}
                        className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition"
                        title="Delete Phone Drop"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 4: TEAM ACCOUNTS & PINs */}
        {activeTab === 'team_pins' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-100">
                <div>
                  <h3 className="text-lg font-black text-slate-900">Team Staff PINs & URLs Manager</h3>
                  <p className="text-xs text-slate-500">
                    You can change any team member's PIN at any time or update everyone's code in one click. When team members visit their specific URL or <span className="font-mono text-blue-600 font-bold">/#admin</span>, they enter their PIN to unlock their dedicated dashboard.
                  </p>
                </div>

                {/* Bulk PIN updater */}
                <div className="flex items-center gap-2 bg-slate-50 p-2.5 rounded-2xl border border-slate-200 shrink-0">
                  <input
                    type="password"
                    maxLength={6}
                    value={bulkPinValue}
                    onChange={(e) => setBulkPinValue(e.target.value)}
                    placeholder="New PIN for all"
                    className="w-32 px-3 py-1.5 rounded-xl border border-slate-300 font-mono text-xs font-bold bg-white text-center"
                  />
                  <button
                    onClick={() => {
                      if (bulkPinValue.length < 4) {
                        addToast('PIN must be at least 4 digits.', 'error');
                        return;
                      }
                      updateAllTeamPins(bulkPinValue);
                      setBulkPinValue('');
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-3 py-1.5 rounded-xl text-xs transition whitespace-nowrap shadow-sm"
                  >
                    Change Code for Everyone
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                {teamMembers.map((member) => (
                  <div
                    key={member.id}
                    className="p-5 rounded-3xl border border-slate-200 bg-slate-50/60 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold">
                          <Key className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-black text-sm text-slate-900">{member.name}</h4>
                          <span className="text-[10px] font-mono text-blue-600 font-bold">{member.route}</span>
                        </div>
                      </div>

                      <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                        {member.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-500">{member.description}</p>

                    <div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-bold uppercase">Assigned Access PIN</span>
                        <span className="font-mono font-black text-base text-slate-900 tracking-wider">
                          {member.pin}
                        </span>
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => {
                            setEditingMemberId(member.id);
                            setNewPinValue(member.pin);
                          }}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-800 px-3 py-1.5 rounded-xl font-bold text-xs"
                        >
                          Change PIN
                        </button>
                        <button
                          onClick={() => handleCopy(window.location.origin + member.route, member.id)}
                          className="bg-blue-50 text-blue-700 px-2.5 py-1.5 rounded-xl font-bold text-xs flex items-center space-x-1"
                          title="Copy Link"
                        >
                          {copiedLink === member.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>Link</span>
                        </button>
                      </div>
                    </div>

                    {editingMemberId === member.id && (
                      <div className="p-3 bg-blue-50 rounded-2xl border border-blue-200 space-y-2 animate-in fade-in">
                        <span className="text-[11px] font-bold text-blue-900 block">Set New PIN for {member.name}:</span>
                        <div className="flex items-center space-x-2">
                          <input
                            type="password"
                            maxLength={6}
                            value={newPinValue}
                            onChange={(e) => setNewPinValue(e.target.value)}
                            placeholder="e.g. 9988"
                            className="p-2 rounded-xl border border-blue-300 font-mono text-center font-bold text-sm w-28 bg-white"
                          />
                          <button
                            onClick={() => handleUpdatePin(member.id)}
                            className="bg-blue-600 text-white px-3 py-2 rounded-xl font-bold text-xs hover:bg-blue-700"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingMemberId(null)}
                            className="text-slate-500 text-xs px-2"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: REMOTE COMMUNITY APPLICATIONS (MAX 7 ACCEPTED) */}
        {activeTab === 'applications' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-black text-slate-900">Remote Team Applications</h3>
                <p className="text-xs text-slate-500">
                  Review applicant profiles. Once accepted (up to 7 max), you generate their PIN and message them directly via WhatsApp or email.
                </p>
              </div>

              <div className="bg-blue-50 border border-blue-200 px-4 py-2 rounded-2xl text-xs font-bold text-blue-800">
                Quota: <strong className="text-blue-900">{acceptedCount}</strong> of 7 positions accepted
              </div>
            </div>

            <div className="space-y-4">
              {teamApplications.map((app) => (
                <div
                  key={app.id}
                  className="p-5 rounded-3xl border border-slate-200 bg-slate-50/50 space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold">
                        {app.applicant_name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-black text-sm text-slate-900">{app.applicant_name}</h4>
                        <span className="text-xs text-blue-600 font-semibold">{app.email} • {app.whatsapp}</span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                        app.status === 'accepted' ? 'bg-emerald-100 text-emerald-800' :
                        app.status === 'rejected' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {app.status}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        Role: {app.desired_role}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-2xl border border-slate-200 text-xs space-y-1">
                    <span className="font-bold text-slate-700 block">Experience & Background:</span>
                    <p className="text-slate-600">{app.experience_summary}</p>
                    {app.remote_readiness && (
                      <span className="text-[11px] text-slate-500 block pt-1">
                        <strong>Remote Setup:</strong> {app.remote_readiness}
                      </span>
                    )}
                  </div>

                  {/* Actions: Accept, Decline, WhatsApp */}
                  <div className="pt-2 flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div>
                      {app.assigned_pin && (
                        <span className="text-emerald-700 font-mono font-bold bg-emerald-50 px-3 py-1 rounded-xl border border-emerald-200">
                          Assigned PIN: {app.assigned_pin}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center space-x-2">
                      {app.status !== 'accepted' && (
                        <button
                          onClick={() => reviewTeamApplication(app.id, 'accepted')}
                          disabled={acceptedCount >= 7}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3.5 py-2 rounded-xl disabled:opacity-50"
                        >
                          Accept & Generate PIN
                        </button>
                      )}

                      {app.status !== 'rejected' && (
                        <button
                          onClick={() => reviewTeamApplication(app.id, 'rejected')}
                          className="bg-rose-50 text-rose-700 font-bold px-3 py-2 rounded-xl hover:bg-rose-100"
                        >
                          Decline
                        </button>
                      )}

                      <a
                        href={`https://wa.me/${app.whatsapp.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                          `Hello ${app.applicant_name}, congratulations! Your application for ${app.desired_role} on Mega Marketplace has been accepted. Your dashboard PIN is: ${app.assigned_pin || '2026'}. Please visit https://megamarket.ng/#admin to log in.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-green-600 hover:bg-green-700 text-white font-bold px-3.5 py-2 rounded-xl flex items-center space-x-1.5 shadow-sm"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Message on WhatsApp</span>
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 6: ADMIN REVENUE & BANK ACCOUNTS */}
        {activeTab === 'bank_accounts' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-black text-slate-900">Admin Revenue Channels & Settlement Banks</h3>
                <p className="text-xs text-slate-500">
                  Primary revenue receiver: <strong className="text-slate-800">UBA bank 2311406173</strong>. Disconnected from customer Paystack accounts so all admin charges and ₦50 seller payout fees deposit safely into your own accounts.
                </p>
              </div>

              <button
                onClick={() => setShowAddBank(!showAddBank)}
                className="bg-blue-600 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center space-x-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Add Bank Account</span>
              </button>
            </div>

            {/* Add Bank Form */}
            {showAddBank && (
              <form onSubmit={handleAddBankSubmit} className="p-5 bg-slate-50 rounded-3xl border border-slate-200 space-y-4 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div className="flex items-center space-x-2">
                    <Building2 className="w-4 h-4 text-blue-600" />
                    <span className="font-bold text-slate-800">New Settlement Bank & Gateway Connection</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-medium">Connect Paystack API, Flutterwave or NUBAN</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Bank Name</label>
                    <input
                      type="text"
                      required
                      value={newBankName}
                      onChange={(e) => setNewBankName(e.target.value)}
                      placeholder="e.g. United Bank for Africa (UBA)"
                      className="w-full p-2.5 rounded-xl border border-slate-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Account Number (NUBAN)</label>
                    <input
                      type="text"
                      required
                      maxLength={10}
                      value={newAccNumber}
                      onChange={(e) => setNewAccNumber(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="2311406173"
                      className="w-full p-2.5 rounded-xl border border-slate-300 bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Account Name / Beneficiary</label>
                    <input
                      type="text"
                      value={newAccName}
                      onChange={(e) => setNewAccName(e.target.value)}
                      placeholder="CYPRIAN MICHAEL OJOCHOGWU"
                      className="w-full p-2.5 rounded-xl border border-slate-300 bg-white font-semibold"
                    />
                  </div>
                </div>

                {/* Gateway API & Future Integration Section */}
                <div className="p-3.5 bg-blue-50/70 rounded-2xl border border-blue-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-blue-700" />
                      <span className="font-black text-blue-950 text-xs">Payment Gateway API Link & Auto-Connect</span>
                    </div>
                    <span className="text-[10px] bg-blue-600 text-white font-bold px-2 py-0.5 rounded-full">
                      Future-Proof API
                    </span>
                  </div>
                  <p className="text-[11px] text-blue-800">
                    Add the API endpoint, webhook URL, or secret integration link for Paystack or any payment gateway bank so your settlement route connects automatically.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                    <div>
                      <label className="block font-bold text-blue-900 mb-1">Gateway Provider</label>
                      <select
                        value={newGatewayProvider}
                        onChange={(e) => setNewGatewayProvider(e.target.value as any)}
                        className="w-full p-2 rounded-xl border border-blue-300 bg-white text-xs font-semibold"
                      >
                        <option value="paystack">Paystack API Gateway</option>
                        <option value="flutterwave">Flutterwave Rave API</option>
                        <option value="moniepoint">Moniepoint Direct Gateway</option>
                        <option value="opay">OPay Digital Gateway</option>
                        <option value="kuda">Kuda Open Banking API</option>
                        <option value="interswitch">Interswitch WebPAY</option>
                        <option value="custom">Custom Webhook / Banking API</option>
                      </select>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block font-bold text-blue-900 mb-1">API Endpoint / Secret Gateway Link</label>
                      <input
                        type="url"
                        value={newGatewayLink}
                        onChange={(e) => setNewGatewayLink(e.target.value)}
                        placeholder="https://api.paystack.co/bank/resolve or https://your-gateway.com/api"
                        className="w-full p-2 rounded-xl border border-blue-300 bg-white text-xs font-mono"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowAddBank(false)}
                    className="px-4 py-2 rounded-xl border border-slate-300 text-slate-600 font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-black px-5 py-2 rounded-xl shadow-xs"
                  >
                    Save & Connect Gateway Bank
                  </button>
                </div>
              </form>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {adminBankAccounts.map((acc) => (
                <div
                  key={acc.id}
                  className={`p-5 rounded-3xl border transition-all ${
                    acc.is_primary
                      ? 'border-red-500 bg-red-50/40 shadow-md ring-1 ring-red-400'
                      : 'border-slate-200 bg-slate-50/60'
                  }`}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200/60">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 rounded-xl bg-red-600 text-white font-black text-xs flex items-center justify-center">
                        {acc.bank_name.includes('UBA') ? 'UBA' : 'BNK'}
                      </div>
                      <div>
                        <span className="font-black text-sm text-slate-900 block">{acc.bank_name}</span>
                        {acc.gateway_api_link && (
                          <span className="text-[10px] text-blue-600 font-mono font-bold">
                            API: {acc.gateway_provider?.toUpperCase() || 'GATEWAY'} Connected
                          </span>
                        )}
                      </div>
                    </div>

                    {acc.is_primary ? (
                      <span className="bg-red-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                        Primary Revenue Account
                      </span>
                    ) : (
                      <button
                        onClick={() => setPrimaryAdminBankAccount(acc.id)}
                        className="text-xs text-blue-600 font-bold hover:underline"
                      >
                        Set Primary
                      </button>
                    )}
                  </div>

                  <div className="pt-3 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Account Number:</span>
                      <span className="font-mono font-black text-base text-slate-900">{acc.account_number}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Account Name:</span>
                      <span className="font-bold text-slate-800">{acc.account_name}</span>
                    </div>
                    {acc.gateway_api_link && (
                      <div className="pt-1.5 border-t border-slate-200/50">
                        <span className="text-slate-400 block text-[10px]">Gateway API Link:</span>
                        <span className="font-mono text-[11px] text-blue-700 truncate block bg-white/70 p-1 rounded-md border border-slate-200">
                          {acc.gateway_api_link}
                        </span>
                      </div>
                    )}
                    {acc.notes && (
                      <p className="text-[10px] text-slate-500 italic pt-1">{acc.notes}</p>
                    )}
                  </div>

                  {!acc.is_primary && (
                    <div className="pt-3 flex justify-end">
                      <button
                        onClick={() => deleteAdminBankAccount(acc.id)}
                        className="text-rose-600 hover:text-rose-800 text-xs font-bold"
                      >
                        Remove Account
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 7: SUPER HAND LIVE MONITOR */}
        {activeTab === 'super_hand' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center space-x-3 pb-3 border-b border-slate-100">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-600 flex items-center justify-center">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-900">Super Hand Multi-Panel Monitor</h3>
                <p className="text-xs text-slate-500">
                  Live real-time supervision over Bookkeeper, Payment Checker, and Ad Manager activities.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="text-[10px] font-bold text-blue-600 uppercase block">/@admin Bookkeeper</span>
                <h4 className="font-black text-sm text-slate-900">Ledger Health: 100% Balanced</h4>
                <p className="text-xs text-slate-500">
                  All transaction rows reconciled. Platform fee deductions audit verified.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="text-[10px] font-bold text-emerald-600 uppercase block">/$admin Money Checker</span>
                <h4 className="font-black text-sm text-slate-900">Settlements: Verified</h4>
                <p className="text-xs text-slate-500">
                  Direct UBA 2311406173 settlement route verified. ₦50 seller payout charge operational.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="text-[10px] font-bold text-purple-600 uppercase block">/%admin Ad Manager</span>
                <h4 className="font-black text-sm text-slate-900">Video Lab: 2 Active Streams</h4>
                <p className="text-xs text-slate-500">
                  Auto-scheduled daily self-posting active across homepage and explore feeds.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 8: PROFILE & AVATAR UPLOAD */}
        {activeTab === 'profile' && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm max-w-2xl mx-auto space-y-6">
            <div>
              <h3 className="text-lg font-black text-slate-900">Super Admin Profile & Avatar</h3>
              <p className="text-xs text-slate-500">
                Upload your admin photo, update email to <span className="font-bold text-blue-600">support@megamarket.com</span>, and manage password.
              </p>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
              <div className="space-y-2">
                <label className="block font-bold text-slate-700">Admin Profile Avatar</label>
                <ImageDropzone
                  value={adminAvatar}
                  onChange={(url) => setAdminAvatar(url)}
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Display Name</label>
                <input
                  type="text"
                  value={adminName}
                  onChange={(e) => setAdminName(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Official Support Email</label>
                <input
                  type="email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 font-bold"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-3.5 rounded-2xl shadow-md text-xs"
              >
                Save Admin Profile Details
              </button>
            </form>
          </div>
        )}

        {/* TAB 9: SUPABASE SQL & CREDENTIALS */}
        {activeTab === 'supabase' && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-4xl mx-auto">
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full">
                Supabase Database Connected
              </span>
              <h3 className="text-xl font-black text-slate-900 mt-2">Supabase SQL Script & Account Credentials</h3>
              <p className="text-xs text-slate-500">
                Copy the complete PostgreSQL migration script below and paste it into your Supabase SQL Editor to create all required tables and policies.
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-700">1. Supabase SQL Schema Script</span>
                <button
                  type="button"
                  onClick={() => handleCopy(`-- SUPABASE SQL SCRIPT FOR MEGA MARKETPLACE
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    phone TEXT,
    role TEXT DEFAULT 'customer',
    business_name TEXT,
    wallet_balance NUMERIC DEFAULT 50000,
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    price NUMERIC NOT NULL,
    category TEXT,
    image_url TEXT,
    seller_id TEXT,
    stock INTEGER DEFAULT 10,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    social_link TEXT,
    total_spent NUMERIC DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.video_ads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    video_url TEXT NOT NULL,
    thumbnail_url TEXT,
    product_id TEXT,
    views INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_code TEXT UNIQUE NOT NULL,
    customer_email TEXT,
    total_amount NUMERIC NOT NULL,
    items JSONB,
    status TEXT DEFAULT 'completed',
    created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.video_ads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public profiles" ON public.profiles FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public products" ON public.products FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public customers" ON public.customers FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public video_ads" ON public.video_ads FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public orders" ON public.orders FOR ALL USING (true) WITH CHECK (true);`, 'sql-script')}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow-sm"
                >
                  {copiedLink === 'sql-script' ? <Check className="w-3.5 h-3.5 text-emerald-200" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Copy SQL Script</span>
                </button>
              </div>

              <textarea
                readOnly
                rows={12}
                className="w-full p-4 bg-slate-900 text-emerald-400 font-mono text-xs rounded-2xl border border-slate-800 focus:outline-none"
                value={`-- SUPABASE SQL SCRIPT FOR MEGA MARKETPLACE
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    phone TEXT,
    role TEXT DEFAULT 'customer',
    business_name TEXT,
    wallet_balance NUMERIC DEFAULT 50000,
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    price NUMERIC NOT NULL,
    category TEXT,
    image_url TEXT,
    seller_id TEXT,
    stock INTEGER DEFAULT 10,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    social_link TEXT,
    total_spent NUMERIC DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.video_ads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    video_url TEXT NOT NULL,
    thumbnail_url TEXT,
    product_id TEXT,
    views INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_code TEXT UNIQUE NOT NULL,
    customer_email TEXT,
    total_amount NUMERIC NOT NULL,
    items JSONB,
    status TEXT DEFAULT 'completed',
    created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.video_ads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public profiles" ON public.profiles FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public products" ON public.products FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public customers" ON public.customers FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public video_ads" ON public.video_ads FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public orders" ON public.orders FOR ALL USING (true) WITH CHECK (true);`}
              />

              <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-4 text-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-extrabold text-sm text-slate-900 flex items-center space-x-2">
                      <Zap className="w-4 h-4 text-emerald-600" />
                      <span>2. Paste Credentials & Connect Globally</span>
                    </h4>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      Paste your credentials from your Supabase dashboard to immediately bind the marketplace globally.
                    </p>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full">
                    Active Ref: {getCurrentSupabaseConfig().projectRef}
                  </span>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-bold text-slate-700">Supabase Project URL</label>
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            const text = await navigator.clipboard.readText();
                            if (text) setSuperSupabaseUrl(text.trim());
                          } catch {}
                        }}
                        className="text-[11px] text-emerald-700 font-bold hover:underline flex items-center space-x-1"
                      >
                        <Clipboard className="w-3 h-3" />
                        <span>Paste from Clipboard</span>
                      </button>
                    </div>
                    <input
                      type="url"
                      value={superSupabaseUrl}
                      onChange={(e) => setSuperSupabaseUrl(e.target.value)}
                      placeholder="https://ugkvfehugcakdqbikdyx.supabase.co"
                      className="w-full bg-white border border-slate-300 rounded-xl p-2.5 font-mono text-xs text-slate-900 focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-bold text-slate-700">Supabase Anon / Public Key</label>
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            const text = await navigator.clipboard.readText();
                            if (text) setSuperSupabaseKey(text.trim());
                          } catch {}
                        }}
                        className="text-[11px] text-emerald-700 font-bold hover:underline flex items-center space-x-1"
                      >
                        <Clipboard className="w-3 h-3" />
                        <span>Paste from Clipboard</span>
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        type={superShowKey ? 'text' : 'password'}
                        value={superSupabaseKey}
                        onChange={(e) => setSuperSupabaseKey(e.target.value)}
                        placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                        className="w-full bg-white border border-slate-300 rounded-xl p-2.5 font-mono text-xs text-slate-900 focus:border-emerald-600 focus:outline-none pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setSuperShowKey(!superShowKey)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        {superShowKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {superTestResult && (
                    <div
                      className={`p-3 rounded-xl border flex items-start space-x-2 text-xs ${
                        superTestResult.success ? 'bg-emerald-50 border-emerald-300 text-emerald-950' : 'bg-rose-50 border-rose-300 text-rose-950'
                      }`}
                    >
                      {superTestResult.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" /> : <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />}
                      <div>
                        <strong>{superTestResult.success ? 'Connected!' : 'Error'}</strong>: {superTestResult.message}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center gap-3 pt-2">
                    <button
                      type="button"
                      onClick={async () => {
                        setSuperTesting(true);
                        setSuperTestResult(null);
                        try {
                          const res = await testSupabaseConnection(superSupabaseUrl, superSupabaseKey);
                          setSuperTestResult(res);
                        } finally {
                          setSuperTesting(false);
                        }
                      }}
                      disabled={superTesting || !superSupabaseUrl || !superSupabaseKey}
                      className="px-4 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 font-bold text-slate-700 flex items-center space-x-1.5 transition-colors text-xs"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${superTesting ? 'animate-spin' : ''}`} />
                      <span>{superTesting ? 'Testing...' : 'Test Connection'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        applySupabaseCredentialsGlobally(superSupabaseUrl, superSupabaseKey);
                        updatePlatformSettings({
                          supabase_url: superSupabaseUrl.trim(),
                          supabase_anon_key: superSupabaseKey.trim()
                        });
                        alert('✅ Supabase credentials applied globally across the entire website!');
                      }}
                      disabled={!superSupabaseUrl || !superSupabaseKey}
                      className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black flex items-center space-x-1.5 transition-colors shadow-md text-xs"
                    >
                      <Zap className="w-3.5 h-3.5" />
                      <span>Apply & Connect Globally</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
