import React, { useState } from 'react';
import { useStore } from '../../store';
import { AdminSidebar } from '../../components/AdminSidebar';
import { 
  BookOpen, 
  DollarSign, 
  TrendingUp, 
  FileText, 
  Download, 
  AlertCircle, 
  Search,
  CheckCircle2,
  Calendar,
  Building2,
  ShieldCheck
} from 'lucide-react';
import { formatCurrency } from '../../lib/utils';
import { Order } from '../../types';
import jsPDF from 'jspdf';

export default function BookkeeperPanel() {
  const { 
    orders, 
    adminRevenueNgn, 
    currency, 
    activeStaffRole, 
    teamMembers, 
    loginStaffWithPin, 
    addToast 
  } = useStore();

  const isAuthorized = activeStaffRole === 'bookkeeper' || activeStaffRole === 'super_admin';
  const bookkeeperMember = teamMembers.find(m => m.role === 'bookkeeper');

  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const totalGrossSales = orders.reduce((acc, o) => acc + o.total_amount, 0);
  const totalPlatformFees = orders.reduce((acc, o) => acc + (o.platform_fee || 50), 0);
  const totalSellerPayouts = orders.reduce((acc, o) => acc + (o.seller_payout_amount || (o.total_amount - 50)), 0);

  const handlePinLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const res = loginStaffWithPin('bookkeeper', pinInput);
    if (!res.success) {
      setPinError(`Incorrect PIN. (Default Bookkeeper PIN is ${bookkeeperMember?.pin || '1122'})`);
    } else {
      setPinError('');
    }
  };

  // Download individual document / invoice PDF for an order
  const handleDownloadOrderPdf = (o: Order) => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();

      // Header Banner
      doc.setFillColor(15, 23, 42); // slate-900
      doc.rect(0, 0, pageWidth, 40, 'F');

      doc.setTextColor(255, 255, 255);
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text('MEGA MARKETPLACE NIGERIA', 14, 20);

      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(148, 163, 184); // slate-400
      doc.text('FINANCIAL BOOKKEEPING & ESCROW AUDIT CERTIFICATE', 14, 28);
      doc.text(`DATE GENERATED: ${new Date().toLocaleDateString()} | REF: AUD-${o.order_number}`, 14, 34);

      // Status Stamp Box
      doc.setFillColor(236, 253, 245); // emerald-50
      doc.setDrawColor(16, 185, 129); // emerald-500
      doc.roundedRect(pageWidth - 65, 12, 51, 20, 2, 2, 'FD');
      doc.setTextColor(6, 95, 70); // emerald-800
      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.text('AUDIT STATUS', pageWidth - 60, 20);
      doc.setFontSize(10);
      doc.text('RECONCILED & PAID', pageWidth - 60, 27);

      // Section: Document Meta
      let y = 52;
      doc.setTextColor(15, 23, 42);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('TRANSACTION AUDIT PARTICULARS', 14, y);

      y += 8;
      doc.setDrawColor(226, 232, 240); // slate-200
      doc.setLineWidth(0.5);
      doc.line(14, y, pageWidth - 14, y);

      y += 10;
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text('Order Number:', 14, y);
      doc.setFont('helvetica', 'normal');
      doc.text(o.order_number, 55, y);

      doc.setFont('helvetica', 'bold');
      doc.text('Transaction Date:', 110, y);
      doc.setFont('helvetica', 'normal');
      doc.text(new Date(o.created_at).toLocaleDateString(), 155, y);

      y += 8;
      doc.setFont('helvetica', 'bold');
      doc.text('Customer Name:', 14, y);
      doc.setFont('helvetica', 'normal');
      doc.text(o.customer_name || 'N/A', 55, y);

      doc.setFont('helvetica', 'bold');
      doc.text('Customer Phone:', 110, y);
      doc.setFont('helvetica', 'normal');
      doc.text(o.customer_phone || 'N/A', 155, y);

      y += 8;
      doc.setFont('helvetica', 'bold');
      doc.text('Payment Channel:', 14, y);
      doc.setFont('helvetica', 'normal');
      doc.text((o.payment_method || 'Bank Transfer').toUpperCase(), 55, y);

      doc.setFont('helvetica', 'bold');
      doc.text('Clearing Bank:', 110, y);
      doc.setFont('helvetica', 'normal');
      doc.text('UBA (2311406173)', 155, y);

      // Financial Ledger Breakdown Table
      y += 16;
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('ESCROW SETTLEMENT STATEMENT', 14, y);

      y += 6;
      doc.setFillColor(241, 245, 249); // slate-100
      doc.rect(14, y, pageWidth - 28, 8, 'F');
      doc.setFontSize(9);
      doc.setTextColor(71, 85, 105);
      doc.text('DESCRIPTION', 18, y + 5.5);
      doc.text('REVENUE ALLOCATION', 130, y + 5.5);
      doc.text('AMOUNT (NGN)', pageWidth - 45, y + 5.5);

      y += 14;
      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'normal');
      doc.text(`Total Gross Customer Purchase`, 18, y);
      doc.text('Escrow Holding', 130, y);
      doc.setFont('helvetica', 'bold');
      doc.text(`NGN ${o.total_amount.toLocaleString()}`, pageWidth - 45, y);

      y += 9;
      doc.setFont('helvetica', 'normal');
      doc.text('Mandatory Platform Deductions (Admin Fee)', 18, y);
      doc.text('Revenue Account (UBA)', 130, y);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(185, 28, 28); // rose-700
      doc.text(`- NGN ${(o.platform_fee || 50).toLocaleString()}`, pageWidth - 45, y);

      y += 9;
      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'normal');
      doc.text('Dispatched Merchant Payout', 18, y);
      doc.text('Seller Bank Settlement', 130, y);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(5, 150, 105); // emerald-600
      const netPayout = o.seller_payout_amount || (o.total_amount - 50);
      doc.text(`NGN ${netPayout.toLocaleString()}`, pageWidth - 45, y);

      // Summary Box
      y += 18;
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(203, 213, 225);
      doc.roundedRect(14, y, pageWidth - 28, 38, 2, 2, 'FD');

      doc.setTextColor(15, 23, 42);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text('BOOKKEEPING CERTIFICATION & ESCROW GUARANTEE', 20, y + 9);

      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text('This document certifies that order payments have been audited in compliance with the Central Bank', 20, y + 17);
      doc.text('escrow standards. All ₦50 fee deductions have been securely allocated to UBA clearing account: 2311406173 CYPRIAN MICHAEL OJOCHOGWU.', 20, y + 23);
      doc.text(`Signed: CYPRIAN MICHAEL OJOCHOGWU (Super Admin) & Chief Bookkeeper | Session Hash: ${Math.random().toString(36).substring(2, 10).toUpperCase()}`, 20, y + 30);

      // Save PDF
      doc.save(`MegaMarket-Audit-${o.order_number}.pdf`);
      addToast(`Downloaded audit document for ${o.order_number}!`, 'success', 'PDF Ready');
    } catch (err) {
      console.error(err);
      addToast('Error generating PDF document.', 'error');
    }
  };

  // Consolidated PDF Report of all ledger orders
  const handleDownloadConsolidatedPdf = () => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();

      // Header
      doc.setFillColor(15, 23, 42);
      doc.rect(0, 0, pageWidth, 42, 'F');

      doc.setTextColor(255, 255, 255);
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text('MEGA MARKETPLACE NIGERIA', 14, 18);

      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(148, 163, 184);
      doc.text('COMPLETE CONSOLIDATED FINANCIAL LEDGER REPORT', 14, 26);
      doc.text(`Generated on: ${new Date().toLocaleString()} | Clearing Account: UBA 2311406173`, 14, 34);

      // Key metrics row
      let y = 52;
      doc.setFillColor(241, 245, 249);
      doc.rect(14, y, pageWidth - 28, 20, 'F');

      doc.setTextColor(71, 85, 105);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.text('GROSS VOLUME', 20, y + 7);
      doc.text('PLATFORM REVENUE', 75, y + 7);
      doc.text('SELLER PAYOUTS', 130, y + 7);

      doc.setTextColor(15, 23, 42);
      doc.setFontSize(11);
      doc.text(`NGN ${totalGrossSales.toLocaleString()}`, 20, y + 15);
      doc.setTextColor(5, 150, 105);
      doc.text(`NGN ${adminRevenueNgn.toLocaleString()}`, 75, y + 15);
      doc.setTextColor(37, 99, 235);
      doc.text(`NGN ${totalSellerPayouts.toLocaleString()}`, 130, y + 15);

      // Orders Table Header
      y += 28;
      doc.setTextColor(15, 23, 42);
      doc.setFontSize(11);
      doc.setFont('helvetica', 'bold');
      doc.text('ITEMIZED AUDIT JOURNAL ENTRIES', 14, y);

      y += 6;
      doc.setFillColor(15, 23, 42);
      doc.rect(14, y, pageWidth - 28, 7, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(8);
      doc.text('ORDER #', 18, y + 5);
      doc.text('CUSTOMER', 55, y + 5);
      doc.text('GROSS (NGN)', 105, y + 5);
      doc.text('ADMIN FEE', 140, y + 5);
      doc.text('NET PAYOUT', pageWidth - 40, y + 5);

      y += 12;
      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);

      orders.forEach((ord, index) => {
        if (y > 270) {
          doc.addPage();
          y = 20;
        }

        const net = ord.seller_payout_amount || (ord.total_amount - 50);
        doc.text(ord.order_number, 18, y);
        doc.text((ord.customer_name || 'Customer').substring(0, 24), 55, y);
        doc.text(`NGN ${ord.total_amount.toLocaleString()}`, 105, y);
        doc.text(`NGN ${(ord.platform_fee || 50).toLocaleString()}`, 140, y);
        doc.text(`NGN ${net.toLocaleString()}`, pageWidth - 40, y);

        y += 7;
      });

      doc.save(`MegaMarket-Full-Ledger-Report-${Date.now()}.pdf`);
      addToast('Full consolidated ledger report downloaded!', 'success', 'PDF Ledger Exported');
    } catch (err) {
      console.error(err);
      addToast('Error exporting ledger PDF.', 'error');
    }
  };

  if (!isAuthorized) {
    return (
      <div className="flex min-h-screen bg-slate-900">
        <AdminSidebar activeRole="bookkeeper" />
        <main className="flex-1 p-6 sm:p-12 flex items-center justify-center">
          <div className="w-full max-w-md bg-white rounded-3xl p-8 border border-slate-200 shadow-2xl text-center space-y-6">
            <div className="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto shadow-lg">
              <BookOpen className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">Chief Bookkeeper Portal (/@admin)</h2>
              <p className="text-xs text-slate-500 mt-1">
                Enter your 4-digit PIN (<strong className="font-mono text-blue-600">{bookkeeperMember?.pin || '1122'}</strong>) to audit sales and download financial PDF documents.
              </p>
            </div>

            <form onSubmit={handlePinLogin} className="space-y-4">
              <input
                type="password"
                maxLength={6}
                value={pinInput}
                onChange={(e) => {
                  setPinInput(e.target.value);
                  setPinError('');
                }}
                placeholder="••••"
                className="w-full text-center text-2xl tracking-[0.5em] font-mono py-3.5 px-4 rounded-2xl border-2 border-slate-200 focus:border-blue-600 focus:outline-none bg-slate-50 font-bold"
                autoFocus
              />

              {pinError && (
                <div className="p-3 bg-rose-50 text-rose-700 text-xs rounded-xl flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{pinError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-2xl text-xs transition"
              >
                Unlock Bookkeeper Dashboard
              </button>
            </form>
          </div>
        </main>
      </div>
    );
  }

  const filteredOrders = orders.filter(o => 
    o.order_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    o.customer_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex min-h-screen bg-slate-100">
      <AdminSidebar activeRole="bookkeeper" />

      <main className="flex-1 p-6 sm:p-10 space-y-6 overflow-y-auto max-h-screen">
        {/* Header */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-black">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="bg-blue-100 text-blue-800 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                  Bookkeeper
                </span>
                <span className="text-[10px] font-mono text-slate-400">/@admin</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Financial Ledger & Document PDF Center
              </h1>
              <p className="text-xs text-slate-500">
                Audit every escrow settlement and download official signed PDF receipts and ledger statements.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleDownloadConsolidatedPdf}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center space-x-2 transition shadow-xs"
            >
              <Download className="w-4 h-4" />
              <span>Download Full Ledger (PDF)</span>
            </button>
          </div>
        </div>

        {/* 4 Financial Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
            <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider block">Gross Sales Volume</span>
            <div className="text-xl font-black text-slate-900 mt-1">
              {formatCurrency(totalGrossSales, currency)}
            </div>
            <span className="text-[11px] text-emerald-600 font-bold mt-1 block">100% Escrow Reconciled</span>
          </div>

          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
            <span className="text-[10px] font-black uppercase text-emerald-600 tracking-wider block">Admin Platform Charges</span>
            <div className="text-xl font-black text-emerald-700 mt-1">
              ₦{adminRevenueNgn.toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-400 font-medium mt-1 block">₦50 fees credited to UBA</span>
          </div>

          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
            <span className="text-[10px] font-black uppercase text-blue-600 tracking-wider block">Merchant Payouts</span>
            <div className="text-xl font-black text-blue-700 mt-1">
              {formatCurrency(totalSellerPayouts, currency)}
            </div>
            <span className="text-[11px] text-slate-400 font-medium mt-1 block">Net payout after fee</span>
          </div>

          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
            <span className="text-[10px] font-black uppercase text-purple-600 tracking-wider block">Ledger Rows Audited</span>
            <div className="text-xl font-black text-purple-700 mt-1">
              {orders.length} Documents Available
            </div>
            <span className="text-[11px] text-purple-600 font-bold mt-1 block">All ready for PDF download</span>
          </div>
        </div>

        {/* Audit Table with Individual PDF Downloads */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-black text-slate-900">Itemized Financial Documents & Audit Records</h3>
              <p className="text-xs text-slate-500">
                Click "Download PDF" on any document to export an official signed transaction statement.
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search order or customer..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-blue-600"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 uppercase text-[10px] font-black">
                  <th className="py-3 px-3">Order Number</th>
                  <th className="py-3 px-3">Customer</th>
                  <th className="py-3 px-3">Gross Total</th>
                  <th className="py-3 px-3">Admin Fee (₦50)</th>
                  <th className="py-3 px-3">Net Seller Payout</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3 text-right">Download Document</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredOrders.map((o) => (
                  <tr key={o.id} className="hover:bg-slate-50 transition">
                    <td className="py-3 px-3 font-mono font-bold text-blue-600">{o.order_number}</td>
                    <td className="py-3 px-3 font-bold text-slate-900">{o.customer_name}</td>
                    <td className="py-3 px-3 font-black text-slate-900">{formatCurrency(o.total_amount, currency)}</td>
                    <td className="py-3 px-3 font-mono font-bold text-emerald-600">₦{(o.platform_fee || 50).toLocaleString()}</td>
                    <td className="py-3 px-3 font-black text-slate-700">
                      {formatCurrency(o.seller_payout_amount || (o.total_amount - 50), currency)}
                    </td>
                    <td className="py-3 px-3">
                      <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                        {o.payment_status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => handleDownloadOrderPdf(o)}
                        className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-3 py-1.5 rounded-xl text-xs transition flex items-center space-x-1.5 ml-auto shadow-xs active:scale-95"
                        title="Download Signed PDF Document"
                      >
                        <FileText className="w-3.5 h-3.5 text-blue-400" />
                        <span>Download PDF</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
