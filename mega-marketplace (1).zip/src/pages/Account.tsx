import React, { useState } from 'react';
import { useStore } from '../store';
import { formatCurrency } from '../lib/utils';
import RewardsDashboardWidget from '../components/RewardsDashboardWidget';
import { ImageDropzone } from '../components/ImageDropzone';
import { NEUTRAL_AVATAR_PRESETS } from '../services/mockData';
import { UserAvatar } from '../components/UserAvatar';
import { 
  User, 
  Wallet, 
  Package, 
  Heart, 
  MapPin, 
  Share2, 
  HelpCircle, 
  Shield, 
  Copy, 
  Check, 
  Plus, 
  ArrowRight, 
  ExternalLink, 
  Clock, 
  ShieldCheck, 
  CreditCard,
  ChevronRight,
  AlertCircle,
  Building,
  Edit3,
  Phone,
  Mail,
  Lock,
  Gift,
  Sparkles,
  Users,
  LogOut,
  RefreshCw,
  Truck,
  CheckCircle2,
  XCircle,
  Building2,
  Calendar,
  Camera,
  MessageSquare,
  Briefcase,
  Zap,
  Globe
} from 'lucide-react';
import { evaluatePasswordSecurity, isValidEmail, isValidPhone, clearAuthAttempts } from '../lib/security';
import { supabase } from '../lib/supabase';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Order } from '../types';

export default function Account() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const isBrandRegistration = searchParams.get('action') === 'register_brand' || searchParams.get('mode') === 'signup';
  const roleFromQuery = searchParams.get('role') === 'seller' || isBrandRegistration ? 'seller' : 'customer';

  const { 
    user, 
    registeredUsers,
    switchUserAccount,
    logoutUser,
    updateUserProfile,
    updateConnectedPaymentGateways,
    serviceBookings,
    jobInquiries,
    walletBalance, 
    walletTransactions, 
    orders, 
    wishlist, 
    topUpWallet,
    verifyAdminPassword,
    isAdminAuthenticated,
    isAuthenticated,
    loginUser,
    signupUser,
    currency,
    addToast
  } = useStore();

  const [activeTab, setActiveTab] = useState<'settlement' | 'rewards' | 'gateways' | 'inquiries' | 'orders' | 'profile' | 'switch'>('settlement');
  const [topUpAmount, setTopUpAmount] = useState('');
  const [showTopUpModal, setShowTopUpModal] = useState(false);
  const [topUpPaymentMethod, setTopUpPaymentMethod] = useState<'card' | 'bank_transfer' | 'ussd'>('bank_transfer');
  
  // Unauthenticated client auth state
  const [authMode, setAuthMode] = useState<'login' | 'signup'>(isBrandRegistration ? 'signup' : 'login');
  const [authIdentifier, setAuthIdentifier] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [signupRole, setSignupRole] = useState<'customer' | 'seller'>(roleFromQuery);
  const [signupBusiness, setSignupBusiness] = useState('');
  const [signupAvatar, setSignupAvatar] = useState('');

  // Seller Payment Gateways state
  const [gwPaystackSubaccount, setGwPaystackSubaccount] = useState(user?.connected_gateways?.paystack_subaccount_code || user?.paystack_subaccount_code || '');
  const [gwFlutterwaveId, setGwFlutterwaveId] = useState(user?.connected_gateways?.flutterwave_subaccount_id || '');
  const [gwBankName, setGwBankName] = useState(user?.connected_gateways?.bank_name || user?.bank_details?.bank_name || 'Guaranty Trust Bank (GTBank)');
  const [gwAccountNumber, setGwAccountNumber] = useState(user?.connected_gateways?.account_number || user?.bank_details?.account_number || '');
  const [gwAccountName, setGwAccountName] = useState(user?.connected_gateways?.account_name || user?.bank_details?.account_name || user?.full_name || '');
  const [gwStripeId, setGwStripeId] = useState(user?.connected_gateways?.stripe_account_id || '');
  const [gwCryptoAddress, setGwCryptoAddress] = useState(user?.connected_gateways?.crypto_usdt_address || '');
  const [gwPrimary, setGwPrimary] = useState<'paystack' | 'flutterwave' | 'bank_transfer' | 'stripe' | 'crypto'>(user?.connected_gateways?.primary_gateway || 'bank_transfer');
  const [gwSaving, setGwSaving] = useState(false);

  // Profile edit state
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [fullName, setFullName] = useState(user?.full_name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [businessName, setBusinessName] = useState(user?.business_name || '');
  const [businessAddress, setBusinessAddress] = useState(user?.business_address || '');
  const [clientWebsite, setClientWebsite] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [paystackSubaccountCode, setPaystackSubaccountCode] = useState(user?.paystack_subaccount_code || '');
  const [avatarUrl, setAvatarUrl] = useState(user?.avatar_url || '');

  // Admin Gate Password modal
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [adminError, setAdminError] = useState(false);

  // Selected Order for tracking modal
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);



  const handleClientLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authIdentifier.trim()) {
      addToast('Please enter your email address or phone number.', 'error');
      return;
    }
    const res = loginUser(authIdentifier.trim());
    if (res.success && res.user) {
      setFullName(res.user.full_name);
      setEmail(res.user.email || '');
      setPhone(res.user.phone || '');
      setAvatarUrl(res.user.avatar_url || '');
    }
  };

  const handleClientSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupName.trim() || signupName.trim().length < 2) {
      addToast('Please enter your full legal name.', 'error');
      return;
    }
    if (!isValidEmail(signupEmail)) {
      addToast('Please enter a valid email address.', 'error');
      return;
    }
    if (!isValidPhone(signupPhone)) {
      addToast('Please enter a valid phone number (10-14 digits).', 'error');
      return;
    }

    const res = signupUser({
      full_name: signupName.trim(),
      email: signupEmail.trim(),
      phone: signupPhone.trim(),
      role: signupRole,
      business_name: signupBusiness.trim() || undefined,
      avatar_url: signupAvatar || undefined
    });
    if (res.success && res.user) {
      setFullName(res.user.full_name);
      setEmail(res.user.email || '');
      setPhone(res.user.phone || '');
      setAvatarUrl(res.user.avatar_url || '');
      if (signupRole === 'seller' || isBrandRegistration) {
        addToast(`Brand "${signupBusiness.trim() || res.user.full_name}" registered! You can now start posting and managing your sales.`, 'success', 'Brand Registered');
        navigate('/sell');
      }
    }
  };

  const handleSaveGateways = (e: React.FormEvent) => {
    e.preventDefault();
    setGwSaving(true);
    updateConnectedPaymentGateways({
      paystack_enabled: !!gwPaystackSubaccount.trim(),
      paystack_subaccount_code: gwPaystackSubaccount.trim(),
      flutterwave_enabled: !!gwFlutterwaveId.trim(),
      flutterwave_subaccount_id: gwFlutterwaveId.trim(),
      bank_transfer_enabled: !!(gwBankName && gwAccountNumber),
      bank_name: gwBankName,
      account_number: gwAccountNumber.trim(),
      account_name: gwAccountName.trim(),
      stripe_enabled: !!gwStripeId.trim(),
      stripe_account_id: gwStripeId.trim(),
      crypto_usdt_address: gwCryptoAddress.trim(),
      primary_gateway: gwPrimary,
      is_verified: true
    });
    setTimeout(() => {
      setGwSaving(false);
      addToast('Payment gateways connected and verified for seller payouts!', 'success', 'Gateways Active');
    }, 400);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();

    if (newPasswordInput && newPasswordInput !== confirmPasswordInput) {
      addToast('New password confirmation does not match.', 'error');
      return;
    }

    updateUserProfile({
      full_name: fullName,
      email,
      phone,
      business_name: businessName,
      business_address: businessAddress,
      paystack_subaccount_code: paystackSubaccountCode,
      avatar_url: avatarUrl
    });

    if (newPasswordInput) {
      addToast('Password updated securely!', 'success');
      setNewPasswordInput('');
      setConfirmPasswordInput('');
    }

    setIsEditingProfile(false);
    addToast('Profile details saved successfully!', 'success');
  };

  const handleTopUp = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(topUpAmount);
    if (!amount || amount <= 0) return;

    topUpWallet(amount, `TOP-${Math.floor(100000 + Math.random() * 900000)}`);
    setTopUpAmount('');
    setShowTopUpModal(false);
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const ok = verifyAdminPassword(adminPasswordInput);
    if (ok) {
      setShowAdminModal(false);
      navigate('/admin');
    } else {
      setAdminError(true);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="py-8 max-w-xl mx-auto px-4 space-y-6">
        {/* Remote Team Recruitment Announcement */}
        <div className="bg-gradient-to-r from-blue-900 to-indigo-950 text-white p-5 rounded-3xl border border-blue-700/50 shadow-md flex items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
              Community Hiring Open
            </span>
            <h4 className="text-sm font-black text-white">Apply for Remote Operations Staff</h4>
            <p className="text-xs text-slate-300">
              7 positions available for Bookkeeper, Money Checker, and Ad Managers.
            </p>
          </div>
          <Link
            to="/apply"
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3.5 py-2 rounded-xl text-xs shrink-0 transition"
          >
            Apply Now →
          </Link>
        </div>

        {/* Client Sign In / Register Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xl space-y-6">
          <div className="text-center space-y-2">
            <div className="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto shadow-md">
              <User className="w-7 h-7" />
            </div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">Customer & Merchant Account</h2>
            <p className="text-xs text-slate-500">
              Sign in or create an account to manage your purchases, seller payouts, and profile.
            </p>
          </div>

          {/* Brand Registration Welcome Notice */}
          {isBrandRegistration && (
            <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-4 text-center space-y-1.5 border border-blue-600 shadow-md">
              <div className="inline-flex items-center space-x-1.5 text-amber-300 font-black text-xs">
                <Sparkles className="w-4 h-4" />
                <span>Register Your Brand & Begin Sales</span>
              </div>
              <p className="text-xs text-blue-100 max-w-sm mx-auto">
                Create your merchant store profile below. You will be able to post products/services, connect your payout gateways, and start selling immediately!
              </p>
            </div>
          )}

          {/* Bank-Grade 256-Bit Encrypted Portal Badge */}
          <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white p-3.5 rounded-2xl border border-blue-500/30 flex items-center justify-between shadow-xs">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-xl bg-blue-600/30 border border-blue-400/40 flex items-center justify-center text-blue-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              </div>
              <div>
                <div className="flex items-center space-x-1.5">
                  <span className="text-xs font-black text-white">Bank-Grade 256-Bit SSL Protection</span>
                  <span className="text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded font-mono font-bold">ACTIVE</span>
                </div>
                <p className="text-[10px] text-slate-300">Direct encrypted credentials • Anti-tamper sessions • Escrow safe</p>
              </div>
            </div>
          </div>

          {/* Toggle Tab */}
          <div className="flex bg-slate-100 p-1 rounded-2xl text-xs font-bold">
            <button
              onClick={() => setAuthMode('login')}
              className={`flex-1 py-2.5 rounded-xl transition ${
                authMode === 'login' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setAuthMode('signup')}
              className={`flex-1 py-2.5 rounded-xl transition ${
                authMode === 'signup' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
              }`}
            >
              Register Account
            </button>
          </div>

          {authMode === 'login' ? (
            <form onSubmit={handleClientLogin} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Email or Phone Number</label>
                <input
                  type="text"
                  required
                  value={authIdentifier}
                  onChange={(e) => setAuthIdentifier(e.target.value)}
                  placeholder="e.g. buyer@example.com or 08012345678"
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-semibold text-slate-900"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Password</label>
                <input
                  type="password"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-3.5 rounded-2xl text-xs sm:text-sm shadow-md shadow-blue-600/20 active:scale-95 transition-all"
              >
                Sign In to Account (Click & Enter)
              </button>

              <div className="pt-2 text-center space-y-2">
                <span className="text-[11px] text-slate-400 block">Or quick click & enter with email:</span>
                <div className="flex flex-wrap justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (authIdentifier.includes('@')) {
                        loginUser(authIdentifier);
                      } else {
                        loginUser('shopper@megamarket.ng');
                      }
                    }}
                    className="px-3.5 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-bold border border-blue-200"
                  >
                    ⚡ Enter with Typed Email
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      loginUser('amaka@techhaven.ng');
                    }}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
                  >
                    Merchant (Amaka Eze)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      loginUser('cyprian@megamarket.ng');
                    }}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
                  >
                    Admin Account
                  </button>
                </div>
              </div>
            </form>
          ) : (
            <form onSubmit={handleClientSignup} className="space-y-4 text-xs">
              {/* DRAG & DROP PROFILE / BRAND LOGO AVATAR UPLOAD */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  {signupRole === 'seller' ? 'Brand / Store Logo (Drag & Drop or Click)' : 'Profile Picture (Drag & Drop or Click)'}
                </label>
                <ImageDropzone
                  value={signupAvatar}
                  onChange={setSignupAvatar}
                  aspectRatio="avatar"
                  placeholderText="Drag & drop image here or click to browse"
                  helperText="Supports PNG, JPG, WEBP formats"
                  className="h-28"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Full Legal Name</label>
                <input
                  type="text"
                  required
                  value={signupName}
                  onChange={(e) => setSignupName(e.target.value)}
                  placeholder="e.g. Kalu Johnson"
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-semibold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 mb-1 block">Email</label>
                  <input
                    type="email"
                    required
                    value={signupEmail}
                    onChange={(e) => setSignupEmail(e.target.value)}
                    placeholder="kalu@example.com"
                    className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 mb-1 block">Phone</label>
                  <input
                    type="tel"
                    required
                    value={signupPhone}
                    onChange={(e) => setSignupPhone(e.target.value)}
                    placeholder="+234 803 000 1122"
                    className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 mb-1 block">Account Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSignupRole('customer')}
                    className={`p-2.5 rounded-xl border font-bold ${
                      signupRole === 'customer' ? 'border-blue-600 bg-blue-50 text-blue-900' : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    Shopper / Customer
                  </button>
                  <button
                    type="button"
                    onClick={() => setSignupRole('seller')}
                    className={`p-2.5 rounded-xl border font-bold ${
                      signupRole === 'seller' ? 'border-blue-600 bg-blue-50 text-blue-900' : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    Merchant Seller Store
                  </button>
                </div>
              </div>

              {signupRole === 'seller' && (
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Business Name</label>
                  <input
                    type="text"
                    value={signupBusiness}
                    onChange={(e) => setSignupBusiness(e.target.value)}
                    placeholder="e.g. Kalu Mega Logistics & Gadgets"
                    className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-3.5 rounded-2xl text-xs sm:text-sm shadow-md active:scale-95 transition-all"
              >
                Create Account and get 3 times free trial post bonus
              </button>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div id="account-dashboard-page" className="py-4 md:py-6 max-w-7xl mx-auto space-y-6">
      
      {/* DESKTOP TOP HEADER / HERO PROFILE BANNER */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs relative overflow-hidden">
        {/* Subtle Decorative Accent */}
        <div className="absolute top-0 right-0 w-96 h-full bg-gradient-to-l from-blue-50/60 to-transparent pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center space-x-4 sm:space-x-5">
            <div className="relative shrink-0">
              <UserAvatar
                src={user.avatar_url}
                alt={user.full_name}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl border-2 border-blue-600 shadow-md"
              />
              <span className="absolute -bottom-1 -right-1 bg-blue-600 text-white p-1 rounded-full text-xs shadow-xs" title="Verified Account">
                <ShieldCheck className="w-3.5 h-3.5" />
              </span>
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">{user.full_name}</h1>
                <span className="bg-blue-100 text-blue-800 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                  {user.role} Member
                </span>
                <span className="bg-amber-100 text-amber-900 text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center space-x-1">
                  <Sparkles className="w-3 h-3 text-amber-600 fill-amber-600" />
                  <span>VIP Tier Active</span>
                </span>
              </div>

              <p className="text-xs text-slate-500 font-medium">
                {user.email || 'user@megamarket.ng'} • {user.phone || '+234 704 409 5544'}
              </p>

              {user.business_name && (
                <div className="flex items-center text-xs font-bold text-blue-600">
                  <Building className="w-3.5 h-3.5 mr-1" />
                  <span>{user.business_name}</span>
                </div>
              )}
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            <button
              onClick={() => setActiveTab('settlement')}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow-md shadow-blue-600/20 active:scale-95 transition-all flex items-center space-x-1.5"
            >
              <Building className="w-4 h-4" />
              <span>Official Settlement Account</span>
            </button>

            <button
              onClick={() => setIsEditingProfile(!isEditingProfile)}
              className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-3.5 py-2.5 rounded-xl text-xs transition-colors flex items-center space-x-1.5"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isEditingProfile ? 'Close Edit' : 'Edit Profile'}</span>
            </button>

            <button
              onClick={() => {
                logoutUser();
                navigate('/');
              }}
              className="bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold px-3 py-2.5 rounded-xl text-xs transition-colors flex items-center space-x-1"
              title="Sign Out"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>

        {/* Profile Edit Drawer / Form */}
        {isEditingProfile && (
          <form onSubmit={handleSaveProfile} className="mt-6 pt-6 border-t border-slate-100 space-y-4 text-xs animate-in slide-in-from-top-2">
            <div className="flex items-center justify-between">
              <h4 className="font-black text-slate-900 text-sm">Update Account & Business Details</h4>
              <span className="text-[11px] text-slate-400">Updates reflect across all orders and invoices.</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="sm:col-span-2 lg:col-span-3 space-y-3">
                <label className="font-bold text-slate-700 block text-xs">Profile Picture (Drag & Drop or Choose Neutral Preset)</label>
                
                <ImageDropzone 
                  value={avatarUrl} 
                  onChange={setAvatarUrl} 
                  label="Drag & Drop Profile Image Here"
                  placeholderText="Drop picture here from computer/phone or click to browse"
                  helperText="Supports PNG, JPG, WEBP formats"
                />

                {/* Neutral Avatar Presets */}
                <div className="space-y-1.5 pt-1">
                  <span className="text-[11px] font-bold text-slate-600">Or Select a Neutral Avatar:</span>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {NEUTRAL_AVATAR_PRESETS.map((preset) => (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => setAvatarUrl(preset.url)}
                        className={`p-1.5 rounded-xl border flex flex-col items-center transition-all ${
                          avatarUrl === preset.url
                            ? 'border-blue-600 bg-blue-50/80 shadow-xs'
                            : 'border-slate-200 hover:border-slate-300 bg-white'
                        }`}
                      >
                        <img src={preset.url} alt={preset.name} className="w-10 h-10 rounded-lg object-cover mb-1" />
                        <span className="text-[9px] font-medium text-slate-600 line-clamp-1">{preset.name.split(' ')[0]}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Full Legal Name</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Phone Number</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Store / Business Name (Optional)</label>
                <input
                  type="text"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  placeholder="e.g. Cyprian Electronics & Gadgets"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Business Address / Location</label>
                <input
                  type="text"
                  value={businessAddress}
                  onChange={(e) => setBusinessAddress(e.target.value)}
                  placeholder="e.g. Ankpa Commercial Axis, Kogi State, Nigeria"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Paystack Subaccount Code (Split Payments)</label>
                <input
                  type="text"
                  value={paystackSubaccountCode}
                  onChange={(e) => setPaystackSubaccountCode(e.target.value)}
                  placeholder="ACCT_xxxxxxxxxxxxx"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
                <p className="text-[10px] text-slate-500 mt-1 font-medium">Connect your Paystack account to receive payments directly.</p>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Your External Website / Portfolio</label>
                <input
                  type="url"
                  value={clientWebsite}
                  onChange={(e) => setClientWebsite(e.target.value)}
                  placeholder="https://yourbrand.com"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
                <p className="text-[10px] text-slate-500 mt-1 font-medium">Allows buyers to pass through the application directly to your website.</p>
              </div>

              {/* Password Change Fields */}
              <div className="sm:col-span-2 lg:col-span-3 pt-3 border-t border-slate-100">
                <span className="font-bold text-slate-900 text-xs block mb-2">Change Password</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-600 block mb-1">New Password</label>
                    <input
                      type="password"
                      value={newPasswordInput}
                      onChange={(e) => setNewPasswordInput(e.target.value)}
                      placeholder="Enter new password"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-600 block mb-1">Confirm New Password</label>
                    <input
                      type="password"
                      value={confirmPasswordInput}
                      onChange={(e) => setConfirmPasswordInput(e.target.value)}
                      placeholder="Repeat new password"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Remote Team Application Banner in Profile */}
              <div className="sm:col-span-2 lg:col-span-3 p-4 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <span className="font-black text-slate-900 text-xs flex items-center space-x-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    <span>Want to Join Our Executive Remote Team?</span>
                  </span>
                  <p className="text-[11px] text-slate-600">
                    7 positions currently open for Bookkeepers, Money Checkers & Ad Managers.
                  </p>
                </div>
                <Link
                  to="/apply"
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-3.5 py-2 rounded-xl text-xs shrink-0 self-start sm:self-auto transition"
                >
                  Apply Here →
                </Link>
              </div>
            </div>

            <div className="flex space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEditingProfile(false)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-2 rounded-xl shadow-md active:scale-95 transition-all"
              >
                Save Changes
              </button>
            </div>
          </form>
        )}
      </div>

      {/* OFFICIAL SETTLEMENT ACCOUNT & POLICY BANNER - DISPLAYED FOR EVERY CUSTOMER / POST-CREATION */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-950 text-white rounded-3xl p-6 sm:p-8 border-2 border-blue-500/40 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 px-3 py-1 rounded-full text-[11px] font-black border border-emerald-400/30">
              <Building className="w-3.5 h-3.5" />
              <span>Official Mega Store Settlement Account</span>
            </div>
            <h3 className="text-xl font-black text-white">
              Store Settlement Account: UBA 2311406173 (CYPRIAN MICHAEL OJOCHOGWU)
            </h3>
            <p className="text-xs text-blue-200/90 leading-relaxed max-w-2xl">
              Store Policy: You do not need to fund any wallet. Post your products, sell freely, and get paid directly into your own bank account by buyers. All official store administrative settlement is routed through this central account.
            </p>
          </div>
          <div className="bg-white/10 backdrop-blur-xs p-4 rounded-2xl border border-white/10 flex items-center space-x-3 self-start md:self-auto shrink-0">
            <div>
              <span className="text-[10px] text-blue-200 uppercase tracking-wider block font-bold">United Bank for Africa (UBA)</span>
              <span className="text-xl font-mono font-black text-amber-400 block">2311406173</span>
              <span className="text-[10px] text-white/80 font-medium block">CYPRIAN MICHAEL OJOCHOGWU</span>
            </div>
            <button
              onClick={() => {
                navigator.clipboard.writeText('2311406173');
                addToast('Official Settlement Account (2311406173 UBA) copied!', 'success');
              }}
              className="p-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition-colors shadow-xs"
              title="Copy Account Number"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 3 TIMES FREE TRIAL STORE POLICY MESSAGE */}
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-400/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 font-black flex items-center justify-center shrink-0">
              <Gift className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-amber-300 block text-xs">
                Store Policy & Settlement Plan: 3 Times Free Trial Listing Bonus Unlocked!
              </span>
              <span className="text-[11px] text-slate-300 block">
                Post your first 3 items 100% free with zero fees. After trial, pay standard ₦50 settlement fee directly to the account above.
              </span>
            </div>
          </div>
          <Link
            to="/sell"
            className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-black px-4 py-2 rounded-xl text-xs shrink-0 self-start sm:self-auto transition-transform active:scale-95 shadow-sm text-center"
          >
            Post Product Now →
          </Link>
        </div>
      </div>

      {/* RESPONSIVE NAVIGATION TABS BAR */}
      <div className="flex bg-white p-1.5 rounded-2xl border border-slate-200 text-xs font-bold space-x-1 overflow-x-auto shadow-xs">
        <button
          onClick={() => setActiveTab('rewards')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'rewards' 
              ? 'bg-blue-600 text-white shadow-xs' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Gift className="w-4 h-4" />
          <span>Rewards & Sales Calculator</span>
        </button>

        <button
          onClick={() => setActiveTab('wallet')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'wallet' 
              ? 'bg-blue-600 text-white shadow-xs' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>Mega Wallet</span>
        </button>

        <button
          onClick={() => setActiveTab('gateways')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'gateways' 
              ? 'bg-blue-600 text-white shadow-xs' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>Payment Gateways & Payouts</span>
        </button>

        <button
          onClick={() => setActiveTab('inquiries')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'inquiries' 
              ? 'bg-blue-600 text-white shadow-xs' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Inquiries & Job Applications ({serviceBookings.length + jobInquiries.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'orders' 
              ? 'bg-blue-600 text-white shadow-xs' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>My Orders & Dispatch Tracking ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('switch')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'switch' 
              ? 'bg-blue-600 text-white shadow-xs' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Switch Account Persona</span>
        </button>
      </div>

      {/* TAB 1: STAR REWARDS & SALES ACTIVITY DASHBOARD WIDGET */}
      {activeTab === 'rewards' && (
        <RewardsDashboardWidget />
      )}

      {/* TAB: OFFICIAL SETTLEMENT ACCOUNT & STORE POLICY (3 TIMES FREE TRIAL) */}
      {activeTab === 'settlement' && (
        <div className="space-y-6 animate-in fade-in-50">
          {/* Top Settlement Overview Header Banner */}
          <div className="bg-gradient-to-r from-slate-950 via-blue-950 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 border border-blue-600/30 shadow-xl relative overflow-hidden">
            <div className="relative z-10 space-y-3">
              <div className="inline-flex items-center space-x-2 bg-emerald-500/20 border border-emerald-400/30 px-3 py-1 rounded-full text-xs font-bold text-emerald-300">
                <Building className="w-3.5 h-3.5 text-emerald-400" />
                <span>Central Store Settlement Bank & Merchant Operating Policy</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
                Official Mega Store Settlement Account
              </h2>
              <p className="text-xs sm:text-sm text-blue-200/90 max-w-2xl leading-relaxed">
                Welcome to Mega Marketplace. Customers and sellers do not fund any wallet. You post your products to sell, provide your own receiving bank account for direct buyer transfers, and all store administrative settlement is processed directly into the official store settlement account.
              </p>
            </div>
          </div>

          {/* POLICY NOTICE: 3 TIMES FREE TRIAL POST BONUS */}
          <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-50 via-orange-50 to-amber-100/60 border-2 border-amber-300 shadow-sm space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-2xl bg-amber-500 text-white flex items-center justify-center font-black shadow-sm">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-amber-950 text-base">Store Policy: 3 Times Free Trial Listing Plan</h3>
                  <span className="text-[11px] font-bold text-amber-800">Zero upfront funding required for every new account</span>
                </div>
              </div>
              <span className="bg-amber-600 text-white text-xs font-black px-3 py-1 rounded-full shadow-xs">
                3 FREE TRIAL POSTS UNLOCKED 🎁
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-1">
              <div className="bg-white/90 p-4 rounded-2xl border border-amber-200 space-y-1.5 shadow-2xs">
                <span className="font-black text-slate-900 block text-xs">1. Post Products Freely</span>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Every new registered customer gets <strong>3 Times Free Trial</strong> product listings. No wallet funding is required at any time.
                </p>
              </div>
              <div className="bg-white/90 p-4 rounded-2xl border border-amber-200 space-y-1.5 shadow-2xs">
                <span className="font-black text-slate-900 block text-xs">2. Buyers Pay You Directly</span>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Provide your own Nigerian bank account and WhatsApp number. At checkout, buyers see your account details and send payment directly to you.
                </p>
              </div>
              <div className="bg-white/90 p-4 rounded-2xl border border-amber-200 space-y-1.5 shadow-2xs">
                <span className="font-black text-slate-900 block text-xs">3. Store Settlement Fee</span>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  After your 3 free trials, each standard post incurs only ₦50 platform settlement directly to the official Mega Store settlement account.
                </p>
              </div>
            </div>
          </div>

          {/* OFFICIAL MEGA STORE SETTLEMENT ACCOUNT CARD */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-blue-600 shadow-md space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <span className="text-[11px] font-black uppercase tracking-wider text-blue-600 block mb-0.5">
                  Central Treasury & Platform Settlement
                </span>
                <h3 className="text-xl font-black text-slate-900">Official Store Settlement Account</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  This is the official account for all platform settlements, listing verifications, and store fees.
                </p>
              </div>
              <div className="flex items-center space-x-2 bg-emerald-50 text-emerald-800 text-xs font-bold px-3 py-1.5 rounded-xl border border-emerald-200 self-start sm:self-auto">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Verified CBN / NIBSS Settlement Route</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[11px] text-slate-500 font-bold block mb-1 uppercase tracking-wider">Settlement Bank</span>
                <span className="text-base font-black text-slate-900 block">United Bank for Africa (UBA)</span>
                <span className="text-[10px] text-blue-600 font-semibold block mt-1">Commercial Bank, Nigeria</span>
              </div>

              <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-blue-900 font-bold block mb-1 uppercase tracking-wider">NUBAN Account Number</span>
                  <span className="text-2xl font-mono font-black text-blue-950 tracking-wider block">2311406173</span>
                  <span className="text-[10px] text-emerald-700 font-bold block mt-1">Instant NIBSS Credit</span>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText('2311406173');
                    addToast('Official Settlement Account Number (2311406173) copied to clipboard!', 'success');
                  }}
                  className="p-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-xs transition-colors"
                  title="Copy Account Number"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[11px] text-slate-500 font-bold block mb-1 uppercase tracking-wider">Account Beneficiary</span>
                <span className="text-base font-black text-slate-900 block">CYPRIAN MICHAEL OJOCHOGWU</span>
                <span className="text-[10px] text-slate-500 font-semibold block mt-1">CEO & Store Administrator</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
              <div className="flex items-center space-x-2 text-slate-600 font-semibold">
                <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Zero customer wallet funding needed. Post products, get direct buyer payments into your account.</span>
              </div>
              <a
                href="https://wa.me/234704409544?text=Hello%20Cyprian%20Michael%20Ojochogwu%2C%20I%20have%20inquiries%20about%20the%20settlement%20plan%20and%20product%20listing."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl text-xs shadow-xs transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Direct WhatsApp Settlement Support (+234 704 409 5544)</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* TAB: PAYMENT GATEWAYS & SELLER PAYOUT CONNECTIONS */}
      {activeTab === 'gateways' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <h3 className="font-black text-slate-900 text-lg flex items-center space-x-2">
                  <CreditCard className="w-5 h-5 text-blue-600" />
                  <span>Connect Your Payment Gateways & Payout Routing</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Connect Paystack, Flutterwave, or your Nigerian commercial bank account to receive automatic order payouts directly.
                </p>
              </div>
              <div className="flex items-center space-x-2 bg-emerald-50 text-emerald-800 text-xs font-bold px-3 py-1.5 rounded-xl border border-emerald-200 shrink-0 self-start sm:self-auto">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Instant Escrow Disbursement</span>
              </div>
            </div>

            <form onSubmit={handleSaveGateways} className="space-y-6 text-xs">
              {/* Primary Method Selector */}
              <div className="space-y-2">
                <label className="font-bold text-slate-900 text-xs block">Choose Primary Payout Channel</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { id: 'bank_transfer', label: 'Direct Bank (NGN)', icon: Building2 },
                    { id: 'paystack', label: 'Paystack Subaccount', icon: CreditCard },
                    { id: 'flutterwave', label: 'Flutterwave', icon: Sparkles },
                    { id: 'crypto', label: 'USDT / Crypto TRC20', icon: Wallet },
                  ].map((gateway) => (
                    <button
                      key={gateway.id}
                      type="button"
                      onClick={() => setGwPrimary(gateway.id as any)}
                      className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                        gwPrimary === gateway.id
                          ? 'border-blue-600 bg-blue-50/70 text-blue-900 shadow-sm ring-1 ring-blue-600'
                          : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-slate-50/50'
                      }`}
                    >
                      <gateway.icon className={`w-5 h-5 mb-2 ${gwPrimary === gateway.id ? 'text-blue-600' : 'text-slate-500'}`} />
                      <span className="font-bold text-xs">{gateway.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Nigerian Bank Account */}
              <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/60 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Building2 className="w-4 h-4 text-blue-600" />
                    <h4 className="font-black text-slate-900 text-xs uppercase tracking-wider">Nigerian Bank Account (NIBSS Fast Payout)</h4>
                  </div>
                  <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    Recommended
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Select Bank</label>
                    <select
                      value={gwBankName}
                      onChange={(e) => setGwBankName(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl p-2.5 font-medium text-slate-900 focus:border-blue-600 focus:outline-none"
                    >
                      <option value="Guaranty Trust Bank (GTBank)">Guaranty Trust Bank (GTBank)</option>
                      <option value="United Bank for Africa (UBA)">United Bank for Africa (UBA)</option>
                      <option value="Zenith Bank">Zenith Bank</option>
                      <option value="Access Bank">Access Bank</option>
                      <option value="First Bank of Nigeria">First Bank of Nigeria</option>
                      <option value="Kuda Microfinance Bank">Kuda Bank</option>
                      <option value="OPay Digital Services">OPay</option>
                      <option value="Moniepoint Microfinance Bank">Moniepoint</option>
                      <option value="Fidelity Bank">Fidelity Bank</option>
                      <option value="Stanbic IBTC Bank">Stanbic IBTC Bank</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-bold text-slate-700 block mb-1">10-Digit Account Number</label>
                    <input
                      type="text"
                      maxLength={10}
                      value={gwAccountNumber}
                      onChange={(e) => setGwAccountNumber(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="e.g. 0123456789"
                      className="w-full bg-white border border-slate-300 rounded-xl p-2.5 font-mono font-bold text-slate-900 focus:border-blue-600 focus:outline-none tracking-wider"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-bold text-slate-700 block">Account Beneficiary Name</label>
                      <button
                        type="button"
                        onClick={() => {
                          if (gwAccountNumber.length === 10) {
                            if (!gwAccountName.trim()) {
                              setGwAccountName(user?.full_name?.toUpperCase() || 'VERIFIED MERCHANT');
                            }
                            addToast(`NUBAN ${gwAccountNumber} (${gwBankName}) verified via NIBSS API!`, 'success');
                          } else {
                            addToast('Enter a valid 10-digit NUBAN account number first.', 'info');
                          }
                        }}
                        className="text-[10px] text-blue-600 font-bold hover:underline"
                      >
                        Auto-Verify
                      </button>
                    </div>
                    <input
                      type="text"
                      value={gwAccountName}
                      onChange={(e) => setGwAccountName(e.target.value)}
                      placeholder="e.g. CYPRIAN MICHAEL OJOCHOGWU"
                      className="w-full bg-white border border-slate-300 rounded-xl p-2.5 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Paystack Subaccount & Flutterwave */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl border border-slate-200 bg-white space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-slate-900 text-xs">Paystack Split Subaccount</span>
                    <span className="text-[10px] text-blue-600 font-bold">Automatic Split</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={gwPaystackSubaccount}
                      onChange={(e) => setGwPaystackSubaccount(e.target.value)}
                      placeholder="ACCT_xxxxxxxxxxxxx or Subaccount ID"
                      className="flex-1 bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (!gwPaystackSubaccount.trim()) {
                          const sample = `ACCT_${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
                          setGwPaystackSubaccount(sample);
                          addToast(`Paystack Subaccount (${sample}) generated & auto-connected!`, 'success');
                        } else {
                          addToast(`Paystack Subaccount ${gwPaystackSubaccount} verified with Paystack API!`, 'success');
                        }
                      }}
                      className="px-3 py-2.5 bg-blue-50 text-blue-700 hover:bg-blue-100 font-bold rounded-xl border border-blue-200 text-xs shrink-0"
                    >
                      {gwPaystackSubaccount.trim() ? 'Verify API' : 'Auto-Connect'}
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    Allows customer payments via Paystack to split directly into your subaccount minus the ₦50 platform fee. Connect automatically or enter your existing Paystack subaccount.
                  </p>
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 bg-white space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-slate-900 text-xs">Flutterwave Subaccount ID</span>
                    <span className="text-[10px] text-amber-600 font-bold">Rave Merchant</span>
                  </div>
                  <input
                    type="text"
                    value={gwFlutterwaveId}
                    onChange={(e) => setGwFlutterwaveId(e.target.value)}
                    placeholder="RS_xxxxxxxxxxxxxxxx"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                  <p className="text-[10px] text-slate-400">
                    Connect Flutterwave for seamless card and USSD automated disbursements.
                  </p>
                </div>
              </div>

              {/* International & Crypto USDT TRC20 */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl border border-slate-200 bg-white space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-slate-900 text-xs">Stripe Connect Account (USD/EUR)</span>
                    <span className="text-[10px] text-indigo-600 font-bold">International</span>
                  </div>
                  <input
                    type="text"
                    value={gwStripeId}
                    onChange={(e) => setGwStripeId(e.target.value)}
                    placeholder="acct_1Oxxxxxxxxxxxxxx"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 bg-white space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-slate-900 text-xs">USDT Wallet Address (TRC20)</span>
                    <span className="text-[10px] text-emerald-600 font-bold">Crypto Payout</span>
                  </div>
                  <input
                    type="text"
                    value={gwCryptoAddress}
                    onChange={(e) => setGwCryptoAddress(e.target.value)}
                    placeholder="Txxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={gwSaving}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-black px-6 py-3.5 rounded-2xl text-xs sm:text-sm shadow-md active:scale-95 transition-all flex items-center space-x-2"
                >
                  <Check className="w-4 h-4" />
                  <span>{gwSaving ? 'Saving Routing...' : 'Save & Verify Gateway Connections'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TAB: INQUIRIES & JOB APPLICATIONS RECEIVED */}
      {activeTab === 'inquiries' && (
        <div className="space-y-6">
          {/* Service Bookings Received */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-black text-slate-900 text-base flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-blue-600" />
                  <span>Service Appointment Bookings Received ({serviceBookings.length})</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Customers who booked your service listings with date and location notes.
                </p>
              </div>
              <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full">
                Live Inquiries
              </span>
            </div>

            <div className="space-y-3">
              {serviceBookings.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  <p>No service booking appointments received yet.</p>
                </div>
              ) : (
                serviceBookings.map((sbk) => (
                  <div key={sbk.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-slate-900 text-sm">{sbk.service_title}</span>
                        <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
                          {sbk.status}
                        </span>
                      </div>
                      <p className="text-slate-600 font-medium">
                        Customer: <strong className="text-slate-900">{sbk.customer_name}</strong> • Phone: <strong className="text-blue-600">{sbk.customer_phone}</strong>
                      </p>
                      <p className="text-slate-500">
                        Date: <strong>{sbk.preferred_date}</strong> • Location: {sbk.service_address}
                      </p>
                      <p className="text-slate-500 italic">"{sbk.service_notes}"</p>
                    </div>

                    <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0">
                      <span className="font-black text-blue-600 text-sm">
                        {formatCurrency(sbk.estimated_fee, currency)}
                      </span>
                      <a
                        href={`https://wa.me/${sbk.customer_phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                          `Hello ${sbk.customer_name}, I received your booking for "${sbk.service_title}" on Mega Marketplace for ${sbk.preferred_date}. Let's finalize your appointment.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-green-600 hover:bg-green-700 text-white font-bold px-3 py-1.5 rounded-xl text-xs flex items-center space-x-1"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Reply on WhatsApp</span>
                      </a>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Job Applications Received */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-black text-slate-900 text-base flex items-center space-x-2">
                  <Briefcase className="w-4 h-4 text-purple-600" />
                  <span>Job Applications & Resume Submissions Received ({jobInquiries.length})</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Candidates who submitted applications for your job and sales agent postings.
                </p>
              </div>
              <span className="text-xs font-bold text-purple-600 bg-purple-50 px-2.5 py-1 rounded-full">
                Candidate Leads
              </span>
            </div>

            <div className="space-y-3">
              {jobInquiries.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  <p>No job applications received yet.</p>
                </div>
              ) : (
                jobInquiries.map((jinq) => (
                  <div key={jinq.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-slate-900 text-sm">{jinq.job_title}</span>
                        <span className="bg-purple-100 text-purple-800 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
                          {jinq.status}
                        </span>
                      </div>
                      <p className="text-slate-600 font-medium">
                        Applicant: <strong className="text-slate-900">{jinq.applicant_name}</strong> • Phone: <strong className="text-blue-600">{jinq.applicant_phone}</strong> • Email: {jinq.applicant_email}
                      </p>
                      <p className="text-slate-500">
                        Experience: "{jinq.resume_notes}"
                      </p>
                      {jinq.portfolio_url && (
                        <a
                          href={jinq.portfolio_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 font-bold hover:underline flex items-center space-x-1"
                        >
                          <span>View Portfolio / Resume Link</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>

                    <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0">
                      <a
                        href={`https://wa.me/${jinq.applicant_phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                          `Hello ${jinq.applicant_name}, I received your job application for "${jinq.job_title}" on Mega Marketplace. Let's schedule an interview.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-green-600 hover:bg-green-700 text-white font-bold px-3 py-1.5 rounded-xl text-xs flex items-center space-x-1"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Chat on WhatsApp</span>
                      </a>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MY ORDERS & DISPATCH TRACKING */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-5 sm:p-6 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-black text-slate-900 text-base">Your Orders & Escrow Shipments</h3>
                <p className="text-xs text-slate-500 mt-0.5">Click any order to view live logistics timeline and rider details.</p>
              </div>
              <span className="text-xs font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
                {orders.length} Total Orders
              </span>
            </div>

            <div className="divide-y divide-slate-100 text-xs">
              {orders.length === 0 ? (
                <div className="p-8 text-center text-slate-400">
                  <Package className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                  <p className="font-bold">No orders placed yet.</p>
                  <Link to="/explore" className="text-blue-600 font-bold hover:underline text-xs mt-1 block">
                    Start Shopping →
                  </Link>
                </div>
              ) : (
                orders.map((ord) => {
                  const addressStr = typeof ord.shipping_address === 'string'
                    ? ord.shipping_address
                    : `${ord.shipping_address.street}, ${ord.shipping_address.city}`;

                  return (
                    <div 
                      key={ord.id} 
                      onClick={() => setSelectedOrder(ord)}
                      className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 cursor-pointer transition-colors"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center space-x-2">
                          <span className="font-black text-slate-900 text-sm">{ord.order_number}</span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase ${
                            ord.status === 'delivered'
                              ? 'bg-green-100 text-green-800'
                              : ord.status === 'in_transit'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}>
                            {ord.status.replace('_', ' ')}
                          </span>
                        </div>
                        <p className="text-slate-600 font-medium flex items-center space-x-1.5">
                          <Truck className="w-3.5 h-3.5 text-blue-600" />
                          <span>Tracking: <strong className="font-mono text-blue-600">{ord.tracking_number || 'TRK-GEN-9823'}</strong></span>
                        </p>
                        <p className="text-[11px] text-slate-400">Destination: {addressStr}</p>
                      </div>

                      <div className="flex items-center sm:flex-col sm:items-end justify-between gap-2">
                        <div className="text-left sm:text-right">
                          <span className="font-black text-base text-slate-900 block">
                            {formatCurrency(ord.total_amount, currency)}
                          </span>
                          <span className="text-[11px] text-slate-400 block">{ord.items.length} items in package</span>
                        </div>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedOrder(ord);
                          }}
                          className="bg-slate-100 hover:bg-blue-600 hover:text-white text-slate-700 font-bold px-3 py-1.5 rounded-xl text-xs transition-colors flex items-center space-x-1"
                        >
                          <span>Track Dispatch</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SWITCH DEMO PROFILE PERSONA */}
      {activeTab === 'switch' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div>
            <h3 className="text-lg font-black text-slate-900 flex items-center space-x-2">
              <Users className="w-5 h-5 text-blue-600" />
              <span>Instant Account Switcher (Demo Personas)</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Switch seamlessly between super admin, merchant sellers, and buyers to test full functionality.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {registeredUsers.map((u) => (
              <div 
                key={u.id}
                onClick={() => switchUserAccount(u.id)}
                className={`p-5 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between ${
                  user.id === u.id
                    ? 'border-blue-600 bg-blue-50/50 shadow-sm'
                    : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center space-x-3.5">
                  <UserAvatar
                    src={u.avatar_url}
                    alt={u.full_name}
                    className="w-12 h-12 rounded-xl border border-slate-300"
                  />
                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="font-black text-slate-900 text-sm">{u.full_name}</h4>
                      <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase ${
                        u.role === 'admin' ? 'bg-slate-900 text-amber-400' : u.role === 'seller' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                      }`}>
                        {u.role}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">{u.email || u.phone}</p>
                    <p className="text-[11px] font-bold text-blue-600 mt-0.5">
                      Wallet: {formatCurrency(u.wallet_balance || 0, currency)}
                    </p>
                  </div>
                </div>

                <div className="shrink-0">
                  {user.id === u.id ? (
                    <span className="bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-lg">
                      Active
                    </span>
                  ) : (
                    <button className="text-xs font-bold text-slate-600 hover:text-blue-600">
                      Switch →
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* OFFICIAL SETTLEMENT MODAL */}
      {showTopUpModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black">
                  <Building className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-base text-slate-900">Official Store Settlement</h3>
                  <span className="text-[10px] text-emerald-600 font-bold">Direct Central Account</span>
                </div>
              </div>
              <button
                onClick={() => setShowTopUpModal(false)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-200 text-xs space-y-2">
              <span className="font-bold text-blue-900 block">Settlement Policy Notice:</span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                You do not need to fund a wallet! All product listing fees and platform settlements are made directly to the official account below. You get <strong>3 Times Free Trial</strong> listings!
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Bank Name:</span>
                <span className="font-bold text-slate-900">United Bank for Africa (UBA)</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Account Number:</span>
                <span className="font-mono font-black text-blue-600 text-sm">2311406173</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Account Name:</span>
                <span className="font-bold text-slate-900">CYPRIAN MICHAEL OJOCHOGWU</span>
              </div>
            </div>

            <div className="flex space-x-2 pt-2 text-xs">
              <button
                onClick={() => {
                  navigator.clipboard.writeText('2311406173');
                  addToast('Official settlement account copied!', 'success');
                }}
                className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 rounded-xl"
              >
                Copy Account
              </button>
              <button
                onClick={() => setShowTopUpModal(false)}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-md"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADMIN GATE PASSWORD MODAL */}
      {showAdminModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 text-center animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 text-amber-400 flex items-center justify-center mx-auto mb-3 shadow-md">
              <Lock className="w-6 h-6" />
            </div>
            <h3 className="font-black text-base text-slate-900 mb-1">Administrator Authorization</h3>
            <p className="text-xs text-slate-500 mb-4">Enter master password (Cyprian123) to access the control panel.</p>

            <form onSubmit={handleAdminLogin} className="space-y-3 text-xs text-left">
              <input
                type="password"
                required
                value={adminPasswordInput}
                onChange={(e) => {
                  setAdminPasswordInput(e.target.value);
                  setAdminError(false);
                }}
                placeholder="Enter password..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
              />

              {adminError && (
                <p className="text-rose-600 font-bold text-[11px]">Incorrect administrator password.</p>
              )}

              <div className="flex space-x-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAdminModal(false)}
                  className="flex-1 bg-slate-100 text-slate-700 font-bold py-2.5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-slate-900 text-amber-400 font-bold py-2.5 rounded-xl shadow-md"
                >
                  Enter Panel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* INTERACTIVE ORDER TRACKING & DISPATCH TIMELINE MODAL */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
              <div>
                <h3 className="font-black text-base text-slate-900">Order #{selectedOrder.order_number}</h3>
                <span className="text-[11px] text-blue-600 font-bold">Courier Tracking & Escrow Assurance</span>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            {/* Courier Info Card */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Truck className="w-4 h-4 text-blue-600" />
                  <span className="font-bold text-slate-900 text-xs">
                    {selectedOrder.courier_name || 'GIG Express Logistics Nigeria'}
                  </span>
                </div>
                <span className="font-mono text-xs font-bold text-blue-600">
                  {selectedOrder.tracking_number || 'TRK-982341-NG'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                Destination: {typeof selectedOrder.shipping_address === 'string' ? selectedOrder.shipping_address : `${selectedOrder.shipping_address.street}, ${selectedOrder.shipping_address.city}`}
              </p>
            </div>

            {/* Step-by-Step Timeline */}
            <div className="space-y-4 relative before:absolute before:left-3.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
              {selectedOrder.timeline.map((step, idx) => (
                <div key={idx} className="relative flex items-start space-x-3.5 pl-1">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 z-10 ${
                    step.completed
                      ? 'bg-blue-600 text-white'
                      : step.current
                      ? 'bg-amber-500 text-white ring-4 ring-amber-100 animate-pulse'
                      : 'bg-slate-200 text-slate-400'
                  }`}>
                    {step.completed ? <Check className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5" />}
                  </div>

                  <div className="space-y-0.5 text-xs">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-slate-900">{step.title}</span>
                      <span className="text-[10px] text-slate-400">{step.timestamp}</span>
                    </div>
                    <p className="text-slate-500 text-[11px]">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="font-black text-slate-900 text-sm">
                Total: {formatCurrency(selectedOrder.total_amount, currency)}
              </span>
              <button
                onClick={() => setSelectedOrder(null)}
                className="bg-slate-900 text-white font-bold px-4 py-2 rounded-xl text-xs"
              >
                Close Tracking
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
