import React, { useState } from 'react';
import { useStore } from '../store';
import { formatCurrency, calculatePlatformFee } from '../lib/utils';
import { Order } from '../types';
import { 
  ShieldCheck, 
  CreditCard, 
  Truck, 
  MapPin, 
  CheckCircle2, 
  ArrowRight, 
  Lock, 
  ArrowLeft,
  AlertTriangle,
  Building,
  Phone,
  MessageCircle,
  Copy,
  ExternalLink,
  Store,
  Clock,
  Sparkles
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { usePaystackPayment } from 'react-paystack';

export default function Checkout() {
  const navigate = useNavigate();
  const { 
    cart, 
    clearCart, 
    discountPercentage, 
    promoCode, 
    user, 
    createOrder, 
    currency,
    addToast,
    platformSettings,
    stores
  } = useStore();

  const [fullName, setFullName] = useState(user.full_name || 'Cyprian Nwosu');
  const [phone, setPhone] = useState(user.phone || '+234 812 345 6789');
  const [email, setEmail] = useState(user.email || 'cyprian@megamarket.ng');
  const [address, setAddress] = useState('14 Admiralty Way, Lekki Phase 1');
  const [landmark, setLandmark] = useState('Opposite Mega Plaza');
  const [cityState, setCityState] = useState('Lagos State');
  const [deliveryNotes, setDeliveryNotes] = useState('Please call 10 minutes before arrival at gate security.');
  const [shippingMethod, setShippingMethod] = useState<'standard' | 'express'>('standard');
  const [paymentMethod, setPaymentMethod] = useState<'seller_direct' | 'paystack'>('seller_direct');
  const [isProcessing, setIsProcessing] = useState(false);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  // Paystack Modal State
  const [showPaystackModal, setShowPaystackModal] = useState(false);
  const [cardNumber, setCardNumber] = useState('5399 4100 8821 9024');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvv, setCardCvv] = useState('781');
  const [cardPin, setCardPin] = useState('1234');
  const [paystackStep, setPaystackStep] = useState<'card' | 'otp' | 'verifying'>('card');
  const [otpCode, setOtpCode] = useState('');

  const subtotal = cart.reduce((acc, item) => {
    const price = item.product.discount_price || item.product.price;
    return acc + (price * item.quantity);
  }, 0);

  const discountAmount = discountPercentage > 0 ? (subtotal * discountPercentage) / 100 : 0;
  const shippingCost = shippingMethod === 'express' ? 6000 : (subtotal > 100000 ? 0 : 3000);
  const grandTotal = subtotal - discountAmount + shippingCost;
  const platformFee = calculatePlatformFee(subtotal);

  // Primary poster details from cart items
  const primaryItem = cart[0];
  const primaryProduct = primaryItem?.product;
  
  // Resolve poster account bank, number, name and contact WhatsApp
  const posterBank = primaryProduct?.poster_account_bank || primaryProduct?.store?.name || 'Guaranty Trust Bank (GTBank)';
  const posterAccountNumber = primaryProduct?.poster_account_number || '0123456789';
  const posterAccountName = primaryProduct?.poster_account_name || primaryProduct?.store?.name || 'Authorized Product Merchant';
  const posterWhatsApp = (primaryProduct?.contact_whatsapp || '234704409544').replace(/[^0-9]/g, '');

  // Paystack config
  const paystackKey = platformSettings.paystack_public_key || (import.meta as any).env.VITE_PAYSTACK_PUBLIC_KEY || '';
  
  const paystackConfig: any = {
    reference: `REF-${(new Date()).getTime()}`,
    email: email,
    amount: grandTotal * 100, // in kobo
    publicKey: paystackKey || 'pk_test_dummy',
    currency: 'NGN',
  };

  const initializePayment = usePaystackPayment(paystackConfig);

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (paymentMethod === 'seller_direct') {
      processOrderSuccess('seller_direct');
    } else {
      if (paystackKey) {
        initializePayment({
          onSuccess: (reference: any) => {
            addToast(`Payment successful! Ref: ${reference.reference}`, 'success');
            processOrderSuccess('paystack');
          },
          onClose: () => {
            addToast('Payment cancelled by user.', 'error');
          }
        });
      } else {
        setShowPaystackModal(true);
      }
    }
  };

  const processOrderSuccess = (method: 'seller_direct' | 'paystack') => {
    setIsProcessing(true);

    const newOrder = createOrder({
      customer_name: fullName,
      customer_email: email,
      customer_phone: phone,
      shipping_address: {
        street: `${address} (Landmark: ${landmark})`,
        city: cityState,
        state: 'Lagos',
        instructions: deliveryNotes
      },
      items: [...cart],
      subtotal,
      discount_amount: discountAmount,
      delivery_fee: shippingCost,
      total_amount: grandTotal,
      platform_fee: platformFee,
      seller_payout_amount: grandTotal - platformFee,
      status: method === 'seller_direct' ? 'pending_payment' : 'paid',
      payment_method: method,
      payment_status: method === 'seller_direct' ? 'pending' : 'paid',
      coupon_code: promoCode || undefined,
    });

    setIsProcessing(false);
    setShowPaystackModal(false);
    setCreatedOrder(newOrder);
  };

  const handlePaystackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (paystackStep === 'card') {
      setPaystackStep('otp');
    } else if (paystackStep === 'otp') {
      setPaystackStep('verifying');
      setTimeout(() => {
        processOrderSuccess('paystack');
      }, 1500);
    }
  };

  // Build WhatsApp message for product poster
  const getWhatsAppMessage = (order: Order) => {
    const itemsDescription = order.items.map((i, idx) => {
      const p = i.product;
      const desc = p.description ? p.description.slice(0, 80) + '...' : '';
      return `${idx + 1}. *${p.title}* (Qty: ${i.quantity}) - ₦${((p.discount_price || p.price) * i.quantity).toLocaleString()}\n   _Desc:_ ${desc}`;
    }).join('\n\n');

    const addressStr = typeof order.shipping_address === 'string'
      ? order.shipping_address
      : `${order.shipping_address.street}, ${order.shipping_address.city}, ${order.shipping_address.state}`;

    const text = `*HELLO, I HAVE MADE PAYMENT FOR YOUR PRODUCT!*\n\n` +
      `*Order Ref:* ${order.order_number}\n` +
      `*Buyer Name:* ${order.customer_name}\n` +
      `*Buyer Phone:* ${order.customer_phone}\n` +
      `*Total Amount Sent:* ₦${order.total_amount.toLocaleString()}\n\n` +
      `*PRODUCT(S) ORDERED & DESCRIPTIONS:*\n${itemsDescription}\n\n` +
      `*DELIVERY DESTINATION:*\n${addressStr}\n` +
      (deliveryNotes ? `*Special Notes:* ${deliveryNotes}\n` : '') +
      `\n*Please confirm receipt of money and dispatch my package.* Thank you!`;

    return encodeURIComponent(text);
  };

  if (createdOrder) {
    const addressStr = typeof createdOrder.shipping_address === 'string'
      ? createdOrder.shipping_address
      : `${createdOrder.shipping_address.street}, ${createdOrder.shipping_address.city}`;

    const waLink = `https://wa.me/${posterWhatsApp}?text=${getWhatsAppMessage(createdOrder)}`;

    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-8 max-w-2xl mx-auto">
        <div className="bg-white w-full rounded-3xl p-6 sm:p-8 border-2 border-blue-600 shadow-2xl text-center space-y-6 animate-in zoom-in-95">
          <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
            <CheckCircle2 className="w-9 h-9" />
          </div>

          <div>
            <div className="inline-flex items-center space-x-1.5 bg-emerald-100 text-emerald-800 text-[11px] font-black px-3 py-1 rounded-full uppercase tracking-wider mb-2">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Checkout Order Placed Successfully</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Transfer to Product Poster Account
            </h2>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
              Please transfer <strong className="text-slate-900 font-bold font-mono">{formatCurrency(createdOrder.total_amount, currency)}</strong> to the product poster account below, then tap the WhatsApp button to message them proof of payment with the product description!
            </p>
          </div>

          {/* PRODUCT POSTER RECEIVING ACCOUNT CARD */}
          <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 text-white rounded-3xl p-5 sm:p-6 text-left border-2 border-amber-400/50 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black text-xs">
                  <Building className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-white">Product Poster Settlement Account</h4>
                  <span className="text-[10px] text-amber-300 font-medium">Direct Seller Receiving Bank</span>
                </div>
              </div>
              <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full">
                Send Money Here
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-white/10 backdrop-blur-xs p-3.5 rounded-2xl border border-white/10">
                <span className="text-[10px] text-blue-200 uppercase font-bold block mb-1">Bank Name</span>
                <span className="text-sm font-black text-white block">{posterBank}</span>
              </div>

              <div className="bg-amber-500/10 backdrop-blur-xs p-3.5 rounded-2xl border border-amber-400/30 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-amber-200 uppercase font-bold block mb-1">Account Number</span>
                  <span className="text-xl font-mono font-black text-amber-400 block tracking-wider">
                    {posterAccountNumber}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(posterAccountNumber);
                    addToast(`Account Number (${posterAccountNumber}) copied to clipboard!`, 'success');
                  }}
                  className="p-2 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl transition-colors shrink-0"
                  title="Copy Account Number"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-white/10 backdrop-blur-xs p-3.5 rounded-2xl border border-white/10">
                <span className="text-[10px] text-blue-200 uppercase font-bold block mb-1">Account Name</span>
                <span className="text-xs font-black text-white block line-clamp-2">{posterAccountName}</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-white/10 text-xs">
              <span className="text-slate-300 text-[11px]">Total Payable to Poster:</span>
              <span className="text-xl font-black text-amber-400 font-mono">
                {formatCurrency(createdOrder.total_amount, currency)}
              </span>
            </div>
          </div>

          {/* PROMINENT DIRECT WHATSAPP PAYMENT MESSAGE BUTTON */}
          <div className="p-4 rounded-2xl bg-emerald-50 border-2 border-emerald-300 space-y-3">
            <div className="flex items-center space-x-2 text-emerald-950 font-bold text-xs text-left">
              <MessageCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Step 2: Notify the Product Poster on WhatsApp Immediately</span>
            </div>
            <p className="text-[11px] text-emerald-800 text-left leading-relaxed">
              After sending the money, tap the button below to send an automated payment proof message directly to the seller's WhatsApp number (+{posterWhatsApp}) with the complete product title, description, and your delivery address!
            </p>

            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black py-4 px-6 rounded-2xl shadow-lg shadow-emerald-600/25 active:scale-[0.98] transition-all flex items-center justify-center space-x-2 text-sm"
            >
              <MessageCircle className="w-5 h-5 fill-white" />
              <span>Send Payment Message & Product Details to WhatsApp Poster</span>
            </a>
          </div>

          {/* Order Reference Details */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-left text-xs space-y-2.5">
            <div className="flex justify-between">
              <span className="text-slate-500">Order Reference:</span>
              <span className="font-mono font-bold text-slate-900">{createdOrder.order_number}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Logistics Tracking Code:</span>
              <span className="font-mono font-bold text-blue-600">{createdOrder.tracking_number}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Courier Partner:</span>
              <span className="font-bold text-slate-900">{createdOrder.courier_name || 'GIG Express Logistics'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Delivery Specification:</span>
              <span className="font-medium text-slate-900 text-right line-clamp-2 max-w-[60%]">{addressStr}</span>
            </div>
          </div>

          <div className="flex space-x-3">
            <Link
              to="/account"
              className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-3.5 rounded-2xl text-xs transition-colors"
            >
              View Order in Account
            </Link>
            <Link
              to="/"
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-2xl text-xs shadow-md shadow-blue-600/20 transition-all"
            >
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center px-4 text-center space-y-4">
        <h2 className="text-xl font-bold text-slate-900">Your shopping cart is currently empty</h2>
        <Link to="/explore" className="bg-blue-600 text-white font-bold px-6 py-3 rounded-2xl text-xs shadow-md">
          Return to Marketplace
        </Link>
      </div>
    );
  }

  return (
    <div className="py-4 md:py-6 max-w-7xl mx-auto space-y-6">
      <div className="flex items-center space-x-3">
        <Link to="/cart" className="p-2.5 rounded-2xl bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 shadow-xs">
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">Direct Seller Checkout</h1>
          <p className="text-xs text-slate-500">Pay directly to the product poster's bank account with 100% WhatsApp notification</p>
        </div>
      </div>

      <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Delivery Details & Payment */}
        <div className="lg:col-span-8 space-y-6">
          {/* Section 1: Customer Delivery Specifications */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center space-x-2 font-bold text-base text-slate-900 pb-2 border-b border-slate-100">
              <MapPin className="w-5 h-5 text-blue-600" />
              <span>1. Customer Delivery & Dispatch Specification</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-semibold focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Phone Number (For Courier Call) *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-semibold focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Email Address (For Invoices) *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-semibold focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">City / State *</label>
                <input
                  type="text"
                  required
                  value={cityState}
                  onChange={(e) => setCityState(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-semibold focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="font-bold text-slate-700 block mb-1">Doorstep Street Address *</label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="e.g. 14 Admiralty Way, Lekki Phase 1"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-semibold focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Closest Landmark / Bus Stop</label>
                <input
                  type="text"
                  value={landmark}
                  onChange={(e) => setLandmark(e.target.value)}
                  placeholder="e.g. Opposite Mega Plaza"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-semibold focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Special Rider Delivery Instructions</label>
                <input
                  type="text"
                  value={deliveryNotes}
                  onChange={(e) => setDeliveryNotes(e.target.value)}
                  placeholder="e.g. Leave with gate security / Call upon arrival"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-semibold focus:border-blue-600 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Delivery Speed */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center space-x-2 font-bold text-base text-slate-900 pb-2 border-b border-slate-100">
              <Truck className="w-5 h-5 text-blue-600" />
              <span>2. Delivery Courier Speed</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <label
                onClick={() => setShippingMethod('standard')}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  shippingMethod === 'standard'
                    ? 'border-blue-600 bg-blue-50/50'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-900">Standard Delivery</span>
                  <span className="font-extrabold text-blue-600">
                    {subtotal > 100000 ? 'FREE' : formatCurrency(3000, currency)}
                  </span>
                </div>
                <p className="text-slate-500 text-[11px]">24 to 48 Hours with live SMS courier tracking</p>
              </label>

              <label
                onClick={() => setShippingMethod('express')}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  shippingMethod === 'express'
                    ? 'border-blue-600 bg-blue-50/50'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-900">Same-Day Priority Express</span>
                  <span className="font-extrabold text-blue-600">{formatCurrency(6000, currency)}</span>
                </div>
                <p className="text-slate-500 text-[11px]">Same-Day dispatch with direct VIP courier handover</p>
              </label>
            </div>
          </div>

          {/* Section 3: Payment Method Selection */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center space-x-2 font-bold text-base text-slate-900 pb-2 border-b border-slate-100">
              <CreditCard className="w-5 h-5 text-blue-600" />
              <span>3. Customized Checkout Method</span>
            </div>

            <div className="space-y-4 text-xs">
              {/* PRIMARY METHOD: DIRECT SELLER ACCOUNT & WHATSAPP PROOF */}
              <div
                onClick={() => setPaymentMethod('seller_direct')}
                className={`p-5 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'seller_direct'
                    ? 'border-blue-600 bg-blue-50/40 shadow-xs'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-black text-slate-900 text-sm">
                      Direct Poster Bank Transfer + WhatsApp Confirmation
                    </span>
                    <span className="text-[10px] font-black px-2 py-0.5 bg-blue-600 text-white rounded-full">
                      Standard Checkout
                    </span>
                  </div>
                  <Building className="w-4 h-4 text-blue-600" />
                </div>

                <p className="text-slate-600 text-[11px] leading-relaxed mb-3">
                  The verified bank account of the person who posted this product is displayed right here. After transferring the money, click the WhatsApp button to send your payment proof message with full product descriptions directly to the seller.
                </p>

                {/* Display Product Poster's Account Details */}
                <div className="p-4 rounded-xl bg-white border border-blue-200 space-y-2">
                  <div className="flex items-center justify-between text-[11px] pb-1 border-b border-slate-100">
                    <span className="text-slate-500 font-bold uppercase tracking-wider">Poster Receiving Bank:</span>
                    <span className="font-black text-slate-900">{posterBank}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] pb-1 border-b border-slate-100">
                    <span className="text-slate-500 font-bold uppercase tracking-wider">Account Number:</span>
                    <span className="font-mono font-black text-blue-600 text-sm">{posterAccountNumber}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] pb-1 border-b border-slate-100">
                    <span className="text-slate-500 font-bold uppercase tracking-wider">Beneficiary Name:</span>
                    <span className="font-bold text-slate-900">{posterAccountName}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-500 font-bold uppercase tracking-wider">Seller WhatsApp Contact:</span>
                    <span className="font-bold text-emerald-700 flex items-center space-x-1">
                      <MessageCircle className="w-3 h-3 text-emerald-600" />
                      <span>+{posterWhatsApp}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* SECONDARY METHOD: ONLINE CARD GATEWAY */}
              <div
                onClick={() => setPaymentMethod('paystack')}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'paystack'
                    ? 'border-blue-600 bg-blue-50/40 shadow-xs'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-900 text-xs">Paystack Online Card Gateway</span>
                  <span className="text-[10px] text-slate-400 font-semibold">Debit Cards & USSD</span>
                </div>
                <p className="text-slate-500 text-[11px]">
                  Alternative option to pay using Mastercard, Visa, or Verve card.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Checkout Breakdown */}
        <div className="lg:col-span-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm sticky top-24 space-y-4">
            <h3 className="font-black text-base text-slate-900">Order Summary</h3>

            <div className="space-y-2.5 text-xs py-2 border-b border-slate-100 max-h-48 overflow-y-auto">
              {cart.map((i) => (
                <div key={i.product.id} className="flex justify-between text-slate-600">
                  <span className="line-clamp-1 pr-2">{i.quantity}x {i.product.title}</span>
                  <span className="font-bold text-slate-900 shrink-0">
                    {formatCurrency((i.product.discount_price || i.product.price) * i.quantity, currency)}
                  </span>
                </div>
              ))}
            </div>

            <div className="space-y-2 text-xs pt-1">
              <div className="flex justify-between text-slate-600">
                <span>Items Subtotal</span>
                <span className="font-bold text-slate-900">{formatCurrency(subtotal, currency)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-green-600 font-bold">
                  <span>Promo Discount</span>
                  <span>-{formatCurrency(discountAmount, currency)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>Courier Delivery</span>
                <span className="font-bold text-slate-900">
                  {shippingCost === 0 ? 'FREE' : formatCurrency(shippingCost, currency)}
                </span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-between items-end">
              <div>
                <span className="text-[10px] text-slate-400 block font-bold uppercase">Total Payable</span>
                <span className="text-2xl font-black text-slate-900">{formatCurrency(grandTotal, currency)}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isProcessing}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-600/20 active:scale-95 transition-all flex items-center justify-center space-x-2 text-sm disabled:opacity-50"
            >
              <Lock className="w-4 h-4" />
              <span>{isProcessing ? 'Processing Order...' : `Complete Order & Get Poster Account`}</span>
            </button>

            <div className="p-3 bg-slate-50 rounded-xl text-[10px] text-slate-500 font-medium text-center space-y-1">
              <div className="flex items-center justify-center space-x-1 text-emerald-600 font-bold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Zero Wallet Funding Needed</span>
              </div>
              <p>Direct bank transfer to product poster + instant WhatsApp notification with product description.</p>
            </div>
          </div>
        </div>
      </form>

      {/* PAYSTACK OFFICIAL PAYMENT MODAL OVERLAY */}
      {showPaystackModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-slate-200 animate-in zoom-in-95">
            <div className="bg-slate-950 text-white p-5 flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center font-black text-white text-xs">
                  P
                </div>
                <div>
                  <h4 className="font-bold text-sm">Paystack Gateway</h4>
                  <span className="text-[10px] text-slate-400">Direct Gateway Checkout</span>
                </div>
              </div>
              <button
                onClick={() => setShowPaystackModal(false)}
                className="w-7 h-7 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center text-xs"
              >
                ✕
              </button>
            </div>

            <div className="bg-blue-50/70 p-4 text-center border-b border-blue-100">
              <span className="text-[11px] text-blue-900 font-bold block uppercase">Amount Due</span>
              <span className="text-2xl font-black text-blue-950">{formatCurrency(grandTotal, currency)}</span>
              <span className="text-[10px] text-slate-500 block mt-0.5">{email}</span>
            </div>

            <form onSubmit={handlePaystackSubmit} className="p-6 space-y-4 text-xs">
              {paystackStep === 'card' && (
                <>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Card Number</label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      placeholder="5399 4100 8821 9024"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-mono font-bold text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">Expiry Date</label>
                      <input
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="MM/YY"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-mono font-bold text-slate-900 focus:border-blue-600 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">CVV Code</label>
                      <input
                        type="password"
                        maxLength={3}
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        placeholder="123"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-mono font-bold text-slate-900 focus:border-blue-600 focus:outline-none"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">4-Digit Card PIN</label>
                    <input
                      type="password"
                      maxLength={4}
                      value={cardPin}
                      onChange={(e) => setCardPin(e.target.value)}
                      placeholder="••••"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-mono font-bold text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3.5 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center space-x-2 text-xs"
                  >
                    <Lock className="w-4 h-4" />
                    <span>Proceed to 2FA Authentication</span>
                  </button>
                </>
              )}
              {paystackStep === 'otp' && (
                <div className="space-y-4 text-center py-2">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">Enter Bank One-Time Password</h4>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      A 6-digit OTP has been dispatched to your bank registered mobile device.
                    </p>
                  </div>
                  <input
                    type="text"
                    maxLength={6}
                    required
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    placeholder="1 2 3 4 5 6"
                    className="w-full text-center tracking-widest text-lg font-mono font-black bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl shadow-md transition-all active:scale-95"
                  >
                    Confirm & Complete Payment
                  </button>
                </div>
              )}
              {paystackStep === 'verifying' && (
                <div className="py-8 text-center space-y-3">
                  <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="font-bold text-slate-900">Verifying Transaction...</p>
                  <p className="text-[11px] text-slate-400">Please do not refresh this window</p>
                </div>
              )}
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
