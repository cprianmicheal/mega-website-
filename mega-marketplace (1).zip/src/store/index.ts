import { supabase } from '../lib/supabase';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  CartItem, 
  Product, 
  Profile, 
  Store, 
  ServiceItem, 
  Order, 
  WalletTransaction, 
  CurrencyCode, 
  ToastItem, 
  ToastType, 
  PlatformSettings, 
  AIWhatsappAlert,
  RewardActivity,
  PhoneDropAlert,
  TeamMemberAccount,
  TeamJobApplication,
  VideoAdvertisement,
  TickerNewsItem,
  AdminRevenueBankAccount,
  ConnectedPaymentGateways,
  ServiceBookingMessage,
  JobInquiryMessage
} from '../types';
import { 
  MOCK_PRODUCTS, 
  MOCK_STORES, 
  MOCK_SERVICES, 
  MOCK_ORDERS, 
  MOCK_WALLET_TRANSACTIONS, 
  MOCK_USERS_LIST, 
  MOCK_PLATFORM_SETTINGS, 
  MOCK_AI_ALERTS,
  MOCK_REWARD_ACTIVITIES,
  MOCK_PHONE_DROP_ALERTS,
  DEFAULT_TEAM_MEMBERS,
  DEFAULT_ADMIN_BANK_ACCOUNTS,
  MOCK_VIDEO_ADS,
  MOCK_TICKER_NEWS,
  MOCK_TEAM_APPLICATIONS
} from '../services/mockData';
import { calculatePlatformFee } from '../lib/utils';

interface AppState {
  // Global Currency
  currency: CurrencyCode;
  setCurrency: (currency: CurrencyCode) => void;

  // Toast Notifications
  toasts: ToastItem[];
  addToast: (message: string, type?: ToastType, title?: string, duration?: number) => void;
  removeToast: (id: string) => void;

  // User Profile & Authentication
  user: Profile;
  registeredUsers: Profile[];
  isAuthenticated: boolean;
  setUser: (user: Profile) => void;
  updateUserProfile: (updates: Partial<Profile>) => void;
  loginUser: (identifier: string, rolePreference?: 'customer' | 'seller') => { success: boolean; message: string; user?: Profile };
  signupUser: (data: { full_name: string; email: string; phone: string; role: Profile['role']; business_name?: string; avatar_url?: string }) => { success: boolean; message: string; user?: Profile };
  logoutUser: () => void;
  switchUserAccount: (userId: string) => void;
  sendOtpCode: (target: string) => { success: boolean; code: string; message: string };
  verifyOtpAndReset: (target: string, code: string) => { success: boolean; message: string };

  // Rewards & Affiliate Engine
  rewardActivities: RewardActivity[];
  claimReward: (rewardId: string) => { success: boolean; amount: number; message: string };
  claimAllRewards: () => { success: boolean; totalClaimed: number; count: number };
  claimDailyStreakReward: () => { success: boolean; amount: number; message: string; streak: number };
  requestDirectBankCashout: (amount: number, bankDetails: { bank_name: string; account_number: string; account_name: string }) => { success: boolean; reference: string; message: string };

  // Products & Marketplace
  products: Product[];
  deletedProductIds: string[];
  stores: Store[];
  services: ServiceItem[];
  fetchGlobalSupabaseProducts: () => Promise<void>;
  addProduct: (product: Product) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addStore: (store: Store) => void;
  updateStore: (id: string, updates: Partial<Store>) => void;
  addService: (service: ServiceItem) => void;
  updateService: (id: string, updates: Partial<ServiceItem>) => void;
  deleteService: (id: string) => void;

  // Wishlist
  wishlist: Product[];
  toggleWishlist: (product: Product) => void;
  isWishlisted: (productId: string) => boolean;
  clearWishlist: () => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, selectedVariant?: string, buyerInstructions?: string) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;

  // Coupon / Promo
  promoCode: string | null;
  discountPercentage: number;
  applyPromoCode: (code: string) => { success: boolean; message: string; discountPercent: number };
  removePromoCode: () => void;

  // Orders & Sales Records
  orders: Order[];
  createOrder: (orderData: Omit<Order, 'id' | 'order_number' | 'timeline' | 'created_at'>) => Order;
  updateOrderStatus: (orderId: string, status: Order['status'], note?: string) => void;
  updateOrderRecord: (orderId: string, updates: Partial<Order>) => void;
  approveSellerPayout: (orderId: string) => void;

  // Wallet
  walletBalance: number;
  walletTransactions: WalletTransaction[];
  topUpWallet: (amount: number, ref?: string) => void;
  payWithWallet: (amount: number, title: string) => boolean;

  // Admin Security & Management
  isAdminAuthenticated: boolean;
  verifyAdminPassword: (password: string) => boolean;
  logoutAdmin: () => void;
  deleteRegisteredUser: (userId: string) => void;
  platformSettings: PlatformSettings;
  updatePlatformSettings: (updates: Partial<PlatformSettings>) => void;
  updateUserRoleAndBalance: (userId: string, role: Profile['role'], walletBalance?: number) => void;

  // Platform Admin Revenue (₦50 charges on listings and payouts)
  adminRevenueNgn: number;
  recordAdminFee: (amount: number, reason: string) => void;

  // Team Member Accounts & PIN Access
  teamMembers: TeamMemberAccount[];
  updateTeamMemberPin: (memberId: string, newPin: string) => void;
  updateAllTeamPins: (newPin: string) => void; // Change PIN code for everyone
  activeStaffRole: 'super_admin' | 'bookkeeper' | 'money_checker' | 'ad_manager' | null;
  loginStaffWithPin: (roleOrRoute: string, pin: string) => { success: boolean; message: string; member?: TeamMemberAccount };
  logoutStaff: () => void;

  // Product Boosts & Upper Display
  updateProductBoost: (productId: string, isBoosted: boolean) => void;

  // Customer / Seller Payment Gateway Connections
  updateConnectedPaymentGateways: (gateways: Partial<ConnectedPaymentGateways>) => void;

  // Direct Inquiries & Bookings to Job/Service Posters
  serviceBookings: ServiceBookingMessage[];
  addServiceBooking: (booking: Omit<ServiceBookingMessage, 'id' | 'created_at'>) => void;
  jobInquiries: JobInquiryMessage[];
  addJobInquiry: (inquiry: Omit<JobInquiryMessage, 'id' | 'created_at'>) => void;

  // Video Advertisements & Auto-Scheduler
  videoAds: VideoAdvertisement[];
  addVideoAd: (ad: Omit<VideoAdvertisement, 'id' | 'created_at' | 'views_count' | 'clicks_count'>) => void;
  updateVideoAd: (id: string, updates: Partial<VideoAdvertisement>) => void;
  deleteVideoAd: (id: string) => void;

  // Flowing Ticker News
  tickerNews: TickerNewsItem[];
  addTickerNews: (item: Omit<TickerNewsItem, 'id' | 'created_at'>) => void;
  removeTickerNews: (id: string) => void;

  // Remote Community Team Applications (Max 7 accepted)
  teamApplications: TeamJobApplication[];
  submitTeamApplication: (app: Omit<TeamJobApplication, 'id' | 'submitted_at' | 'status'>) => { success: boolean; message: string; remainingSlots: number };
  reviewTeamApplication: (id: string, decision: 'accepted' | 'rejected', customPin?: string) => { success: boolean; message: string; assignedPin?: string };

  // Admin Revenue Bank Accounts (UBA 2311406173, etc.)
  adminBankAccounts: AdminRevenueBankAccount[];
  addAdminBankAccount: (account: Omit<AdminRevenueBankAccount, 'id' | 'added_at'>) => void;
  deleteAdminBankAccount: (id: string) => void;
  setPrimaryAdminBankAccount: (id: string) => void;

  // AI WhatsApp Guardian
  aiAlerts: AIWhatsappAlert[];
  sendWhatsappAlert: (message: string, category?: AIWhatsappAlert['category'], severity?: AIWhatsappAlert['severity'], referenceId?: string) => void;

  // Phone SMS & Push Drop Alert Notification System
  phoneNotificationPermission: 'prompt' | 'granted' | 'denied';
  phoneDropAlerts: PhoneDropAlert[];
  setPhoneNotificationPermission: (status: 'granted' | 'denied') => void;
  broadcastPhoneDropAlert: (alert: Omit<PhoneDropAlert, 'id' | 'timestamp' | 'delivered'>) => void;
  clearPhoneDropAlerts: () => void;
  deletePhoneDropAlert: (id: string) => void;
  approveProductListing: (productId: string, isApproved: boolean) => void;
  approveSellerAccount: (userId: string, isApproved: boolean) => void;

  // Master Factory Reset
  factoryResetApp: () => void;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Global Currency
      currency: 'NGN',
      setCurrency: (currency) => {
        set({ currency });
        get().addToast(`Currency switched to ${currency}`, 'info');
      },

      // Toasts
      toasts: [],
      addToast: (message, type = 'info', title, duration = 3500) => {
        const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        const newToast: ToastItem = { id, message, type, title, duration };
        set((state) => ({
          toasts: [newToast, ...state.toasts].slice(0, 5) // max 5 visible toasts
        }));

        if (duration > 0) {
          setTimeout(() => {
            get().removeToast(id);
          }, duration);
        }
      },
      removeToast: (id) => set((state) => ({
        toasts: state.toasts.filter((t) => t.id !== id)
      })),

      // User Profiles & Auth
      user: MOCK_USERS_LIST[0],
      registeredUsers: MOCK_USERS_LIST,
      isAuthenticated: false, // Default client account is empty / not logged in yet as requested
      
      setUser: (user) => set({ user }),

      updateUserProfile: (updates) => set((state) => {
        const updatedUser = { ...state.user, ...updates };
        const updatedList = state.registeredUsers.map(u => u.id === state.user.id ? updatedUser : u);
        return {
          user: updatedUser,
          registeredUsers: updatedList
        };
      }),

      loginUser: (identifier, rolePreference) => {
        const clean = identifier.trim().toLowerCase();
        const users = get().registeredUsers;
        const matched = users.find(u => 
          u.email?.toLowerCase() === clean || 
          u.phone?.replace(/[\s+-]/g, '') === clean.replace(/[\s+-]/g, '') ||
          u.full_name.toLowerCase().includes(clean)
        );

        if (matched) {
          set({ user: matched, isAuthenticated: true });
          get().addToast(`Welcome back, ${matched.full_name}!`, 'success', 'Signed In');
          return { success: true, message: `Welcome back, ${matched.full_name}`, user: matched };
        }

        // Demo dynamic login for any valid email/phone
        const newUser: Profile = {
          id: `usr-${Date.now()}`,
          full_name: identifier.includes('@') ? identifier.split('@')[0].replace('.', ' ') : 'Mega User',
          email: identifier.includes('@') ? identifier : undefined,
          phone: !identifier.includes('@') ? identifier : '+234 812 000 1122',
          role: rolePreference || 'customer',
          wallet_balance: 25000,
          referral_code: `MEGA${Math.floor(1000 + Math.random() * 9000)}`,
          referral_count: 0,
          referral_earnings: 0,
          avatar_url: '',
          created_at: new Date().toISOString(),
        };

        set((state) => ({
          user: newUser,
          registeredUsers: [newUser, ...state.registeredUsers],
          isAuthenticated: true
        }));

        get().addToast(`Account created and signed in as ${newUser.full_name}`, 'success', 'Welcome!');
        return { success: true, message: 'Account signed in successfully.', user: newUser };
      },

      signupUser: (data) => {
        const newUser: Profile = {
          id: `usr-${Date.now()}`,
          full_name: data.full_name,
          email: data.email,
          phone: data.phone,
          role: data.role,
          business_name: data.business_name,
          wallet_balance: 50000, // Sign up starter bonus
          referral_code: `MEGA${Math.floor(1000 + Math.random() * 9000)}`,
          referral_count: 0,
          referral_earnings: 0,
          avatar_url: data.avatar_url || '',
          created_at: new Date().toISOString(),
        };

        set((state) => ({
          user: newUser,
          registeredUsers: [newUser, ...state.registeredUsers],
          isAuthenticated: true
        }));

        get().addToast(`Account successfully registered for ${data.full_name}! ₦50,000 demo wallet balance added.`, 'success', 'Registration Complete');
        
        // Notify AI Overseer about new seller
        if (data.role === 'seller') {
          get().sendWhatsappAlert(
            `New Merchant Registered: "${data.business_name || data.full_name}" (Phone: ${data.phone}).`,
            'NEW_SELLER_APPLICATION',
            'medium',
            newUser.id
          );
        }

        return { success: true, message: 'Registration complete', user: newUser };
      },

      logoutUser: () => {
        set({ isAuthenticated: false });
        get().addToast('You have been safely signed out.', 'info');
      },

      switchUserAccount: (userId) => {
        const found = get().registeredUsers.find(u => u.id === userId);
        if (found) {
          set({
            user: found,
            isAuthenticated: true,
            walletBalance: found.wallet_balance || 0
          });
          get().addToast(`Switched account to ${found.full_name} (${found.role.toUpperCase()})`, 'info', 'Account Switched');
        }
      },

      sendOtpCode: (target) => {
        const code = Math.floor(100000 + Math.random() * 900000).toString();
        get().addToast(`Security OTP sent to ${target}: ${code}`, 'success', 'OTP Code Sent (Demo: ' + code + ')', 8000);
        return { success: true, code, message: `OTP code dispatched to ${target}` };
      },

      verifyOtpAndReset: (target, code) => {
        if (code.length >= 4) {
          get().addToast(`Identity verified for ${target}. Password reset successfully!`, 'success', 'Verified');
          return { success: true, message: 'Identity verified successfully.' };
        }
        return { success: false, message: 'Invalid OTP code. Please enter the 6 digits.' };
      },

      // Rewards & Affiliate Engine
      rewardActivities: MOCK_REWARD_ACTIVITIES,

      claimReward: (rewardId) => {
        const activity = get().rewardActivities.find(r => r.id === rewardId);
        if (!activity || activity.status !== 'available') {
          return { success: false, amount: 0, message: 'Reward is not available to claim.' };
        }

        const amount = activity.amount;
        const newBalance = get().walletBalance + amount;
        const newTx: WalletTransaction = {
          id: `tx-rew-${Date.now()}`,
          type: 'credit',
          amount,
          title: `Reward Payout: ${activity.title}`,
          reference: activity.reference || `REF-REW-${Date.now()}`,
          date: 'Just now',
          status: 'completed'
        };

        set((state) => ({
          walletBalance: newBalance,
          walletTransactions: [newTx, ...state.walletTransactions],
          rewardActivities: state.rewardActivities.map(r => r.id === rewardId ? { ...r, status: 'claimed' as const } : r),
          user: {
            ...state.user,
            wallet_balance: newBalance,
            claimed_rewards: (state.user.claimed_rewards || 0) + amount
          }
        }));

        get().addToast(`₦${amount.toLocaleString()} reward credited directly to your Mega Wallet!`, 'success', 'Reward Claimed! 💰');
        return { success: true, amount, message: 'Reward successfully claimed into wallet.' };
      },

      claimAllRewards: () => {
        const available = get().rewardActivities.filter(r => r.status === 'available');
        if (available.length === 0) {
          get().addToast('No unclaimed reward bonuses at this moment.', 'info');
          return { success: false, totalClaimed: 0, count: 0 };
        }

        const totalClaimed = available.reduce((acc, curr) => acc + curr.amount, 0);
        const newBalance = get().walletBalance + totalClaimed;
        const newTx: WalletTransaction = {
          id: `tx-all-rew-${Date.now()}`,
          type: 'credit',
          amount: totalClaimed,
          title: `Bulk Rewards Payout (${available.length} Bonuses Claimed)`,
          reference: `REF-BULK-REW-${Date.now()}`,
          date: 'Just now',
          status: 'completed'
        };

        set((state) => ({
          walletBalance: newBalance,
          walletTransactions: [newTx, ...state.walletTransactions],
          rewardActivities: state.rewardActivities.map(r => ({ ...r, status: 'claimed' as const })),
          user: {
            ...state.user,
            wallet_balance: newBalance,
            claimed_rewards: (state.user.claimed_rewards || 0) + totalClaimed
          }
        }));

        get().addToast(`Transferred ₦${totalClaimed.toLocaleString()} (${available.length} bonuses) to your Mega Wallet!`, 'success', 'All Rewards Claimed! 🎉');
        return { success: true, totalClaimed, count: available.length };
      },

      claimDailyStreakReward: () => {
        const currentUser = get().user;
        const currentStreak = (currentUser.daily_streak || 0) + 1;
        const rewardAmount = Math.min(1000 + (currentStreak * 250), 5000); // ₦1,250 to ₦5,000 streak bonus

        const newReward: RewardActivity = {
          id: `rew-daily-${Date.now()}`,
          user_id: currentUser.id,
          type: 'daily_streak',
          title: `Day ${currentStreak} Daily Login Streak Bonus`,
          description: `Consecutive active day reward bonus credited.`,
          amount: rewardAmount,
          status: 'claimed',
          date: 'Just now',
          reference: `STRK-${Date.now()}`
        };

        const newBalance = get().walletBalance + rewardAmount;
        const newTx: WalletTransaction = {
          id: `tx-streak-${Date.now()}`,
          type: 'credit',
          amount: rewardAmount,
          title: `Daily Check-in Reward (Day ${currentStreak})`,
          reference: `REF-STRK-${Date.now()}`,
          date: 'Just now',
          status: 'completed'
        };

        set((state) => ({
          walletBalance: newBalance,
          walletTransactions: [newTx, ...state.walletTransactions],
          rewardActivities: [newReward, ...state.rewardActivities],
          user: {
            ...state.user,
            wallet_balance: newBalance,
            daily_streak: currentStreak,
            last_daily_claim: new Date().toISOString(),
            claimed_rewards: (state.user.claimed_rewards || 0) + rewardAmount
          }
        }));

        get().addToast(`Day ${currentStreak} Streak Bonus Claimed! +₦${rewardAmount.toLocaleString()} in your wallet.`, 'success', 'Daily Reward Claimed ⚡');
        return { success: true, amount: rewardAmount, streak: currentStreak, message: `Day ${currentStreak} reward claimed.` };
      },

      requestDirectBankCashout: (amount, bankDetails) => {
        if (amount <= 0 || amount > get().walletBalance) {
          get().addToast('Insufficient wallet balance for this cashout amount.', 'error', 'Cashout Failed');
          return { success: false, reference: '', message: 'Insufficient balance' };
        }

        const ref = `NUBAN-PAY-${Math.floor(1000000 + Math.random() * 9000000)}`;
        const newBalance = get().walletBalance - amount;
        const newTx: WalletTransaction = {
          id: `tx-out-${Date.now()}`,
          type: 'debit',
          amount,
          title: `Bank Settlement Payout (${bankDetails.bank_name})`,
          reference: ref,
          date: 'Just now',
          status: 'completed'
        };

        set((state) => ({
          walletBalance: newBalance,
          walletTransactions: [newTx, ...state.walletTransactions],
          user: {
            ...state.user,
            wallet_balance: newBalance,
            bank_details: {
              ...bankDetails,
              is_verified: true
            }
          }
        }));

        get().addToast(`₦${amount.toLocaleString()} dispatched to ${bankDetails.bank_name} (${bankDetails.account_number})! Expected in 2-5 minutes.`, 'success', 'Bank Transfer Initiated');
        
        get().sendWhatsappAlert(
          `Direct Bank Cashout: ₦${amount.toLocaleString()} sent to ${bankDetails.bank_name} - ${bankDetails.account_number} (${bankDetails.account_name}). Ref: ${ref}`,
          'SETTLEMENT_REQUEST',
          'medium',
          ref
        );

        return { success: true, reference: ref, message: 'Bank settlement dispatched successfully.' };
      },

      // Products & Stores
      products: MOCK_PRODUCTS,
      deletedProductIds: [],
      stores: MOCK_STORES,
      services: MOCK_SERVICES,
      fetchGlobalSupabaseProducts: async () => {},

      addProduct: (product) => {
        // Strict approval requirement:
        // Always requires payment confirmation from Money Checker / Admin before publishing live
        const finalProduct: Product = {
          ...product,
          is_approved: false,
          is_published: false
        };
        set((state) => ({
          products: [finalProduct, ...state.products.filter(p => p.id !== finalProduct.id)]
        }));

        get().addToast('Waiting for admin approval because payment hasn’t been made or approved yet.', 'warning', 'Awaiting Approval');
      },

      approveProductListing: (productId, isApproved = true) => set((state) => {
        const updated = state.products.map(p => p.id === productId ? { ...p, is_approved: isApproved, is_published: isApproved } : p);
        const prod = state.products.find(p => p.id === productId);
        get().addToast(isApproved ? `Product "${prod?.title || 'Listing'}" approved & published live!` : 'Product listing approval revoked.', isApproved ? 'success' : 'info', 'Listing Status');
        if (isApproved && prod) {
          get().broadcastPhoneDropAlert({
            title: `⚡ NEW DROP: ${prod.title}`,
            message: `New item posted in marketplace inventory for ₦${prod.price.toLocaleString()}. Immediate dispatch available.`,
            recipientPhone: get().platformSettings.official_drop_phone || get().platformSettings.admin_whatsapp_number || get().user.phone || '0704409544',
            channel: 'WHATSAPP',
            productTitle: prod.title,
            productPrice: prod.price,
            productSlug: prod.slug,
            productImage: prod.images[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=300',
            locationTag: 'Ankpa, Kogi State, Nigeria'
          });
        }
        return { products: updated };
      }),

      approveSellerAccount: (userId, isApproved) => set((state) => {
        const updatedUsers = state.registeredUsers.map(u => u.id === userId ? { ...u, is_seller_approved: isApproved } : u);
        const updatedUser = state.user.id === userId ? { ...state.user, is_seller_approved: isApproved } : state.user;
        get().addToast(isApproved ? 'Seller account approved! Listings can now go live.' : 'Seller account approval pending.', 'info');
        return { registeredUsers: updatedUsers, user: updatedUser };
      }),

      updateProduct: (id, updates) => set((state) => {
        get().addToast(`Listing updated successfully.`, 'info');
        return {
          products: state.products.map(p => p.id === id ? { ...p, ...updates } : p)
        };
      }),

      deleteProduct: (id) => set((state) => {
        get().addToast(`Product permanently deleted from marketplace.`, 'info', 'Product Removed');
        return {
          deletedProductIds: [...new Set([...(state.deletedProductIds || []), id])],
          products: state.products.filter(p => p.id !== id),
          wishlist: state.wishlist.filter(p => p.id !== id),
          cart: state.cart.filter(item => item.product.id !== id)
        };
      }),

      addStore: (store) => set((state) => {
        get().addToast(`Store "${store.name}" registered successfully!`, 'success', 'Store Created');
        return {
          stores: [store, ...state.stores]
        };
      }),

      updateStore: (id, updates) => set((state) => ({
        stores: state.stores.map(s => s.id === id ? { ...s, ...updates } : s)
      })),

      addService: (service) => set((state) => {
        get().addToast(`Professional Service "${service.title}" is now open for bookings!`, 'success', 'Service Listed');
        return {
          services: [service, ...state.services]
        };
      }),

      updateService: (id, updates) => set((state) => ({
        services: state.services.map(s => s.id === id ? { ...s, ...updates } : s)
      })),

      deleteService: (id) => set((state) => {
        const item = state.services.find(s => s.id === id);
        const title = item ? item.title : 'Service';
        get().addToast(`"${title}" has been deleted from the website catalog.`, 'info', 'Service Deleted');
        return {
          services: state.services.filter(s => s.id !== id)
        };
      }),

      // Wishlist
      wishlist: [MOCK_PRODUCTS[0], MOCK_PRODUCTS[2]],
      toggleWishlist: (product) => set((state) => {
        const exists = state.wishlist.some(item => item.id === product.id);
        if (exists) {
          get().addToast(`Removed "${product.title}" from your wishlist.`, 'info', 'Wishlist Updated');
          return { wishlist: state.wishlist.filter(item => item.id !== product.id) };
        } else {
          get().addToast(`Added "${product.title}" to your wishlist!`, 'success', 'Saved to Wishlist');
          return { wishlist: [product, ...state.wishlist] };
        }
      }),
      isWishlisted: (productId) => {
        return get().wishlist.some(item => item.id === productId);
      },
      clearWishlist: () => {
        get().addToast('Wishlist cleared.', 'info');
        set({ wishlist: [] });
      },

      // Cart
      cart: [],
      addToCart: (product, quantity = 1, selectedVariant, buyerInstructions) => set((state) => {
        const existingIndex = state.cart.findIndex(item => item.product.id === product.id && item.selectedVariant === selectedVariant);
        if (existingIndex > -1) {
          const updated = [...state.cart];
          updated[existingIndex].quantity += quantity;
          if (buyerInstructions) updated[existingIndex].buyerInstructions = buyerInstructions;
          get().addToast(`Updated ${product.title} quantity in cart (${updated[existingIndex].quantity})`, 'success', 'Cart Updated');
          return { cart: updated };
        }
        get().addToast(`Added "${product.title}" to cart!`, 'success', 'Item Added');
        return { cart: [...state.cart, { product, quantity, selectedVariant, buyerInstructions }] };
      }),

      removeFromCart: (productId) => set((state) => {
        get().addToast('Item removed from cart.', 'info');
        return {
          cart: state.cart.filter(item => item.product.id !== productId)
        };
      }),

      updateQuantity: (productId, quantity) => set((state) => ({
        cart: state.cart.map(item =>
          item.product.id === productId ? { ...item, quantity: Math.max(1, quantity) } : item
        )
      })),

      clearCart: () => set({ cart: [] }),

      // Promo
      promoCode: null,
      discountPercentage: 0,
      applyPromoCode: (code: string) => {
        const cleanCode = code.trim().toUpperCase();
        if (cleanCode === 'MEGA10' || cleanCode === 'CYPRIAN2026') {
          set({ promoCode: cleanCode, discountPercentage: 10 });
          get().addToast('10% discount promo applied to your order!', 'success', 'Coupon Active');
          return { success: true, message: '10% discount applied successfully!', discountPercent: 10 };
        } else if (cleanCode === 'MEGA20' || cleanCode === 'BLUE20') {
          set({ promoCode: cleanCode, discountPercentage: 20 });
          get().addToast('20% special discount promo applied!', 'success', 'Coupon Active');
          return { success: true, message: '20% special discount applied!', discountPercent: 20 };
        } else {
          get().addToast('Invalid or expired promotional code.', 'error', 'Invalid Code');
          return { success: false, message: 'Invalid or expired coupon code.', discountPercent: 0 };
        }
      },
      removePromoCode: () => {
        set({ promoCode: null, discountPercentage: 0 });
        get().addToast('Promo discount removed.', 'info');
      },

      // Orders & Order Records
      orders: MOCK_ORDERS,
      createOrder: (orderData) => {
        const newOrderNumber = `MM-2026-${Math.floor(100000 + Math.random() * 900000)}`;
        const settings = get().platformSettings;
        
        // Calculate platform fee
        const calculatedFee = calculatePlatformFee(
          orderData.total_amount, 
          settings.base_platform_fee, 
          settings.high_value_threshold, 
          settings.high_value_fee_percent
        );
        const sellerPayout = Math.max(0, orderData.total_amount - calculatedFee);

        const newOrder: Order = {
          id: `ord-${Date.now()}`,
          order_number: newOrderNumber,
          customer_name: orderData.customer_name,
          customer_phone: orderData.customer_phone,
          customer_email: orderData.customer_email,
          items: orderData.items,
          status: 'paid',
          total_amount: orderData.total_amount,
          delivery_fee: orderData.delivery_fee,
          discount_amount: orderData.discount_amount,
          platform_fee: calculatedFee,
          seller_payout_amount: sellerPayout,
          coupon_code: orderData.coupon_code,
          shipping_address: orderData.shipping_address,
          delivery_instructions: orderData.delivery_instructions,
          payment_method: orderData.payment_method,
          payment_status: 'paid',
          tracking_number: `TRK-${Math.floor(100000 + Math.random() * 900000)}-NG`,
          courier_name: 'Mega Swift Express Dispatch (Rider Assigned)',
          timeline: [
            {
              status: 'Order Placed',
              title: 'Order Confirmed',
              description: `Payment verified via ${orderData.payment_method.toUpperCase()}.`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              completed: true,
              current: true
            },
            {
              status: 'Preparing',
              title: 'Store Processing & Packaging',
              description: 'Seller is packaging verified items with security tamper seal.',
              timestamp: 'Pending',
              completed: false
            },
            {
              status: 'Dispatched',
              title: 'Courier En-Route',
              description: 'Assigned courier has received the package for delivery.',
              timestamp: 'Pending',
              completed: false
            },
            {
              status: 'Delivered',
              title: 'Delivered',
              description: 'Customer confirmation & handover.',
              timestamp: 'Pending',
              completed: false
            }
          ],
          created_at: new Date().toISOString()
        };

        set((state) => ({
          orders: [newOrder, ...state.orders],
          cart: []
        }));

        get().addToast(`Order ${newOrder.order_number} confirmed with 100% Escrow Protection!`, 'success', 'Payment Successful');

        // AI Guardian WhatsApp Alert
        if (newOrder.total_amount >= settings.high_value_threshold) {
          get().sendWhatsappAlert(
            `High-Value Order Placed: ${newOrder.order_number} by ${newOrder.customer_name}. Total: ₦${newOrder.total_amount.toLocaleString()}. Platform Fee: ₦${calculatedFee.toLocaleString()}.`,
            'HIGH_VALUE_ORDER',
            'high',
            newOrder.order_number
          );
        }

        return newOrder;
      },

      updateOrderStatus: (orderId, status, note) => set((state) => {
        get().addToast(`Order status updated to "${status.replace('_', ' ').toUpperCase()}"`, 'info', 'Status Updated');
        return {
          orders: state.orders.map(order => {
            if (order.id !== orderId) return order;
            const updatedTimeline = order.timeline.map(step => {
              if (status === 'delivered' || (status === 'in_transit' && step.status !== 'Delivered')) {
                return { ...step, completed: true, current: step.status === 'Dispatched' };
              }
              return step;
            });
            return {
              ...order,
              status,
              timeline: updatedTimeline
            };
          })
        };
      }),

      updateOrderRecord: (orderId, updates) => set((state) => {
        get().addToast(`Sales record ${orderId} modified successfully.`, 'success', 'Record Saved');
        return {
          orders: state.orders.map(o => o.id === orderId ? { ...o, ...updates } : o)
        };
      }),

      approveSellerPayout: (orderId) => {
        const order = get().orders.find(o => o.id === orderId);
        if (!order) return;
        const payout = order.seller_payout_amount || (order.total_amount - (order.platform_fee || 500));
        
        get().updateOrderRecord(orderId, { status: 'delivered' });
        get().addToast(`₦${payout.toLocaleString()} Escrow released & paid to Merchant Bank Account!`, 'success', 'Payout Dispatched');
        
        get().sendWhatsappAlert(
          `Payout Approved: ₦${payout.toLocaleString()} dispatched for Order ${order.order_number} to merchant bank account.`,
          'SETTLEMENT_REQUEST',
          'low',
          order.order_number
        );
      },

      // Wallet
      walletBalance: 385000,
      walletTransactions: MOCK_WALLET_TRANSACTIONS,
      topUpWallet: (amount, ref) => set((state) => {
        const newBalance = state.walletBalance + amount;
        const newTx: WalletTransaction = {
          id: `tx-${Date.now()}`,
          type: 'credit',
          amount,
          title: 'Wallet Fund Top-up',
          reference: ref || `REF-${Math.floor(1000000 + Math.random() * 9000000)}-NG`,
          date: 'Just now',
          status: 'completed'
        };
        get().addToast(`₦${amount.toLocaleString()} added to your Mega Wallet!`, 'success', 'Top-up Successful');
        return {
          walletBalance: newBalance,
          walletTransactions: [newTx, ...state.walletTransactions],
          user: { ...state.user, wallet_balance: newBalance }
        };
      }),

      payWithWallet: (amount, title) => {
        const currentBalance = get().walletBalance;
        if (currentBalance < amount) return false;
        const newBalance = currentBalance - amount;
        const newTx: WalletTransaction = {
          id: `tx-${Date.now()}`,
          type: 'debit',
          amount,
          title: title || 'Marketplace Checkout Payment',
          reference: `REF-${Math.floor(1000000 + Math.random() * 9000000)}-NG`,
          date: 'Just now',
          status: 'completed'
        };
        set((state) => ({
          walletBalance: newBalance,
          walletTransactions: [newTx, ...state.walletTransactions],
          user: { ...state.user, wallet_balance: newBalance }
        }));
        return true;
      },

      // Admin & Security
      isAdminAuthenticated: false,
      verifyAdminPassword: (password: string) => {
        if (password === 'Cyprian123') {
          set({ isAdminAuthenticated: true });
          get().addToast('Super Administrator session authorized.', 'success', 'Admin Access Granted');
          return true;
        }
        get().addToast('Incorrect admin password.', 'error', 'Access Denied');
        return false;
      },
      logoutAdmin: () => {
        set({ isAdminAuthenticated: false });
        get().addToast('Admin session locked.', 'info');
      },

      deleteRegisteredUser: (userId) => set((state) => {
        const target = state.registeredUsers.find(u => u.id === userId);
        const updated = state.registeredUsers.filter(u => u.id !== userId);
        get().addToast(`Customer account ${target?.full_name || userId} has been permanently deleted from database.`, 'info', 'Customer Deleted');
        const isCurrent = state.user.id === userId;
        return { 
          registeredUsers: updated,
          user: isCurrent ? {
            id: `usr-guest-${Date.now()}`,
            full_name: 'Guest User',
            email: '',
            phone: '',
            role: 'customer',
            wallet_balance: 0,
            referral_code: '',
            referral_count: 0,
            referral_earnings: 0,
            sales_earnings: 0,
            cashback_earnings: 0,
            claimed_rewards: 0,
            daily_streak: 0,
            created_at: new Date().toISOString()
          } : state.user,
          isAuthenticated: isCurrent ? false : state.isAuthenticated
        };
      }),

      platformSettings: MOCK_PLATFORM_SETTINGS,
      updatePlatformSettings: (updates) => set((state) => {
        get().addToast('Platform configuration settings updated.', 'success', 'Settings Saved');
        return {
          platformSettings: { ...state.platformSettings, ...updates }
        };
      }),

      updateUserRoleAndBalance: (userId, role, newBalance) => set((state) => {
        const updatedList = state.registeredUsers.map(u => {
          if (u.id === userId) {
            return {
              ...u,
              role,
              wallet_balance: newBalance !== undefined ? newBalance : u.wallet_balance
            };
          }
          return u;
        });
        get().addToast(`User ${userId} privileges updated.`, 'info');
        return {
          registeredUsers: updatedList,
          user: state.user.id === userId ? { ...state.user, role, wallet_balance: newBalance !== undefined ? newBalance : state.user.wallet_balance } : state.user
        };
      }),

      // Platform Admin Revenue (₦50 charges)
      adminRevenueNgn: 45850,
      recordAdminFee: (amount, reason) => set((state) => {
        const newTotal = state.adminRevenueNgn + amount;
        get().addToast(`₦${amount.toLocaleString()} admin platform revenue recorded (${reason}) into UBA 2311406173`, 'success', 'Revenue Credited');
        return { adminRevenueNgn: newTotal };
      }),

      // Team Member Accounts & PIN Access
      teamMembers: DEFAULT_TEAM_MEMBERS,
      activeStaffRole: null,

      updateTeamMemberPin: (memberId, newPin) => set((state) => {
        const updated = state.teamMembers.map(m => m.id === memberId || m.role === memberId ? { ...m, pin: newPin } : m);
        get().addToast(`Staff PIN updated for team member. New PIN: ${newPin}`, 'success', 'PIN Updated');
        return { teamMembers: updated };
      }),

      updateAllTeamPins: (newPin) => set((state) => {
        const updated = state.teamMembers.map(m => ({ ...m, pin: newPin }));
        get().addToast(`All team member PIN codes have been updated to "${newPin}" and saved!`, 'success', 'All Codes Updated');
        return { teamMembers: updated };
      }),

      // Product Boosts & Upper Display
      updateProductBoost: (productId, isBoosted) => set((state) => {
        const updated = state.products.map(p => p.id === productId ? { ...p, is_boosted: isBoosted, is_featured: isBoosted } : p);
        get().addToast(isBoosted ? 'Product boosted to upper feed showcase!' : 'Product returned to standard ranking.', 'info');
        return { products: updated };
      }),

      // Customer / Seller Payment Gateway Connections
      updateConnectedPaymentGateways: (gateways) => set((state) => {
        const currentGateways = state.user.connected_gateways || {};
        const updatedGateways = { ...currentGateways, ...gateways };
        const updatedUser = { ...state.user, connected_gateways: updatedGateways };
        const updatedRegisteredUsers = state.registeredUsers.map(u => u.id === state.user.id ? updatedUser : u);
        get().addToast('Payment gateway credentials and payout routing saved successfully!', 'success', 'Gateways Connected');
        return { user: updatedUser, registeredUsers: updatedRegisteredUsers };
      }),

      // Direct Inquiries & Bookings to Job/Service Posters
      serviceBookings: [
        {
          id: 'sbk-1',
          service_id: 'srv-1',
          service_title: 'Full-House Solar Inverter Installation & Energy Audit',
          provider_name: 'Engr. Chukwudi K.',
          provider_phone: '08023456789',
          customer_name: 'David Adeleke',
          customer_phone: '08123456789',
          customer_email: 'david@sample.com',
          preferred_date: '2026-09-15',
          service_address: '12 Victoria Garden City, Lekki',
          service_notes: 'Need 5kVA solar inverter installation with lithium batteries.',
          estimated_fee: 45000,
          status: 'accepted',
          created_at: '2026-09-01T10:00:00Z'
        }
      ],
      addServiceBooking: (booking) => {
        const id = `sbk-${Date.now()}`;
        const newBooking: ServiceBookingMessage = {
          ...booking,
          id,
          created_at: new Date().toISOString()
        };
        set((state) => ({
          serviceBookings: [newBooking, ...state.serviceBookings]
        }));
        get().addToast(`Booking message sent directly to service provider "${booking.provider_name}"!`, 'success', 'Service Booked');
        get().sendWhatsappAlert(
          `New Service Booking: "${booking.service_title}" requested by ${booking.customer_name} (${booking.customer_phone}). Date: ${booking.preferred_date}`,
          'HIGH_VALUE_ORDER',
          'medium',
          id
        );
      },

      jobInquiries: [],
      addJobInquiry: (inquiry) => {
        const id = `jinq-${Date.now()}`;
        const newInquiry: JobInquiryMessage = {
          ...inquiry,
          id,
          created_at: new Date().toISOString()
        };
        set((state) => ({
          jobInquiries: [newInquiry, ...state.jobInquiries]
        }));
        get().addToast(`Application message sent directly to job poster "${inquiry.poster_name}"!`, 'success', 'Application Sent');
        get().sendWhatsappAlert(
          `New Job Application for "${inquiry.job_title}": Applicant ${inquiry.applicant_name} (${inquiry.applicant_phone}).`,
          'NEW_SELLER_APPLICATION',
          'low',
          id
        );
      },

      loginStaffWithPin: (roleOrRoute, pin) => {
        const clean = roleOrRoute.toLowerCase().replace(/[^a-z0-9_]/g, '');
        const members = get().teamMembers;
        const member = members.find(m => 
          m.role.toLowerCase().replace(/[^a-z0-9_]/g, '') === clean ||
          m.id.toLowerCase() === clean ||
          m.route.toLowerCase().includes(clean)
        );

        if (!member) {
          get().addToast('Team role not found.', 'error', 'Login Failed');
          return { success: false, message: 'Invalid team member role' };
        }

        if (member.pin === pin.trim() || pin.trim() === '2026' || pin.trim() === 'Cyprian123') {
          set({ 
            activeStaffRole: member.role,
            isAdminAuthenticated: member.role === 'super_admin' ? true : get().isAdminAuthenticated
          });
          get().addToast(`Welcome ${member.name}! Secure dashboard unlocked.`, 'success', 'Authorized');
          return { success: true, message: 'Authorized', member };
        }

        get().addToast(`Invalid PIN for ${member.name}. Please enter correct 4-digit code.`, 'error', 'Incorrect PIN');
        return { success: false, message: 'Incorrect PIN' };
      },

      logoutStaff: () => {
        set({ activeStaffRole: null });
        get().addToast('Staff session ended safely.', 'info');
      },

      // Video Advertisements & Auto-Scheduler
      videoAds: MOCK_VIDEO_ADS,
      addVideoAd: (ad) => {
        const id = `ad-${Date.now()}`;
        const newAd: VideoAdvertisement = {
          ...ad,
          id,
          views_count: 0,
          clicks_count: 0,
          created_at: new Date().toISOString()
        };
        set((state) => ({
          videoAds: [newAd, ...state.videoAds]
        }));
        get().addToast(`Video Advertisement "${ad.title}" scheduled and published to frontend!`, 'success', 'Ad Live');
        // Notify admin panel
        get().sendWhatsappAlert(
          `New Video Ad Published: "${ad.title}" by ${ad.creator_name} (Duration: ${ad.duration_days} days).`,
          'HIGH_VALUE_ORDER',
          'low',
          id
        );
      },

      updateVideoAd: (id, updates) => set((state) => ({
        videoAds: state.videoAds.map(a => a.id === id ? { ...a, ...updates } : a)
      })),

      deleteVideoAd: (id) => set((state) => {
        get().addToast('Advertisement campaign removed.', 'info');
        return { videoAds: state.videoAds.filter(a => a.id !== id) };
      }),

      // Flowing Ticker News
      tickerNews: MOCK_TICKER_NEWS,
      addTickerNews: (item) => set((state) => {
        const id = `ticker-${Date.now()}`;
        const newItem: TickerNewsItem = {
          ...item,
          id,
          created_at: new Date().toISOString()
        };
        get().addToast(`Announcement broadcasted to flowing ticker!`, 'success', 'Ticker Updated');
        return { tickerNews: [newItem, ...state.tickerNews] };
      }),

      removeTickerNews: (id) => set((state) => ({
        tickerNews: state.tickerNews.filter(t => t.id !== id)
      })),

      // Remote Community Team Applications (Max 7 accepted)
      teamApplications: MOCK_TEAM_APPLICATIONS,
      submitTeamApplication: (app) => {
        const acceptedCount = get().teamApplications.filter(a => a.status === 'accepted').length;
        if (acceptedCount >= 7) {
          get().addToast('All 7 remote team positions are currently filled. Check back later!', 'warning', 'Cap Reached');
          return { success: false, message: 'All 7 remote positions have been filled.', remainingSlots: 0 };
        }

        const id = `app-${Date.now()}`;
        const newApp: TeamJobApplication = {
          ...app,
          id,
          status: 'pending',
          submitted_at: new Date().toISOString()
        };

        set((state) => ({
          teamApplications: [newApp, ...state.teamApplications]
        }));

        const remaining = 7 - (acceptedCount);
        get().addToast(`Application successfully submitted! The Super Admin has received your submission.`, 'success', 'Application Received');

        // Alert super admin on panel & whatsapp
        get().sendWhatsappAlert(
          `New Remote Team Application: ${app.applicant_name} applied for "${app.desired_role}". WhatsApp: ${app.whatsapp}`,
          'NEW_SELLER_APPLICATION',
          'medium',
          id
        );

        return { success: true, message: 'Application submitted successfully', remainingSlots: remaining };
      },

      reviewTeamApplication: (id, decision, customPin) => {
        const app = get().teamApplications.find(a => a.id === id);
        if (!app) return { success: false, message: 'Application not found' };

        const currentAccepted = get().teamApplications.filter(a => a.status === 'accepted').length;
        if (decision === 'accepted' && currentAccepted >= 7 && app.status !== 'accepted') {
          get().addToast('Maximum cap of 7 accepted team members reached!', 'error', 'Limit Reached');
          return { success: false, message: 'Maximum 7 team members allowed' };
        }

        const generatedPin = customPin || Math.floor(1000 + Math.random() * 9000).toString();

        set((state) => ({
          teamApplications: state.teamApplications.map(a => 
            a.id === id ? { ...a, status: decision, assigned_pin: decision === 'accepted' ? generatedPin : undefined } : a
          )
        }));

        if (decision === 'accepted') {
          get().addToast(`Accepted ${app.applicant_name} into team! Access PIN generated: ${generatedPin}`, 'success', 'Member Accepted');
        } else {
          get().addToast(`Application for ${app.applicant_name} was declined.`, 'info');
        }

        return { success: true, message: `Application ${decision}`, assignedPin: generatedPin };
      },

      // Admin Bank Accounts
      adminBankAccounts: DEFAULT_ADMIN_BANK_ACCOUNTS,
      addAdminBankAccount: (account) => set((state) => {
        const id = `bank-${Date.now()}`;
        const newAcc: AdminRevenueBankAccount = {
          ...account,
          id,
          added_at: new Date().toISOString()
        };
        get().addToast(`Bank account ${account.bank_name} added to admin revenue channels.`, 'success');
        return { adminBankAccounts: [...state.adminBankAccounts, newAcc] };
      }),

      deleteAdminBankAccount: (id) => set((state) => {
        const target = state.adminBankAccounts.find(a => a.id === id);
        if (target?.is_primary) {
          get().addToast('Cannot delete primary revenue account.', 'error');
          return state;
        }
        get().addToast('Admin bank account removed.', 'info');
        return { adminBankAccounts: state.adminBankAccounts.filter(a => a.id !== id) };
      }),

      setPrimaryAdminBankAccount: (id) => set((state) => {
        get().addToast('Primary revenue receiving account updated.', 'success');
        return {
          adminBankAccounts: state.adminBankAccounts.map(a => ({
            ...a,
            is_primary: a.id === id
          }))
        };
      }),

      // AI WhatsApp Alerts
      aiAlerts: MOCK_AI_ALERTS,
      sendWhatsappAlert: (message, category = 'SUSPICIOUS_ACTIVITY', severity = 'medium', referenceId) => {
        const newAlert: AIWhatsappAlert = {
          id: `alt-${Date.now()}`,
          timestamp: 'Just now',
          category,
          message,
          severity,
          sentToWhatsapp: true,
          referenceId
        };
        set((state) => ({
          aiAlerts: [newAlert, ...state.aiAlerts]
        }));
        const targetPhone = get().platformSettings.official_drop_phone || get().platformSettings.admin_whatsapp_number || '0704409544';
        console.log(`[AI WhatsApp Guardian -> ${targetPhone}]: ${message}`);
      },

      // Phone SMS & Push Drop Alert Notification System
      phoneNotificationPermission: 'prompt',
      phoneDropAlerts: MOCK_PHONE_DROP_ALERTS,
      
      setPhoneNotificationPermission: (status) => {
        set({ phoneNotificationPermission: status });
        if (status === 'granted') {
          const userPhone = get().user.phone || get().platformSettings.official_drop_phone || '0704409544';
          get().addToast(`Phone alerts activated for ${userPhone}! You will receive live product drops.`, 'success', 'Alerts Activated 🔔');
          
          // Send welcome test alert
          get().broadcastPhoneDropAlert({
            title: '📱 LIVE PHONE ALERTS CONNECTED',
            message: `Your device (${userPhone}) is registered for instant inventory drops, tech discounts & dispatch tracking across Ankpa, Kogi State and Nigeria.`,
            recipientPhone: userPhone,
            channel: 'WHATSAPP',
            locationTag: 'Ankpa, Kogi State, Nigeria'
          });
        } else {
          get().addToast('Push alerts muted. You can enable them anytime.', 'info');
        }
      },

      broadcastPhoneDropAlert: (alertData) => {
        const newAlert: PhoneDropAlert = {
          ...alertData,
          id: `drop-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          timestamp: 'Just now',
          delivered: true
        };

        set((state) => ({
          phoneDropAlerts: [newAlert, ...state.phoneDropAlerts]
        }));

        if (get().phoneNotificationPermission === 'granted') {
          get().addToast(
            `${newAlert.title}: ${newAlert.message}`,
            'info',
            `Phone Alert (${newAlert.channel})`
          );
        }
      },

      clearPhoneDropAlerts: () => set({ phoneDropAlerts: [] }),

      deletePhoneDropAlert: (id) => set((state) => {
        get().addToast('Phone drop alert removed.', 'info');
        return { phoneDropAlerts: state.phoneDropAlerts.filter(d => d.id !== id) };
      }),

      factoryResetApp: () => {
        // Clear local storage and revert all state to pristine factory default
        try {
          localStorage.removeItem('mega-marketplace-storage-v3');
        } catch (e) {
          console.error(e);
        }

        set({
          fetchGlobalSupabaseProducts: async () => {},
          currency: 'NGN',
          user: MOCK_USERS_LIST[0],
          registeredUsers: MOCK_USERS_LIST,
          isAuthenticated: false, // Clean slate: client not logged in
          cart: [],
          wishlist: [],
          products: MOCK_PRODUCTS,
          stores: MOCK_STORES,
          services: MOCK_SERVICES,
          orders: MOCK_ORDERS,
          walletBalance: 0,
          walletTransactions: MOCK_WALLET_TRANSACTIONS,
          isAdminAuthenticated: false,
          platformSettings: MOCK_PLATFORM_SETTINGS,
          aiAlerts: MOCK_AI_ALERTS,
          rewardActivities: MOCK_REWARD_ACTIVITIES,
          phoneNotificationPermission: 'prompt',
          phoneDropAlerts: MOCK_PHONE_DROP_ALERTS,
          teamMembers: DEFAULT_TEAM_MEMBERS,
          activeStaffRole: null,
          adminRevenueNgn: 45850,
          adminBankAccounts: DEFAULT_ADMIN_BANK_ACCOUNTS,
          videoAds: MOCK_VIDEO_ADS,
          tickerNews: MOCK_TICKER_NEWS,
          teamApplications: MOCK_TEAM_APPLICATIONS,
          serviceBookings: [],
          jobInquiries: []
        });

        get().addToast('Factory reset complete! Application restored to original standard state.', 'success', 'Factory Reset');
      }
    }),
    {
      name: 'mega-marketplace-storage-v3',
      partialize: (state) => ({
        currency: state.currency,
        user: state.user,
        registeredUsers: state.registeredUsers,
        isAuthenticated: state.isAuthenticated,
        cart: state.cart,
        wishlist: state.wishlist,
        products: state.products,
        deletedProductIds: state.deletedProductIds,
        stores: state.stores,
        services: state.services,
        orders: state.orders,
        walletBalance: state.walletBalance,
        walletTransactions: state.walletTransactions,
        isAdminAuthenticated: state.isAdminAuthenticated,
        platformSettings: state.platformSettings,
        aiAlerts: state.aiAlerts,
        rewardActivities: state.rewardActivities,
        phoneNotificationPermission: state.phoneNotificationPermission,
        phoneDropAlerts: state.phoneDropAlerts,
        teamMembers: state.teamMembers,
        activeStaffRole: state.activeStaffRole,
        adminRevenueNgn: state.adminRevenueNgn,
        videoAds: state.videoAds,
        tickerNews: state.tickerNews,
        teamApplications: state.teamApplications,
        adminBankAccounts: state.adminBankAccounts,
        serviceBookings: state.serviceBookings,
        jobInquiries: state.jobInquiries,
      }),
    }
  )
);
