import { 
  Product, 
  Store, 
  ServiceItem, 
  Order, 
  WalletTransaction, 
  Profile, 
  PlatformSettings, 
  AIWhatsappAlert, 
  RewardActivity, 
  PhoneDropAlert,
  TeamMemberAccount,
  TeamJobApplication,
  VideoAdvertisement,
  TickerNewsItem,
  AdminRevenueBankAccount
} from '../types';

export const MOCK_PLATFORM_SETTINGS: PlatformSettings = {
  base_platform_fee: 50, // ₦50 base platform fee
  listing_fee_ngn: 50, // ₦50 listing charge
  payout_fee_ngn: 50, // ₦50 customer payout deduction
  high_value_threshold: 100000,
  high_value_fee_percent: 2.5,
  auto_approve_first_time_sellers: false, // Strict approval: requires admin/money checker payment approval
  admin_whatsapp_number: '0704409544',
  official_drop_phone: '0704409544',
  admin_avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300',
  admin_name: 'Cyprian O. (Super Admin)',
  admin_email: 'support@megamarket.com',
  platform_location: 'Ankpa, Kogi State, Nigeria',
  supabase_url: 'https://ugkvfehugcakdqbikdyx.supabase.co',
  supabase_anon_key: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVna3ZmZWh1Z2Nha2RxYmlrZHl4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA5MjI4NjAsImV4cCI6MjEwNjQ5ODg2MH0.IzeQYl5RG9mDUnh1InFPw_ZAp-xvory2Z9C6XE_dSqw'
};

export const DEFAULT_TEAM_MEMBERS: TeamMemberAccount[] = [
  {
    id: 'team-super',
    role: 'super_admin',
    name: 'Super Admin (You)',
    email: 'support@megamarket.com',
    phone: '0704409544',
    pin: '2026',
    route: '/#admin',
    status: 'active',
    last_active: 'Active now',
    description: 'Supreme oversight, master controls, team PIN dispatch & deletion power',
    avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300'
  },
  {
    id: 'team-bookkeeper',
    role: 'bookkeeper',
    name: 'Chief Bookkeeper',
    email: 'bookkeeper@megamarket.com',
    phone: '+234 813 445 7788',
    pin: '1122',
    route: '/@admin',
    status: 'active',
    last_active: '10 mins ago',
    description: 'Audits transaction ledgers, orders, daily balance sheets & records',
    avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300'
  },
  {
    id: 'team-money',
    role: 'money_checker',
    name: 'Payment / Money Checker',
    email: 'money@megamarket.com',
    phone: '+234 802 889 1122',
    pin: '3344',
    route: '/$admin',
    status: 'active',
    last_active: '25 mins ago',
    description: 'Verifies customer bank transfers, ₦50 seller payout fees & wallet deposits',
    avatar_url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=300'
  },
  {
    id: 'team-ads',
    role: 'ad_manager',
    name: 'Ad & Broadcast Manager',
    email: 'ads@megamarket.com',
    phone: '+234 816 772 3344',
    pin: '5566',
    route: '/%admin',
    status: 'active',
    last_active: '1 hr ago',
    description: 'Controls Video Lab ad builder, scheduled campaigns & live flowing ticker news',
    avatar_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=300'
  }
];

export const DEFAULT_ADMIN_BANK_ACCOUNTS: AdminRevenueBankAccount[] = [
  {
    id: 'bank-uba-revenue',
    bank_name: 'United Bank for Africa (UBA)',
    account_number: '2311406173',
    account_name: 'CYPRIAN MICHAEL OJOCHOGWU',
    is_primary: true,
    currency: 'NGN',
    notes: 'Official Mega Store Settlement Account: 2311406173 UBA BANK CYPRIAN MICHAEL OJOCHOGWU for all direct customer settlements and admin charges',
    added_at: '2026-01-01T00:00:00Z'
  },
  {
    id: 'bank-gtb-escrow',
    bank_name: 'Guaranty Trust Bank (GTBank)',
    account_number: '0123456789',
    account_name: 'Mega Market Escrow Clearing',
    is_primary: false,
    currency: 'NGN',
    notes: 'Secondary commercial reserve account',
    added_at: '2026-02-15T00:00:00Z'
  }
];

export const MOCK_VIDEO_ADS: VideoAdvertisement[] = [
  {
    id: 'ad-vid-1',
    title: 'Solar Power Inverter Systems — 40% Off Mega Deal',
    description: 'Pure copper coils, smart lithium batteries with 5 years guarantee for homes and shops in Nigeria.',
    video_url: 'https://assets.mixkit.co/videos/preview/mixkit-solar-panels-in-a-solar-power-plant-40617-large.mp4',
    poster_url: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&q=80&w=600',
    creator_name: 'Mega Energy Tech Ltd',
    duration_days: 14,
    status: 'active',
    target_url: '/product/solar-inverter-system-5kva',
    start_date: '2026-10-01',
    end_date: '2026-10-15',
    views_count: 4280,
    clicks_count: 612,
    daily_auto_post: true,
    budget: 25000,
    currency: 'NGN',
    created_at: '2026-10-01T10:00:00Z'
  },
  {
    id: 'ad-vid-2',
    title: 'MacBook Pro M3 Max Delivery Fleet',
    description: 'Same day VIP armored transit across Nigeria. Direct from certified Apple partner warehouse.',
    video_url: 'https://assets.mixkit.co/videos/preview/mixkit-hands-holding-a-smartphone-with-a-green-screen-40546-large.mp4',
    poster_url: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&q=80&w=600',
    creator_name: 'Tech Haven Official',
    duration_days: 7,
    status: 'active',
    target_url: '/product/macbook-pro-m3-max-16',
    start_date: '2026-10-03',
    end_date: '2026-10-10',
    views_count: 8940,
    clicks_count: 1420,
    daily_auto_post: true,
    budget: 35000,
    currency: 'NGN',
    created_at: '2026-10-03T14:30:00Z'
  }
];

export const MOCK_TICKER_NEWS: TickerNewsItem[] = [
  {
    id: 'ticker-1',
    title: '⚡ SYSTEM NOTICE',
    content: 'All verified merchants now receive instant ₦50 listing confirmation with automated 24/7 bank settlement!',
    category: 'announcement',
    is_active: true,
    created_at: '2026-10-08T00:00:00Z'
  },
  {
    id: 'ticker-2',
    title: '📢 REMOTE WORK RECRUITMENT',
    content: 'Community hiring open: 7 exclusive remote staff slots available for Bookkeeper, Money Checker, and Ad Managers. Apply now!',
    category: 'deals',
    is_active: true,
    created_at: '2026-10-08T02:00:00Z'
  },
  {
    id: 'ticker-3',
    title: '💳 UBA DIRECT DEPOSIT',
    content: 'Admin revenue channel active: UBA 2311406173. CBN encrypted escrow protection guarantees 100% security.',
    category: 'financial',
    is_active: true,
    created_at: '2026-10-08T04:00:00Z'
  }
];

export const MOCK_TEAM_APPLICATIONS: TeamJobApplication[] = [
  {
    id: 'app-1',
    applicant_name: 'Chinedu Okeke',
    email: 'chinedu.okeke@example.com',
    whatsapp: '+234 814 555 9012',
    desired_role: 'bookkeeper',
    experience_summary: '4 years experience managing inventory ledger, accounting software and balance reconciliation for retail brands.',
    remote_readiness: 'Equipped with stable fiber internet, laptop and uninterrupted solar inverter backup.',
    portfolio_url: 'https://linkedin.com/in/chinedu-okeke',
    status: 'accepted',
    assigned_pin: '1122',
    submitted_at: '2026-10-05T08:30:00Z'
  },
  {
    id: 'app-2',
    applicant_name: 'Fatima Bello',
    email: 'fatima.bello@example.com',
    whatsapp: '+234 809 333 4455',
    desired_role: 'ad_manager',
    experience_summary: 'Created video marketing campaigns on TikTok & Meta with over 200,000 views and direct conversions.',
    remote_readiness: 'High speed workstation, video editing suite (Premiere & CapCut) and 100% remote availability.',
    portfolio_url: 'https://instagram.com/fatima_adcraft',
    status: 'accepted',
    assigned_pin: '5566',
    submitted_at: '2026-10-06T11:15:00Z'
  },
  {
    id: 'app-3',
    applicant_name: 'Emmanuel Adeyemi',
    email: 'emmanuel.ade@example.com',
    whatsapp: '+234 812 777 6655',
    desired_role: 'money_checker',
    experience_summary: 'Former fintech operations analyst handling bank transfer disputes, NUBAN verifications and settlement logs.',
    remote_readiness: 'Dedicated home office with 24/7 internet and quick response time.',
    portfolio_url: 'https://linkedin.com/in/emmanuel-adeyemi',
    status: 'pending',
    submitted_at: '2026-10-07T14:40:00Z'
  }
];

export const NEUTRAL_AVATAR_PRESETS = [
  { id: 'neutral-1', name: 'Clean Minimalist', url: 'https://ui-avatars.com/api/?name=Admin+User&background=random' },
  { id: 'neutral-2', name: 'Professional Pro', url: 'https://ui-avatars.com/api/?name=Seller+Two&background=random' },
  { id: 'neutral-3', name: 'Modern Creative', url: 'https://ui-avatars.com/api/?name=Buyer+One&background=random' },
  { id: 'neutral-4', name: 'Executive Stylist', url: 'https://ui-avatars.com/api/?name=Buyer+Two&background=random' },
  { id: 'neutral-5', name: 'Verified Merchant', url: 'https://ui-avatars.com/api/?name=Merchant&background=random' },
  { id: 'neutral-6', name: 'Global VIP Trader', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300' }
];

export const MOCK_PHONE_DROP_ALERTS: PhoneDropAlert[] = [
  {
    id: 'drop-1',
    title: '⚡ LIVE DROP ALERT: MacBook M3 Max Workstations',
    message: 'Tech Haven has dropped 8 units in Ankpa, Kogi State inventory with instant dispatch warranty. Claim VIP rebate before stock ends!',
    timestamp: 'Just now',
    recipientPhone: '0704409544',
    channel: 'WHATSAPP',
    productTitle: 'MacBook Pro M3 Max 16"',
    productPrice: 4200000,
    productSlug: 'macbook-pro-m3-max-16',
    productImage: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&q=80&w=300',
    locationTag: 'Ankpa, Kogi State, Nigeria',
    delivered: true
  },
  {
    id: 'drop-2',
    title: '🔥 FLASH SALE: Sony WH-1000XM5 ANC Headphones',
    message: 'Verified merchant in Ankpa Central Hub just initiated flash sale at ₦325,000. Free doorstep delivery within Kogi & nationwide courier.',
    timestamp: '15 mins ago',
    recipientPhone: '0704409544',
    channel: 'SMS',
    productTitle: 'Sony WH-1000XM5 Noise-Canceling Wireless Headphones',
    productPrice: 325000,
    productSlug: 'sony-wh-1000xm5',
    productImage: 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?auto=format&fit=crop&q=80&w=300',
    locationTag: 'Ankpa, Kogi State, Nigeria',
    delivered: true
  }
];

export const MOCK_USERS_LIST: Profile[] = [
  {
    id: 'usr-1',
    full_name: 'Cyprian O.',
    email: 'cyprian@megamarket.ng',
    role: 'admin',
    phone: '0704409544',
    wallet_balance: 385000,
    referral_code: 'CYPRIAN2026',
    referral_count: 18,
    referral_earnings: 28000,
    sales_earnings: 1250000,
    cashback_earnings: 12400,
    claimed_rewards: 850000,
    daily_streak: 5,
    last_daily_claim: '2026-08-28T09:00:00Z',
    avatar_url: 'https://ui-avatars.com/api/?name=Admin+User&background=random',
    business_name: 'Mega Platform Master Control',
    business_address: 'No. 14 Otukpo-Enugu Commercial Road, Ankpa, Kogi State, Nigeria',
    delivery_address: 'Plot 5 Main Market Boulevard, Ankpa, Kogi State, Nigeria',
    bank_details: {
      bank_name: 'Guaranty Trust Bank (GTBank)',
      account_number: '0123456789',
      account_name: 'Cyprian O. Global',
      is_verified: true
    },
    created_at: '2026-01-01T00:00:00Z'
  },
  {
    id: 'usr-2',
    full_name: 'Amaka Eze (Tech Haven)',
    email: 'amaka@techhaven.ng',
    role: 'seller',
    phone: '+234 803 111 2233',
    wallet_balance: 1450000,
    referral_code: 'TECHHAVEN',
    referral_count: 12,
    referral_earnings: 18500,
    sales_earnings: 3420000,
    cashback_earnings: 18000,
    claimed_rewards: 2100000,
    daily_streak: 7,
    last_daily_claim: '2026-08-28T10:00:00Z',
    avatar_url: 'https://ui-avatars.com/api/?name=Seller+Two&background=random',
    business_name: 'Tech Haven Official Stores Ltd',
    business_address: 'Tech Plaza, Opposite Central Mosque, Ankpa, Kogi State, Nigeria',
    bank_details: {
      bank_name: 'Zenith Bank',
      account_number: '1012345678',
      account_name: 'Tech Haven Official Ltd',
      is_verified: true
    },
    created_at: '2026-01-15T08:00:00Z'
  },
  {
    id: 'usr-3',
    full_name: 'Folake Adeleke (Luxe Studio)',
    email: 'folake@luxestudio.ng',
    role: 'seller',
    phone: '+234 818 998 8776',
    wallet_balance: 620000,
    referral_code: 'LUXE2026',
    referral_count: 9,
    referral_earnings: 12000,
    sales_earnings: 980000,
    cashback_earnings: 8500,
    claimed_rewards: 450000,
    daily_streak: 3,
    avatar_url: 'https://ui-avatars.com/api/?name=Buyer+One&background=random',
    business_name: 'Luxe Bespoke Fashion Studio',
    business_address: 'Plot 8 Commercial Avenue, Ankpa, Kogi State, Nigeria',
    bank_details: {
      bank_name: 'Access Bank',
      account_number: '0712345678',
      account_name: 'Folake Adeleke Studio',
      is_verified: true
    },
    created_at: '2026-02-01T10:00:00Z'
  },
  {
    id: 'usr-4',
    full_name: 'Emeka Nwankwo (Buyer)',
    email: 'emeka.nwankwo@gmail.com',
    role: 'customer',
    phone: '+234 802 334 5566',
    wallet_balance: 45000,
    referral_code: 'EMEKA10',
    referral_count: 4,
    referral_earnings: 4000,
    sales_earnings: 0,
    cashback_earnings: 5200,
    claimed_rewards: 2000,
    daily_streak: 2,
    avatar_url: 'https://ui-avatars.com/api/?name=Buyer+Two&background=random',
    delivery_address: 'No. 22 Mission Road, Ankpa, Kogi State, Nigeria',
    created_at: '2026-02-12T14:30:00Z'
  }
];

export const MOCK_STORES: Store[] = [
  {
    id: 'store-1',
    owner_id: 'usr-2',
    name: 'Apple Official Store',
    description: 'Direct authorized distributor of Apple Inc. Flagship iPhone 16 Pro, M3 Max MacBooks, iPads & AirPods Max with 1-year global Apple Care warranty.',
    logo_url: 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&q=80&w=300',
    cover_url: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&q=80&w=1200',
    is_verified: true,
    rating: 4.95,
    reviews_count: 1420,
    followers_count: 4500000,
    tiktok_url: 'https://www.tiktok.com/@apple',
    tiktok_handle: '@apple',
    tiktok_followers: '4.5M',
    location: 'Apple Authorized Hub, Victoria Island, Lagos & Ankpa Tech Plaza',
    status: 'active',
    brand_color: 'from-slate-950 via-zinc-900 to-slate-900',
    featured_category: 'Electronics & Computing',
    created_at: '2026-01-15T08:00:00Z',
  },
  {
    id: 'store-2',
    owner_id: 'usr-3',
    name: 'Nike Official Athletics',
    description: 'Official Nike Sports & Athletics Distributor. Authentic Air Jordan 1 Retros, Nike Dunk Lows, Dri-FIT running gear & performance footwear with zero counterfeit guarantee.',
    logo_url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=300',
    cover_url: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80&w=1200',
    is_verified: true,
    rating: 4.9,
    reviews_count: 980,
    followers_count: 6800000,
    tiktok_url: 'https://www.tiktok.com/@nike',
    tiktok_handle: '@nike',
    tiktok_followers: '6.8M',
    location: 'Palms Mall, Lekki & Commercial Avenue, Ankpa, Nigeria',
    status: 'active',
    brand_color: 'from-slate-950 via-red-950 to-neutral-900',
    featured_category: 'Fashion & Luxury',
    created_at: '2026-02-01T10:00:00Z',
  },
  {
    id: 'store-3',
    owner_id: 'usr-1',
    name: 'Samsung Electronics Experience',
    description: 'Direct Authorized Samsung Experience Store. Galaxy S24 Ultra AI, Galaxy Z Fold 6, Neo QLED Smart TVs & Smart Home appliances with 24-month manufacturer warranty.',
    logo_url: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&q=80&w=300',
    cover_url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=1200',
    is_verified: true,
    rating: 4.88,
    reviews_count: 730,
    followers_count: 4100000,
    tiktok_url: 'https://www.tiktok.com/@samsung',
    tiktok_handle: '@samsung',
    tiktok_followers: '4.1M',
    location: 'Samsung Experience Center, Ikeja City Mall & Otukpo Road, Ankpa',
    status: 'active',
    brand_color: 'from-slate-950 via-blue-950 to-slate-900',
    featured_category: 'Electronics & Computing',
    created_at: '2026-02-10T12:00:00Z',
  },
  {
    id: 'store-4',
    owner_id: 'usr-1',
    name: 'Oraimo Official Brand Store',
    description: 'Official Oraimo Sound, Smart Energy & Clean Solar Distributor. FreePods 4, 30,000mAh Power Banks, Smart Inverter Solar stations & phone accessories with 365-day warranty.',
    logo_url: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&q=80&w=300',
    cover_url: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&q=80&w=1200',
    is_verified: true,
    rating: 4.85,
    reviews_count: 620,
    followers_count: 1800000,
    tiktok_url: 'https://www.tiktok.com/@oraimoclub',
    tiktok_handle: '@oraimoclub',
    tiktok_followers: '1.8M',
    location: 'Computer Village, Ikeja & Main Market Square, Ankpa, Nigeria',
    status: 'active',
    brand_color: 'from-slate-950 via-emerald-950 to-teal-950',
    featured_category: 'Home, Decor & Solar',
    created_at: '2026-02-18T12:00:00Z',
  },
  {
    id: 'store-5',
    owner_id: 'usr-3',
    name: 'Zara Fashion & Luxury Atelier',
    description: 'Contemporary European Haute Couture, tailored Italian blazers, full-grain leather goods, designer footwear & bespoke luxury streetwear.',
    logo_url: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=300',
    cover_url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=1200',
    is_verified: true,
    rating: 4.92,
    reviews_count: 1150,
    followers_count: 9200000,
    tiktok_url: 'https://www.tiktok.com/@zara',
    tiktok_handle: '@zara',
    tiktok_followers: '9.2M',
    location: 'Luxury Galleria, Victoria Island / Fast Express Dispatch',
    status: 'active',
    brand_color: 'from-slate-950 via-purple-950 to-rose-950',
    featured_category: 'Fashion & Luxury',
    created_at: '2026-02-25T12:00:00Z',
  }
];

export const MOCK_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    store_id: 'store-1',
    category: 'Electronics',
    title: 'MacBook Pro M3 Max 16" (48GB RAM, 1TB SSD)',
    slug: 'macbook-pro-m3-max-16',
    description: 'The ultimate professional workstation. Apple M3 Max chip with 16-core CPU, 40-core GPU, 48GB unified memory, and 16.2-inch Liquid Retina XDR display.',
    price: 4500000,
    discount_price: 4200000,
    stock: 8,
    images: [
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&q=80&w=1000'
    ],
    is_published: true,
    is_featured: true,
    is_flash_sale: true,
    flash_sale_end: '2026-08-30T23:59:59Z',
    rating: 4.9,
    reviews_count: 148,
    delivery_type: 'doorstep',
    delivery_notes: 'White-glove insured security courier dispatch with signature verification.',
    specifications: {
      'Processor': 'Apple M3 Max (16-Core)',
      'Memory': '48GB Unified RAM',
      'Storage': '1TB NVMe SuperFast SSD',
      'Display': '16.2" Liquid Retina XDR',
      'Warranty': '1 Year Apple International'
    },
    tags: ['laptop', 'apple', 'macbook', 'workstation', 'programming'],
        poster_account_bank: 'Guaranty Trust Bank (GTBank)',
    poster_account_number: '0123456789',
    poster_account_name: 'Apple Authorized Hub Direct',
    contact_whatsapp: '2348031112233',
    store: MOCK_STORES[0],
    created_at: '2026-02-20T10:00:00Z',
  },
  {
    id: 'prod-2',
    store_id: 'store-1',
    category: 'Electronics',
    title: 'Sony WH-1000XM5 Noise-Canceling Wireless Headphones',
    slug: 'sony-wh-1000xm5',
    description: 'Industry-leading noise cancellation optimized automatically based on wearing conditions and environment. 30-hour battery life with ultra-clear hands-free calling.',
    price: 380000,
    discount_price: 325000,
    stock: 24,
    images: [
      'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=1000'
    ],
    is_published: true,
    is_featured: true,
    is_flash_sale: true,
    rating: 4.8,
    reviews_count: 94,
    delivery_type: 'nationwide',
    specifications: {
      'Driver Unit': '30mm, dome type',
      'Battery Life': 'Up to 30 hours',
      'Connectivity': 'Bluetooth 5.2, LDAC',
      'Weight': '250g'
    },
    tags: ['audio', 'sony', 'headphones', 'bluetooth', 'anc'],
        poster_account_bank: 'Zenith Bank',
    poster_account_number: '1012345678',
    poster_account_name: 'Sony Authorized Hub',
    contact_whatsapp: '2348031112233',
    store: MOCK_STORES[0],
    created_at: '2026-02-21T10:00:00Z',
  },
  {
    id: 'prod-3',
    store_id: 'store-2',
    category: 'Fashion',
    title: 'Handcrafted Minimalist Italian Leather Sneaker',
    slug: 'minimalist-leather-sneaker',
    description: 'Precision stitched using full-grain Italian calfskin leather with durable Margom vulcanized rubber outsoles. Designed for all-day comfort and timeless styling.',
    price: 65000,
    discount_price: 49000,
    stock: 45,
    images: [
      'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&q=80&w=1000'
    ],
    is_published: true,
    is_featured: true,
    rating: 4.9,
    reviews_count: 67,
    delivery_type: 'doorstep',
    specifications: {
      'Upper Material': 'Full-Grain Italian Calf Leather',
      'Sole': 'Margom Italian Rubber',
      'Lining': 'Breathable Vachetta Leather',
      'Color': 'Alabaster White'
    },
    tags: ['shoes', 'sneakers', 'leather', 'fashion', 'wedding', 'casual'],
        poster_account_bank: 'Access Bank',
    poster_account_number: '0712345678',
    poster_account_name: 'Nike Athletics & Luxury Studio',
    contact_whatsapp: '2348189988776',
    store: MOCK_STORES[1],
    created_at: '2026-02-22T10:00:00Z',
  },
  {
    id: 'prod-4',
    store_id: 'store-2',
    category: 'Fashion',
    title: 'Heavyweight Organic Cotton Relaxed Oversized Tee',
    slug: 'organic-cotton-tshirt',
    description: '280 GSM luxury combed cotton with drop-shoulder tailoring and a reinforced ribbed collar. Pre-shrunk for an enduring silhouette.',
    price: 22000,
    discount_price: 18000,
    stock: 80,
    images: [
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&q=80&w=1000'
    ],
    is_published: true,
    rating: 4.7,
    reviews_count: 52,
    delivery_type: 'nationwide',
    specifications: {
      'Fabric': '100% GOTS Certified Organic Cotton',
      'Weight': '280 GSM Heavyweight',
      'Fit': 'Relaxed Boxy Fit'
    },
    tags: ['tshirt', 'clothing', 'apparel', 'cotton', 'minimal'],
        poster_account_bank: 'Access Bank',
    poster_account_number: '0712345678',
    poster_account_name: 'Nike Athletics & Luxury Studio',
    contact_whatsapp: '2348189988776',
    store: MOCK_STORES[1],
    created_at: '2026-02-23T10:00:00Z',
  },
  {
    id: 'prod-5',
    store_id: 'store-3',
    category: 'Home & Living',
    title: 'Ergonomic Mesh Swivel High-Back Office Chair',
    slug: 'ergonomic-mesh-office-chair',
    description: 'Engineered for 12+ hours of lumbar comfort. Multi-axis dynamic armrests, breathable Korean mesh backrest, and class-4 heavy-duty pneumatic lift cylinder.',
    price: 285000,
    discount_price: 245000,
    stock: 14,
    images: [
      'https://images.unsplash.com/photo-1580481077195-c3a82145d875?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1505797149-43b0069ec26b?auto=format&fit=crop&q=80&w=1000'
    ],
    is_published: true,
    is_featured: true,
    rating: 4.8,
    reviews_count: 41,
    delivery_type: 'doorstep',
    specifications: {
      'Max Weight': '150 kg',
      'Adjustment': '3D Lumbar + 4D Armrests',
      'Base': 'Reinforced Polished Aluminum',
      'Warranty': '3 Years'
    },
    tags: ['furniture', 'chair', 'office', 'ergonomic', 'workspace'],
        poster_account_bank: 'First Bank of Nigeria',
    poster_account_number: '3098765432',
    poster_account_name: 'Samsung & Ergonomics Hub',
    contact_whatsapp: '234704409544',
    store: MOCK_STORES[2],
    created_at: '2026-02-24T10:00:00Z',
  },
  {
    id: 'prod-6',
    store_id: 'store-1',
    category: 'Electronics',
    title: 'Samsung Galaxy S24 Ultra 5G (512GB Titanium Gray)',
    slug: 'samsung-galaxy-s24-ultra',
    description: 'Galaxy AI smartphone with 200MP camera, built-in S Pen, Titanium exterior frame, and Snapdragon 8 Gen 3 chipset.',
    price: 1850000,
    discount_price: 1720000,
    stock: 15,
    images: [
      'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&q=80&w=1000'
    ],
    is_published: true,
    is_flash_sale: true,
    rating: 4.9,
    reviews_count: 86,
    delivery_type: 'doorstep',
    specifications: {
      'Display': '6.8" Dynamic AMOLED 2X 120Hz',
      'Processor': 'Snapdragon 8 Gen 3 for Galaxy',
      'Camera': '200MP + 50MP + 12MP + 10MP Quad Lens',
      'Battery': '5000 mAh Fast Charge 45W'
    },
    tags: ['phone', 'samsung', 'galaxy', 'android', 'flagship'],
        poster_account_bank: 'United Bank for Africa (UBA)',
    poster_account_number: '2311406173',
    poster_account_name: 'Samsung Experience Center',
    contact_whatsapp: '234704409544',
    store: MOCK_STORES[0],
    created_at: '2026-02-25T10:00:00Z',
  },
  {
    id: 'prod-7',
    store_id: 'store-3',
    category: 'Home & Living',
    title: 'Felicity 5kVA 48V Pure Sine Wave Hybrid Solar Inverter & 10kWh Lithium Battery System',
    slug: 'felicity-5kva-hybrid-solar-inverter-system',
    description: 'Complete 24/7 clean solar power system for homes and offices. High-efficiency 5kVA hybrid solar inverter with smart MPPT controller, 48V 200Ah (10kWh) Wall-Mount Lithium LiFePO4 battery bank, smart LCD telemetry, and heavy-duty surge protection.',
    price: 3650000,
    discount_price: 3200000,
    stock: 10,
    images: [
      'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1508873696983-2df5293cb325?auto=format&fit=crop&q=80&w=1000'
    ],
    is_published: true,
    is_featured: true,
    is_flash_sale: true,
    flash_sale_end: '2026-08-31T23:59:59Z',
    rating: 4.9,
    reviews_count: 58,
    delivery_type: 'doorstep',
    delivery_notes: 'Free certified technician inspection and white-glove doorstep delivery across Ankpa, Kogi State, and nationwide.',
    specifications: {
      'Inverter Capacity': '5kVA / 5000W Pure Sine Wave',
      'Battery Bank': '48V 200Ah (10kWh LiFePO4 Lithium)',
      'Solar Input': 'Dual MPPT (up to 5500W PV Input)',
      'Efficiency': '98.5% Peak Solar Conversion',
      'Warranty': '5 Years Comprehensive Manufacturer Warranty'
    },
    tags: ['solar', 'inverter', 'battery', 'lithium', 'power', 'clean energy', 'backup'],
        poster_account_bank: 'United Bank for Africa (UBA)',
    poster_account_number: '2311406173',
    poster_account_name: 'Felicity Solar Energy Systems',
    contact_whatsapp: '234704409544',
    store: MOCK_STORES[2],
    created_at: '2026-02-26T10:00:00Z',
  }
];

export const MOCK_SERVICES: ServiceItem[] = [];

export const MOCK_ORDERS: Order[] = [
  {
    id: 'ord-101',
    order_number: 'MM-2026-000142',
    customer_name: 'Cyprian O.',
    customer_phone: '0704409544',
    customer_email: 'cyprian@megamarket.ng',
    items: [
      {
        product: MOCK_PRODUCTS[1],
        quantity: 1,
        buyerInstructions: 'Please deliver in bubble wrap packaging.'
      },
      {
        product: MOCK_PRODUCTS[3],
        quantity: 2,
      }
    ],
    status: 'in_transit',
    subtotal: 361000,
    total_amount: 361000,
    delivery_fee: 3000,
    discount_amount: 5000,
    platform_fee: 2500,
    seller_payout_amount: 355500,
    coupon_code: 'MEGAWELCOME',
    shipping_address: {
      street: '14 Admiralty Way, Lekki Phase 1',
      city: 'Lekki',
      state: 'Lagos',
      instructions: 'Leave at front security desk'
    },
    delivery_instructions: 'Call customer upon arrival at the gate',
    payment_method: 'paystack',
    payment_status: 'paid',
    tracking_number: 'TRK-982341-NG',
    courier_name: 'GIG Express Logistics (Rider: Babatunde A.)',
    timeline: [
      {
        status: 'Order Placed',
        title: 'Order Confirmed',
        description: 'Payment verified via Paystack.',
        timestamp: 'Aug 29, 2026 - 10:14 AM',
        completed: true
      },
      {
        status: 'Preparing',
        title: 'Packed by Tech Haven',
        description: 'Store has boxed your items with security tamper seal.',
        timestamp: 'Aug 29, 2026 - 11:30 AM',
        completed: true
      },
      {
        status: 'Dispatched',
        title: 'Courier Picked Up',
        description: 'Courier Babatunde A. is en-route with your package.',
        timestamp: 'Aug 29, 2026 - 01:15 PM',
        completed: true,
        current: true
      },
      {
        status: 'Delivered',
        title: 'Delivered to Customer',
        description: 'Package handed over and digital signature obtained.',
        timestamp: 'Estimated: Today, 04:30 PM',
        completed: false
      }
    ],
    created_at: '2026-08-29T10:14:00Z'
  },
  {
    id: 'ord-102',
    order_number: 'MM-2026-000138',
    customer_name: 'Emeka Nwankwo',
    customer_phone: '+234 802 334 5566',
    customer_email: 'emeka.nwankwo@gmail.com',
    items: [
      {
        product: MOCK_PRODUCTS[2],
        quantity: 1,
      }
    ],
    status: 'delivered',
    subtotal: 49000,
    total_amount: 52000,
    delivery_fee: 3000,
    discount_amount: 0,
    platform_fee: 500,
    seller_payout_amount: 48500,
    shipping_address: 'Block B, 10 Banana Island Road, Ikoyi, Lagos',
    payment_method: 'wallet',
    payment_status: 'paid',
    tracking_number: 'TRK-449102-NG',
    courier_name: 'Mega Dispatch Express',
    timeline: [
      {
        status: 'Order Placed',
        title: 'Order Confirmed',
        description: 'Payment paid via Mega Wallet.',
        timestamp: 'Aug 28, 2026 - 09:00 AM',
        completed: true
      },
      {
        status: 'Delivered',
        title: 'Delivered and Confirmed',
        description: 'Handover complete.',
        timestamp: 'Aug 28, 2026 - 04:12 PM',
        completed: true
      }
    ],
    created_at: '2026-08-28T09:00:00Z'
  }
];

export const MOCK_WALLET_TRANSACTIONS: WalletTransaction[] = [
  {
    id: 'tx-1',
    type: 'credit',
    amount: 150000,
    title: 'Wallet Top-up (Bank Transfer)',
    reference: 'REF-8492048-NG',
    date: '28 Aug 2026, 03:45 PM',
    status: 'completed'
  },
  {
    id: 'tx-2',
    type: 'debit',
    amount: 39000,
    title: 'Payment for Order #MM-2026-000139',
    reference: 'REF-3940192-NG',
    date: '25 Aug 2026, 11:20 AM',
    status: 'completed'
  },
  {
    id: 'tx-3',
    type: 'credit',
    amount: 5000,
    title: 'Referral Bonus (Invite: CYPRIAN2026)',
    reference: 'REF-REF-202601',
    date: '20 Aug 2026, 09:10 AM',
    status: 'completed'
  }
];

export const MOCK_AI_ALERTS: AIWhatsappAlert[] = [
  {
    id: 'alt-1',
    timestamp: '2 mins ago',
    category: 'HIGH_VALUE_ORDER',
    message: 'High-Value purchase detected: MacBook Pro M3 Max (₦4,200,000) placed by Cyprian O. Commission fee: ₦105,000.',
    severity: 'high',
    sentToWhatsapp: true,
    referenceId: 'MM-2026-000142'
  },
  {
    id: 'alt-2',
    timestamp: '15 mins ago',
    category: 'NEW_SELLER_APPLICATION',
    message: 'New Merchant Onboarded: "Nordic Living & Solar" configured GTBank direct settlement.',
    severity: 'low',
    sentToWhatsapp: true,
    referenceId: 'store-3'
  },
  {
    id: 'alt-3',
    timestamp: '1 hour ago',
    category: 'SETTLEMENT_REQUEST',
    message: 'Auto Escrow Release queued: ₦48,500 payout ready for Folake Adeleke (Luxe Studio) on delivered Order #MM-2026-000138.',
    severity: 'medium',
    sentToWhatsapp: true,
    referenceId: 'ord-102'
  }
];

export const MOCK_REWARD_ACTIVITIES: RewardActivity[] = [
  {
    id: 'rew-1',
    user_id: 'usr-1',
    type: 'referral_signup',
    title: 'Referral Bonus: Amaka Eze Registered',
    description: 'New merchant signup via your invite code CYPRIAN2026.',
    amount: 1000,
    status: 'claimed',
    date: '28 Aug 2026, 11:20 AM',
    reference: 'REF-AMAKA-2026'
  },
  {
    id: 'rew-2',
    user_id: 'usr-1',
    type: 'referral_order_commission',
    title: '5% Referral Commission: Order #MM-2026-000142',
    description: 'Your referee placed their first high-value electronics order.',
    amount: 18050,
    status: 'available',
    date: '29 Aug 2026, 10:15 AM',
    reference: 'COM-ORD-142'
  },
  {
    id: 'rew-3',
    user_id: 'usr-1',
    type: 'sales_payout',
    title: 'Escrow Merchant Payout: Order #MM-2026-000138',
    description: 'Bespoke item successfully delivered and verified by buyer.',
    amount: 48500,
    status: 'available',
    date: '28 Aug 2026, 04:30 PM',
    reference: 'ESC-PAY-138'
  },
  {
    id: 'rew-4',
    user_id: 'usr-1',
    type: 'cashback',
    title: 'VIP Buyer Cashback (1.5%)',
    description: 'Cashback reward credited for shopping verified brands.',
    amount: 5415,
    status: 'claimed',
    date: '27 Aug 2026, 02:00 PM',
    reference: 'CSH-VIP-2026'
  },
  {
    id: 'rew-5',
    user_id: 'usr-1',
    type: 'daily_streak',
    title: 'Daily Streak Bonus (Day 5/7)',
    description: 'Daily check-in loyalty bonus dropped into rewards pool.',
    amount: 1000,
    status: 'available',
    date: '29 Aug 2026, 08:00 AM',
    reference: 'STRK-D5'
  },
  {
    id: 'rew-6',
    user_id: 'usr-1',
    type: 'vip_milestone',
    title: 'Gold Affiliate Tier Milestone Reached',
    description: 'Earned bonus for reaching over 15 successful friend referrals!',
    amount: 10000,
    status: 'available',
    date: '26 Aug 2026, 06:45 PM',
    reference: 'MLS-GOLD-2026'
  }
];
