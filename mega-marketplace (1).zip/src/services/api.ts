import { supabase, IS_MOCK_ENV } from '../lib/supabase';
import { Product, Store, ServiceItem } from '../types';
import { useStore } from '../store';

export const api = {
  products: {
    getAll: async (): Promise<Product[]> => {
      // In local mode before Supabase, pull from reactive Zustand store (which contains custom added products too!)
      if (IS_MOCK_ENV) {
        return useStore.getState().products;
      }
      
      try {
        const { data, error } = await supabase
          .from('products')
          .select('*, store:stores(*)')
          .eq('is_published', true)
          .order('created_at', { ascending: false });
          
        if (!error && data && data.length > 0) {
          return data as Product[];
        }
      } catch (err) {
        console.debug('Supabase products fetch fallback to store:', err);
      }
      return useStore.getState().products;
    },
    
    getFeatured: async (): Promise<Product[]> => {
      try {
        const { data, error } = await supabase
          .from('products')
          .select('*, store:stores(*)')
          .eq('is_published', true)
          .limit(10);
          
        if (!error && data && data.length > 0) {
          return data as Product[];
        }
      } catch (err) {
        console.debug('Supabase featured products fallback to store:', err);
      }
      return useStore.getState().products.filter(p => p.is_published);
    },
    
    getBySlug: async (slug: string): Promise<Product | null> => {
      try {
        const { data, error } = await supabase
          .from('products')
          .select('*, store:stores(*)')
          .eq('slug', slug)
          .single();
          
        if (!error && data) {
          return data as Product;
        }
      } catch (err) {
        console.debug('Supabase product slug fetch fallback to store:', err);
      }
      const found = useStore.getState().products.find(p => p.slug === slug);
      return found || null;
    }
  },

  services: {
    getAll: async (): Promise<ServiceItem[]> => {
      return useStore.getState().services;
    }
  },

  stores: {
    getAll: async (): Promise<Store[]> => {
      return useStore.getState().stores;
    }
  }
};
