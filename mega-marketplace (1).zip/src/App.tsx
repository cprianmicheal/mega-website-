/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';

// Page components
import Home from './pages/Home';
import Explore from './pages/Explore';
import Sell from './pages/Sell';
import ProductDetails from './pages/ProductDetails';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Account from './pages/Account';
import Wishlist from './pages/Wishlist';
import Admin from './pages/Admin';
import Bookkeeper from './pages/admin/Bookkeeper';
import MoneyChecker from './pages/admin/MoneyChecker';
import AdManager from './pages/admin/AdManager';
import SuperAdmin from './pages/admin/SuperAdmin';
import JoinTeam from './pages/JoinTeam';
import SupabaseSetup from './pages/SupabaseSetup';

export default function App() {
  return (
    <React.Suspense
      fallback={
        <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-3" />
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Loading Mega Marketplace...</span>
        </div>
      }
    >
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="explore" element={<Explore />} />
          <Route path="sell" element={<Sell />} />
          <Route path="product/:slug" element={<ProductDetails />} />
          <Route path="cart" element={<Cart />} />
          <Route path="checkout" element={<Checkout />} />
          <Route path="account" element={<Account />} />
          <Route path="wishlist" element={<Wishlist />} />
          <Route path="apply" element={<JoinTeam />} />
          <Route path="join-team" element={<JoinTeam />} />
          <Route path="supabase-setup" element={<SupabaseSetup />} />
          
          {/* Direct Custom Admin Portals requested: /@admin, /$admin, /%admin, /#admin */}
          <Route path="@admin" element={<Bookkeeper />} />
          <Route path="$admin" element={<MoneyChecker />} />
          <Route path="%admin" element={<AdManager />} />
          <Route path="%25admin" element={<AdManager />} />
          
          {/* Standard Admin Sub-routes */}
          <Route path="admin" element={<Admin />} />
          <Route path="admin/super" element={<SuperAdmin />} />
          <Route path="admin/bookkeeper" element={<Bookkeeper />} />
          <Route path="admin/money" element={<MoneyChecker />} />
          <Route path="admin/ads" element={<AdManager />} />
        </Route>
      </Routes>
    </React.Suspense>
  );
}
