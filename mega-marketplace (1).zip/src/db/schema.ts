import { relations } from 'drizzle-orm';
import { integer, pgTable, serial, text, timestamp, boolean } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Firebase Auth UID
  email: text('email').notNull(),
  role: text('role').default('user'), // 'admin', 'staff', 'user'
  pin: text('pin'), // Encrypted PIN for staff
  createdAt: timestamp('created_at').defaultNow(),
});

export const bankAccounts = pgTable('bank_accounts', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  bankName: text('bank_name').notNull(),
  accountNumber: text('account_number').notNull(),
});

export const advertisements = pgTable('advertisements', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  title: text('title').notNull(),
  description: text('description'),
  videoUrl: text('video_url'),
  currency: text('currency').default('USD').notNull(),
  scheduledAt: timestamp('scheduled_at'),
  status: text('status').default('pending'), // 'pending', 'approved', 'rejected'
  createdAt: timestamp('created_at').defaultNow(),
});

export const news = pgTable('news', {
  id: serial('id').primaryKey(),
  content: text('content').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

export const usersRelations = relations(users, ({ many }) => ({
  bankAccounts: many(bankAccounts),
  advertisements: many(advertisements),
}));
