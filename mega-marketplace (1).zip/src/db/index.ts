import { supabase, getCurrentSupabaseConfig } from '../lib/supabase';

export { supabase };

const config = getCurrentSupabaseConfig();

export const db = {
  // Supabase Database Connection Interface for Mega Marketplace & Ads Manager
  client: supabase,
  status: `Connected to Supabase (${config.projectRef})`,
  projectRef: config.projectRef,
  url: config.url,
  timestamp: new Date().toISOString()
};

console.log(`🔗 Database globally connected to Supabase: ${config.url}`);
