export type UserRole = 'customer' | 'seller' | 'admin';

export type CurrencyCode = 'NGN' | 'USD' | 'GBP' | 'EUR' | 'GHS' | 'KES' | 'ZAR' | 'CAD' | 'AED' | 'JPY' | 'CNY';

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  name: string;
  rateAgainstNGN: number; // multiplier from NGN to this currency
  flag: string;
}

export interface BankAccountDetails {
  bank_name: string;
  account_number: string;
  account_name: string;
  is_verified?: boolean;
}

export interface RewardActivity {
  id: string;
  user_id: string;
  type: 'referral_signup' | 'referral_order_commission' | 'sales_payout' | 'cashback' | 'daily_streak' | 'vip_milestone';
  title: string;
  description: string;
  amount: number;
  status: 'available' | 'claimed' | 'pending';
  date: string;
  reference?: string;
}

export interface ConnectedPaymentGateways {
  paystack_enabled?: boolean;
  paystack_subaccount_code?: string;
  flutterwave_enabled?: boolean;
  flutterwave_subaccount_id?: string;
  bank_transfer_enabled?: boolean;
  bank_name?: string;
  account_number?: string;
  account_name?: string;
  stripe_enabled?: boolean;
  stripe_account_id?: string;
  crypto_usdt_address?: string;
  primary_gateway?: 'paystack' | 'flutterwave' | 'bank_transfer' | 'stripe' | 'crypto';
  is_verified?: boolean;
}

export interface ServiceBookingMessage {
  id: string;
  service_id: string;
  service_title: string;
  provider_name: string;
  provider_phone?: string;
  customer_name: string;
  customer_phone: string;
  customer_email?: string;
  preferred_date: string;
  service_address: string;
  service_notes: string;
  estimated_fee: number;
  status: 'pending' | 'accepted' | 'contacted' | 'completed';
  created_at: string;
}

export interface JobInquiryMessage {
  id: string;
  job_id: string;
  job_title: string;
  poster_name: string;
  poster_contact?: string;
  applicant_name: string;
  applicant_phone: string;
  applicant_email: string;
  resume_notes: string;
  portfolio_url?: string;
  status: 'new' | 'reviewed' | 'contacted';
  created_at: string;
}

export interface Profile {
  id: string;
  email?: string;
  full_name: string;
  avatar_url?: string;
  role: UserRole;
  phone?: string;
  wallet_balance?: number;
  referral_code?: string;
  referred_by?: string;
  referral_count?: number;
  referral_earnings?: number;
  sales_earnings?: number;
  cashback_earnings?: number;
  claimed_rewards?: number;
  daily_streak?: number;
  last_daily_claim?: string;
  business_name?: string;
  business_address?: string;
  paystack_subaccount_code?: string;
  bank_details?: BankAccountDetails;
  connected_gateways?: ConnectedPaymentGateways;
  delivery_address?: string;
  is_seller_approved?: boolean;
  created_at: string;
}

export interface Store {
  id: string;
  owner_id: string;
  name: string;
  description: string;
  logo_url?: string;
  cover_url?: string;
  is_verified: boolean;
  rating?: number;
  reviews_count?: number;
  followers_count?: number;
  location?: string;
  status: 'active' | 'suspended' | 'pending';
  brand_color?: string;
  featured_category?: string;
  tiktok_url?: string;
  tiktok_handle?: string;
  tiktok_followers?: string;
  created_at: string;
}

export interface Product {
  id: string;
  store_id: string;
  category_id?: string;
  category?: string;
  title: string;
  slug: string;
  description: string;
  price: number; // stored in base NGN
  currency?: CurrencyCode; // Added currency support
  discount_price?: number; // stored in base NGN
  stock: number;
  images: string[];
  is_published: boolean;
  is_approved?: boolean;
  is_featured?: boolean;
  is_boosted?: boolean; // Placed at top / upper products feed
  paid_admin_fee?: number;
  is_flash_sale?: boolean;
  flash_sale_end?: string;
  rating?: number;
  reviews_count?: number;
  specifications?: Record<string, string>;
  tags?: string[];
  store?: Store;
  delivery_type?: 'doorstep' | 'pickup' | 'nationwide';
  delivery_notes?: string;
  website_url?: string; // external website redirection
  video_url?: string; // Product video advertisement link
  listing_type?: 'product' | 'service' | 'job' | 'business_listing' | 'sales_agent';
  contact_whatsapp?: string;
  poster_account_bank?: string;
  poster_account_number?: string;
  poster_account_name?: string;
  created_at: string;
}

export interface ServiceItem {
  id: string;
  provider_name: string;
  provider_avatar: string;
  title: string;
  category: string;
  description: string;
  price: number;
  pricing_unit: string; // 'per project' | 'per hour' | 'starting price'
  location: string;
  rating: number;
  reviews_count: number;
  is_verified: boolean;
  image: string;
  available_days: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedVariant?: string;
  buyerInstructions?: string;
}

export interface OrderTimelineItem {
  status: string;
  title: string;
  description: string;
  timestamp: string;
  completed: boolean;
  current?: boolean;
}

export interface OrderAddress {
  street: string;
  city: string;
  state: string;
  instructions?: string;
}

export interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  customer_email: string;
  items: CartItem[];
  status: 'pending_payment' | 'paid' | 'processing' | 'in_transit' | 'delivered' | 'cancelled';
  subtotal?: number;
  total_amount: number;
  delivery_fee: number;
  discount_amount: number;
  coupon_code?: string;
  platform_fee?: number;
  seller_payout_amount?: number;
  shipping_address: string | OrderAddress;
  delivery_instructions?: string;
  payment_method: 'paystack' | 'wallet' | 'bank_transfer' | string;
  payment_status: 'paid' | 'pending' | 'failed';
  tracking_number?: string;
  courier_name?: string;
  timeline: OrderTimelineItem[];
  created_at: string;
}

export interface WalletTransaction {
  id: string;
  type: 'credit' | 'debit';
  amount: number;
  title: string;
  description?: string;
  reference: string;
  date: string;
  created_at?: string;
  status: 'completed' | 'pending';
}

export interface SupportTicket {
  id: string;
  subject: string;
  category: string;
  status: 'open' | 'in_progress' | 'resolved';
  date: string;
  messages: { sender: 'user' | 'support'; text: string; time: string }[];
}

export interface Dispute {
  id: string;
  order_number: string;
  reason: string;
  status: 'reviewing' | 'seller_responded' | 'resolved';
  amount: number;
  date: string;
}

export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface ToastItem {
  id: string;
  title?: string;
  message: string;
  type: ToastType;
  duration?: number;
}

export interface PlatformSettings {
  base_platform_fee: number; // e.g. 50 NGN listing / payout fee
  listing_fee_ngn: number; // 50 NGN per product post
  payout_fee_ngn: number; // 50 NGN per payout
  high_value_threshold: number; // e.g. 100000 NGN
  high_value_fee_percent: number; // e.g. 2.5%
  auto_approve_first_time_sellers: boolean;
  admin_whatsapp_number: string; // "0704409544" / "+234704409544"
  official_drop_phone?: string; // "0704409544"
  admin_avatar_url: string;
  admin_name: string;
  admin_email: string; // "support@megamarket.com"
  platform_location?: string;
  supabase_url?: string;
  supabase_anon_key?: string;
  paystack_public_key?: string;
}

export interface TeamMemberAccount {
  id: string;
  role: 'super_admin' | 'bookkeeper' | 'money_checker' | 'ad_manager';
  name: string;
  email: string;
  phone?: string;
  pin: string;
  avatar_url?: string;
  route: string;
  status: 'active' | 'suspended';
  last_active?: string;
  description: string;
}

export interface TeamJobApplication {
  id: string;
  applicant_name: string;
  email: string;
  whatsapp: string;
  desired_role: 'bookkeeper' | 'money_checker' | 'ad_manager' | 'customer_support' | 'sales_agent';
  experience_summary: string;
  remote_readiness: string;
  portfolio_url?: string;
  status: 'pending' | 'accepted' | 'rejected';
  submitted_at: string;
  assigned_pin?: string;
}

export interface VideoAdvertisement {
  id: string;
  title: string;
  description: string;
  video_url: string;
  poster_url?: string;
  creator_name: string;
  creator_id?: string;
  duration_days: number;
  status: 'active' | 'scheduled' | 'completed' | 'paused';
  target_url?: string;
  social_media_link?: string; // Client's Instagram, TikTok, Twitter, Facebook, or WhatsApp
  start_date: string;
  end_date: string;
  views_count: number;
  clicks_count: number;
  daily_auto_post: boolean;
  budget?: number;
  currency?: CurrencyCode;
  created_at: string;
}

export interface TickerNewsItem {
  id: string;
  title: string;
  content: string;
  category: 'announcement' | 'deals' | 'flash_update' | 'financial';
  is_active: boolean;
  created_at: string;
}

export interface AdminRevenueBankAccount {
  id: string;
  bank_name: string;
  account_number: string;
  account_name: string;
  is_primary: boolean;
  currency: CurrencyCode;
  notes?: string;
  gateway_api_link?: string; // Link of Paystack API or any payment gateway bank for future purposes
  gateway_provider?: 'paystack' | 'flutterwave' | 'moniepoint' | 'opay' | 'kuda' | 'interswitch' | 'custom';
  webhook_url?: string;
  added_at: string;
}

export interface AIWhatsappAlert {
  id: string;
  timestamp: string;
  category: 'HIGH_VALUE_ORDER' | 'DISPUTE_FLAG' | 'NEW_SELLER_APPLICATION' | 'SUSPICIOUS_ACTIVITY' | 'SETTLEMENT_REQUEST';
  message: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  sentToWhatsapp: boolean;
  referenceId?: string;
}

export interface PhoneDropAlert {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  recipientPhone: string;
  channel: 'SMS' | 'WHATSAPP' | 'PUSH';
  productTitle?: string;
  productPrice?: number;
  productSlug?: string;
  productImage?: string;
  locationTag?: string;
  delivered: boolean;
}
