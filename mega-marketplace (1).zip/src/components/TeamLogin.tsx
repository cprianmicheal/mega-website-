import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { 
  Shield, 
  BookOpen, 
  DollarSign, 
  Megaphone, 
  Lock, 
  Key, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle,
  HelpCircle,
  Sparkles
} from 'lucide-react';
import { TeamMemberAccount } from '../types';

export function TeamLogin() {
  const navigate = useNavigate();
  const { teamMembers, loginStaffWithPin, updateTeamMemberPin, addToast } = useStore();

  const [selectedMember, setSelectedMember] = useState<TeamMemberAccount | null>(null);
  const [pinInput, setPinInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isChangingPin, setIsChangingPin] = useState(false);
  const [newPinInput, setNewPinInput] = useState('');
  const [confirmPinInput, setConfirmPinInput] = useState('');

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'super_admin': return Shield;
      case 'bookkeeper': return BookOpen;
      case 'money_checker': return DollarSign;
      case 'ad_manager': return Megaphone;
      default: return Lock;
    }
  };

  const handleSelectMember = (member: TeamMemberAccount) => {
    setSelectedMember(member);
    setPinInput('');
    setErrorMsg('');
    setIsChangingPin(false);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember) return;

    if (!pinInput.trim()) {
      setErrorMsg('Please enter your 4-digit PIN code.');
      return;
    }

    const res = loginStaffWithPin(selectedMember.role, pinInput.trim());
    if (res.success) {
      // Navigate to their assigned dedicated URL
      navigate(selectedMember.route);
    } else {
      setErrorMsg(`Incorrect PIN. (Default demo PIN for ${selectedMember.name} is ${selectedMember.pin})`);
    }
  };

  const handleQuickKeypad = (digit: string) => {
    if (pinInput.length < 6) {
      setPinInput(prev => prev + digit);
    }
  };

  const handleSaveNewPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember) return;

    if (newPinInput.length < 4) {
      setErrorMsg('PIN must be at least 4 digits.');
      return;
    }

    if (newPinInput !== confirmPinInput) {
      setErrorMsg('PINs do not match.');
      return;
    }

    updateTeamMemberPin(selectedMember.id, newPinInput);
    addToast(`Security PIN for ${selectedMember.name} has been updated to ${newPinInput}`, 'success');
    setIsChangingPin(false);
    setPinInput(newPinInput);
    setErrorMsg('');
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6">
      {/* Title & Explainer */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center space-x-2 bg-blue-50 border border-blue-200 px-3 py-1 rounded-full text-blue-700 text-xs font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Mega Staff Multi-Role Gateway</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          Select Your Team Account
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-lg mx-auto">
          Choose your authorized role below and enter your assigned security PIN to access your dedicated dashboard.
        </p>
      </div>

      {/* 4 Team Accounts Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {teamMembers.map((member) => {
          const Icon = getRoleIcon(member.role);
          const isSelected = selectedMember?.id === member.id;

          return (
            <div
              key={member.id}
              onClick={() => handleSelectMember(member)}
              className={`p-5 rounded-3xl border text-left cursor-pointer transition-all duration-200 relative overflow-hidden group ${
                isSelected
                  ? 'border-blue-600 bg-blue-50/70 shadow-lg ring-2 ring-blue-500/30'
                  : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-md'
              }`}
            >
              <div className="flex items-start space-x-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 transition-all ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30'
                    : 'bg-slate-100 text-slate-700 group-hover:bg-slate-200'
                }`}>
                  <Icon className="w-6 h-6" />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-black text-slate-900 truncate">{member.name}</h3>
                    <span className="text-[10px] font-mono font-bold text-blue-600 bg-blue-100/70 px-2 py-0.5 rounded-full">
                      {member.route}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                    {member.description}
                  </p>

                  <div className="mt-3 flex items-center justify-between text-[11px] font-semibold text-slate-400">
                    <span className="flex items-center space-x-1">
                      <Key className="w-3 h-3 text-amber-500" />
                      <span>PIN Protected</span>
                    </span>
                    <span className="text-blue-600 font-bold group-hover:translate-x-0.5 transition-transform inline-flex items-center">
                      <span>Log In</span>
                      <ArrowRight className="w-3 h-3 ml-1" />
                    </span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Member PIN Entry Pad */}
      {selectedMember && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xl max-w-md mx-auto space-y-6 animate-in fade-in zoom-in-95 duration-200">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-md">
                {React.createElement(getRoleIcon(selectedMember.role), { className: 'w-5 h-5' })}
              </div>
              <div>
                <h4 className="text-sm font-black text-slate-900">{selectedMember.name}</h4>
                <span className="text-[11px] font-mono text-blue-600 font-bold">Route: {selectedMember.route}</span>
              </div>
            </div>
            <button
              onClick={() => setSelectedMember(null)}
              className="text-xs text-slate-400 hover:text-slate-700 font-bold"
            >
              Cancel
            </button>
          </div>

          {!isChangingPin ? (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-black text-slate-700 uppercase tracking-wider mb-2">
                  Enter 4-Digit Security PIN
                </label>
                <div className="relative">
                  <input
                    type="password"
                    maxLength={6}
                    value={pinInput}
                    onChange={(e) => {
                      setPinInput(e.target.value);
                      setErrorMsg('');
                    }}
                    placeholder="••••"
                    className="w-full text-center text-2xl tracking-[0.5em] font-mono py-3.5 px-4 rounded-2xl border-2 border-slate-200 focus:border-blue-600 focus:outline-none bg-slate-50 font-bold text-slate-900 shadow-inner"
                    autoFocus
                  />
                  <Lock className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                </div>
                
                <div className="flex items-center justify-between mt-2 text-[11px] text-slate-500">
                  <span>Default PIN: <strong className="font-mono text-blue-600">{selectedMember.pin}</strong></span>
                  <button
                    type="button"
                    onClick={() => {
                      setIsChangingPin(true);
                      setErrorMsg('');
                    }}
                    className="text-blue-600 hover:underline font-bold"
                  >
                    Change PIN
                  </button>
                </div>
              </div>

              {/* Quick On-Screen Number Keypad for instant convenience */}
              <div className="grid grid-cols-3 gap-2 pt-2">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => {
                      if (k === 'C') setPinInput('');
                      else if (k === '⌫') setPinInput(prev => prev.slice(0, -1));
                      else handleQuickKeypad(k);
                    }}
                    className="py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-black text-sm active:scale-95 transition-all"
                  >
                    {k}
                  </button>
                ))}
              </div>

              {errorMsg && (
                <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-3.5 rounded-2xl text-xs sm:text-sm shadow-lg shadow-blue-600/30 active:scale-95 transition-all flex items-center justify-center space-x-2"
              >
                <span>Access {selectedMember.name} Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <form onSubmit={handleSaveNewPin} className="space-y-4">
              <div className="space-y-3">
                <span className="text-xs font-black text-slate-900 block">Update PIN for {selectedMember.name}</span>
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">New 4-Digit PIN</label>
                  <input
                    type="password"
                    maxLength={6}
                    value={newPinInput}
                    onChange={(e) => setNewPinInput(e.target.value)}
                    placeholder="Enter new PIN"
                    className="w-full text-center text-lg font-mono py-2.5 px-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Confirm New PIN</label>
                  <input
                    type="password"
                    maxLength={6}
                    value={confirmPinInput}
                    onChange={(e) => setConfirmPinInput(e.target.value)}
                    placeholder="Re-enter new PIN"
                    className="w-full text-center text-lg font-mono py-2.5 px-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              {errorMsg && (
                <div className="p-2.5 rounded-xl bg-rose-50 text-rose-700 text-xs flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <div className="flex items-center space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsChangingPin(false)}
                  className="w-1/2 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20"
                >
                  Save New PIN
                </button>
              </div>
            </form>
          )}
        </div>
      )}
    </div>
  );
}
