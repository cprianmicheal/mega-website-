import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { CURRENCIES } from '../lib/utils';
import { 
  ShieldCheck, 
  Truck, 
  CreditCard, 
  PhoneCall, 
  Mail, 
  MapPin, 
  MessageSquare, 
  Globe, 
  ArrowRight, 
  Sparkles, 
  Lock, 
  CheckCircle2,
  Headphones,
  ExternalLink,
  Store as StoreIcon,
  Heart,
  Share2
} from 'lucide-react';

interface FooterProps {
  onOpenCurrencyModal?: () => void;
  onOpenAuthModal?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenCurrencyModal, onOpenAuthModal }) => {
  const { currency, addToast, user, platformSettings } = useStore();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const activeCurrencyConfig = CURRENCIES[currency] || CURRENCIES.NGN;
  const whatsappNumber = platformSettings.official_drop_phone || platformSettings.admin_whatsapp_number || '0704409544';
  const cleanIntl = whatsappNumber.replace(/^0/, '234').replace(/[^0-9]/g, '');
  const whatsappLink = `https://wa.me/${cleanIntl}?text=${encodeURIComponent('Hello Mega Support, I need assistance or want to drop an inquiry.')}`;

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes('@')) {
      addToast('Please enter a valid email address.', 'error');
      return;
    }
    setSubscribed(true);
    addToast('Subscribed! Promo voucher code MEGA10 has been sent to your email.', 'success', 'Voucher Unlocked');
    setNewsletterEmail('');
  };

  return (
    <footer id="mega-marketplace-massive-footer" className="bg-slate-950 text-slate-300 border-t border-slate-800 pt-16 pb-28 md:pb-16 mt-20 relative overflow-hidden">
      {/* Ambient background glows */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-16">
        
        {/* COMPACT WHATSAPP & HOTLINE STRIP */}
        <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 sm:p-5 shadow-lg max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3 text-left w-full sm:w-auto">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-green-600 to-emerald-500 text-white flex items-center justify-center shadow-md shadow-green-600/30 shrink-0">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="bg-green-500/20 text-green-400 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border border-green-500/30">
                  24/7 WhatsApp Hotline
                </span>
                <span className="text-slate-400 text-xs hidden sm:inline">• Direct Concierge</span>
              </div>
              <h3 className="text-sm sm:text-base font-bold text-white mt-0.5">
                Have questions or need instant support?
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end shrink-0">
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-initial bg-green-600 hover:bg-green-500 text-white font-black px-4 py-2.5 rounded-xl text-xs transition-all shadow-md shadow-green-600/30 active:scale-95 flex items-center justify-center space-x-2"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>WhatsApp: {whatsappNumber}</span>
              <ExternalLink className="w-3 h-3" />
            </a>

            <a
              href={`tel:+${cleanIntl}`}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-3.5 py-2.5 rounded-xl text-xs border border-slate-700 transition-all flex items-center justify-center space-x-1.5"
            >
              <PhoneCall className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">Call</span>
            </a>
          </div>
        </div>

        {/* OFFICIAL MEGA STORE SETTLEMENT ACCOUNT - DISPLAYED FOR EASY SETTLEMENT */}
        <div className="bg-gradient-to-r from-red-950/80 via-slate-900 to-red-950/70 border-2 border-red-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl max-w-5xl mx-auto backdrop-blur-md">
          <div className="flex flex-col md:flex-row items-center justify-between gap-5">
            <div className="flex items-start sm:items-center space-x-4 text-left">
              <div className="w-14 h-14 rounded-2xl bg-red-600 text-white flex items-center justify-center font-black text-xl shadow-lg shadow-red-600/40 shrink-0">
                UBA
              </div>
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="bg-red-500/20 text-red-400 text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full border border-red-500/40">
                    Official Mega Store Settlement Account
                  </span>
                  <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                    Instant Bank Settlement
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-black text-white">
                  United Bank for Africa (UBA) • <span className="text-red-400">2311406173</span>
                </h3>
                <p className="text-xs text-slate-300 font-medium">
                  Beneficiary Account Name: <strong className="text-amber-300 font-bold tracking-wide">CYPRIAN MICHAEL OJOCHOGWU</strong>
                </p>
                <p className="text-[11px] text-slate-400">
                  All seller listing fees, customer platform charges, and direct store purchases settle safely into this verified CBN-regulated account.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 w-full md:w-auto shrink-0 justify-end">
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText('2311406173');
                  addToast('UBA Account Number 2311406173 copied to clipboard!', 'success');
                }}
                className="flex-1 md:flex-initial bg-red-600 hover:bg-red-500 text-white font-black px-4 py-2.5 rounded-xl text-xs transition-all shadow-md shadow-red-600/30 active:scale-95 flex items-center justify-center space-x-1.5"
              >
                <span>Copy: 2311406173</span>
              </button>
              <a
                href={`https://wa.me/234704409544?text=${encodeURIComponent('Hello Cyprian Michael Ojochogwu, I have made a direct settlement/payment into UBA 2311406173.')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 md:flex-initial bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold px-3.5 py-2.5 rounded-xl text-xs flex items-center justify-center space-x-1.5"
              >
                <MessageSquare className="w-3.5 h-3.5 text-green-400" />
                <span>Confirm Payment</span>
              </a>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 py-6 border-y border-slate-800/80">
          <div className="flex items-start space-x-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-white">100% Escrow Protection</h4>
              <p className="text-xs text-slate-400 mt-0.5">Funds are released only when you inspect & verify goods.</p>
            </div>
          </div>

          <div className="flex items-start space-x-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/30">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-white">Doorstep Tracking</h4>
              <p className="text-xs text-slate-400 mt-0.5">Real-time live GPS express dispatch with tamper seal verification.</p>
            </div>
          </div>

          <div className="flex items-start space-x-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/30">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-white">Direct Seller Payouts</h4>
              <p className="text-xs text-slate-400 mt-0.5">Automated bank settlement with fair transparent platform fees.</p>
            </div>
          </div>

          <div className="flex items-start space-x-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/30">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-white">24/7 Human Resolution</h4>
              <p className="text-xs text-slate-400 mt-0.5">Dedicated dispute arbitration & rapid customer assistance.</p>
            </div>
          </div>
        </div>

        {/* MASSIVE NAVIGATION & LINK MATRIX */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 text-xs">
          {/* Col 1: Brand & Bio */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="flex items-center space-x-2.5 group inline-flex">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-700 to-blue-500 flex items-center justify-center text-white font-black text-xl shadow-md shadow-blue-500/30">
                M
              </div>
              <div className="flex flex-col">
                <span className="font-extrabold text-2xl tracking-tighter text-white leading-none">
                  MEGA<span className="text-blue-500">.</span>
                </span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-blue-400">Marketplace</span>
              </div>
            </Link>

            <p className="text-slate-400 leading-relaxed max-w-sm">
              Nigeria & Africa's premium multi-vendor commerce network. Connecting discerning buyers with authenticated brands, certified technicians, and verified merchants with ironclad escrow security.
            </p>

            {/* Newsletter Subscription Box */}
            <div className="pt-2">
              <span className="font-bold text-white block mb-1.5">Join Mega VIP Circle (Get 10% Off)</span>
              <form onSubmit={handleSubscribe} className="flex max-w-sm">
                <input
                  type="email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="Enter your email address..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-l-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2.5 rounded-r-xl transition-colors shrink-0"
                >
                  Join
                </button>
              </form>
            </div>

            {/* Global Currency Trigger */}
            <div className="pt-2 flex items-center space-x-3">
              <span className="text-slate-500">Active Currency:</span>
              <button
                onClick={onOpenCurrencyModal}
                className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-white px-3 py-1.5 rounded-xl flex items-center space-x-2 transition-all"
              >
                <span>{activeCurrencyConfig.flag}</span>
                <span className="font-bold">{activeCurrencyConfig.code} ({activeCurrencyConfig.symbol})</span>
                <Globe className="w-3.5 h-3.5 text-blue-400 ml-1" />
              </button>
            </div>
          </div>

          {/* Col 2: Marketplace Departments */}
          <div className="space-y-3">
            <h5 className="font-black text-white uppercase tracking-wider text-[11px] text-blue-400">
              Shopping Departments
            </h5>
            <ul className="space-y-2">
              <li>
                <Link to="/explore?q=Electronics" className="text-slate-400 hover:text-white transition-colors">
                  Phones, Tablets & Gadgets
                </Link>
              </li>
              <li>
                <Link to="/explore?q=MacBook" className="text-slate-400 hover:text-white transition-colors">
                  Laptops & Workstations
                </Link>
              </li>
              <li>
                <Link to="/explore?q=Fashion" className="text-slate-400 hover:text-white transition-colors">
                  Designer Fashion & Shoes
                </Link>
              </li>
              <li>
                <Link to="/explore?q=Home" className="text-slate-400 hover:text-white transition-colors">
                  Home Decor & Solar Inverters
                </Link>
              </li>
              <li>
                <Link to="/explore" className="text-slate-400 hover:text-white transition-colors">
                  Professional Services
                </Link>
              </li>
              <li>
                <Link to="/explore" className="text-slate-400 hover:text-white transition-colors">
                  Verified Brand Stores
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: For Sellers & Merchants */}
          <div className="space-y-3">
            <h5 className="font-black text-white uppercase tracking-wider text-[11px] text-blue-400">
              Merchant & Vendor Hub
            </h5>
            <ul className="space-y-2">
              <li>
                <Link to="/sell" className="text-slate-400 hover:text-white transition-colors font-semibold text-blue-300">
                  Open a Seller Store
                </Link>
              </li>
              <li>
                <Link to="/sell" className="text-slate-400 hover:text-white transition-colors">
                  List Products & Inventory
                </Link>
              </li>
              <li>
                <Link to="/sell" className="text-slate-400 hover:text-white transition-colors">
                  Offer Professional Services
                </Link>
              </li>
              <li>
                <Link to="/sell" className="text-slate-400 hover:text-white transition-colors">
                  Direct Bank Payouts Setup
                </Link>
              </li>
              <li>
                <Link to="/account" className="text-slate-400 hover:text-white transition-colors">
                  Seller Ledger & Withdrawals
                </Link>
              </li>
              <li>
                <Link to="/account" className="text-slate-400 hover:text-white transition-colors">
                  Affiliate Rewards & Cashout
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 4: Trust, Safety & Emergency Contacts */}
          <div className="space-y-3">
            <h5 className="font-black text-white uppercase tracking-wider text-[11px] text-blue-400">
              Direct Contact & Trust
            </h5>
            <ul className="space-y-2.5">
              <li className="flex items-center space-x-2 text-slate-300">
                <MessageSquare className="w-3.5 h-3.5 text-green-400 shrink-0" />
                <span>WhatsApp: <strong className="text-white">{whatsappNumber}</strong></span>
              </li>
              <li className="flex items-center space-x-2 text-slate-300">
                <PhoneCall className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span>Hotline: <strong className="text-white">+234 704 409 5544</strong></span>
              </li>
              <li className="flex items-center space-x-2 text-slate-300">
                <Mail className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Email: <strong className="text-white">support@megamarket.com</strong></span>
              </li>
              <li className="flex items-start space-x-2 text-slate-400">
                <MapPin className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                <span>No. 14 Otukpo-Enugu Commercial Road, Ankpa, Kogi State, Nigeria</span>
              </li>
              <li className="pt-1">
                <Link to="/apply" className="text-emerald-400 hover:underline flex items-center space-x-1 font-bold">
                  <span>💼 Work With Us (7 Remote Team Slots)</span>
                </Link>
              </li>
              <li>
                <Link to="/account" className="text-blue-400 hover:underline flex items-center space-x-1">
                  <Share2 className="w-3 h-3 mr-1" />
                  <span>Refer Friends & Earn ₦1,000</span>
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* BANK & FINTECH LOGOS SECTION */}
        <div className="pt-10 border-t border-slate-900 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-blue-400">
                Supported Direct Bank Payouts & Settlement Partners
              </span>
              <p className="text-xs text-slate-400">
                Instant 2-5 min direct settlement to all verified commercial and digital microfinance banks in Nigeria
              </p>
            </div>
            <span className="text-[10px] text-green-400 font-bold bg-green-950/60 border border-green-800/60 px-2.5 py-1 rounded-full w-fit">
              CBN NUBAN 256-Bit Escrow Encrypted
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 pt-2">
            {/* GTBank */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-orange-500/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-[#E65100] text-white flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                GT
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-orange-400 transition-colors">GTBank</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">Guaranty Trust</span>
              </div>
            </div>

            {/* Zenith Bank */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-red-500/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-[#D32F2F] text-white flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                Z
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-red-400 transition-colors">Zenith Bank</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">Direct NUBAN</span>
              </div>
            </div>

            {/* Access Bank */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-amber-500/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-600 to-orange-500 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                ◈
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-amber-400 transition-colors">Access Bank</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">Access Closa</span>
              </div>
            </div>

            {/* UBA */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-red-600/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-[#B71C1C] text-white flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                UBA
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-red-400 transition-colors">UBA Africa</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">United Bank</span>
              </div>
            </div>

            {/* First Bank */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-blue-400/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-[#0D233A] border border-amber-400/30 text-amber-300 flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                FBN
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-blue-300 transition-colors">FirstBank</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">FirstMonie Direct</span>
              </div>
            </div>

            {/* Kuda */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-purple-500/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-[#40196D] text-white flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                K.
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-purple-400 transition-colors">Kuda Bank</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">Microfinance MFB</span>
              </div>
            </div>

            {/* Moniepoint */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-blue-500/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-[#003366] text-blue-300 flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                MP
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-blue-400 transition-colors">Moniepoint</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">Merchant MFB</span>
              </div>
            </div>

            {/* OPay */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-green-500/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-[#00B970] text-slate-950 flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                OP
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-green-400 transition-colors">OPay Digital</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">Instant Settlement</span>
              </div>
            </div>

            {/* PalmPay */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-purple-400/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-700 to-indigo-600 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                PP
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-purple-300 transition-colors">PalmPay</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">Smart Payouts</span>
              </div>
            </div>

            {/* Interswitch */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-red-400/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-red-600 via-blue-700 to-indigo-800 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                IS
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-indigo-300 transition-colors">Interswitch</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">National Switch</span>
              </div>
            </div>

            {/* Paystack */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-cyan-400/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-[#00C3F7]/20 border border-[#00C3F7]/40 text-[#00C3F7] flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                ≡
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-cyan-300 transition-colors">Paystack</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">Stripe Company</span>
              </div>
            </div>

            {/* Flutterwave */}
            <div className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-amber-400/50 p-3 rounded-2xl flex items-center space-x-2.5 transition-all group">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-sm">
                FLW
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-white group-hover:text-amber-300 transition-colors">Flutterwave</span>
                <span className="text-[9px] text-slate-400 uppercase tracking-tighter">Global Gateway</span>
              </div>
            </div>
          </div>
        </div>

        {/* BOTTOM BADGES & COPYRIGHT */}
        <div className="pt-8 border-t border-slate-900 flex flex-col md:flex-row items-center justify-between gap-6 text-[11px] text-slate-500">
          <div className="flex flex-wrap items-center gap-4">
            <span className="font-semibold text-slate-400">© 2026 Mega Marketplace Nigeria Ltd. All Rights Reserved.</span>
            <span>•</span>
            <span className="text-slate-400">Founder & Super Admin: Cyprian O.</span>
            <span>•</span>
            <span className="inline-flex items-center text-green-400">
              <span className="w-2 h-2 rounded-full bg-green-500 mr-1.5 animate-pulse" />
              All Systems Operational
            </span>
          </div>

          {/* Payment & Security Logos / Tags */}
          <div className="flex items-center space-x-2 text-slate-400 font-mono text-[10px]">
            <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800">Paystack 256-Bit</span>
            <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800">Direct Bank Transfer</span>
            <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800">Mastercard</span>
            <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800">Visa / Verve</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
