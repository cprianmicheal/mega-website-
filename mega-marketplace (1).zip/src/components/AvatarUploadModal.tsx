import { UserAvatar } from './UserAvatar';
import React, { useState } from 'react';
import { useStore } from '../store';
import { ImageDropzone } from './ImageDropzone';
import { NEUTRAL_AVATAR_PRESETS } from '../services/mockData';
import { X, Sparkles, Check, Camera, User, RefreshCw, ShieldCheck } from 'lucide-react';

interface AvatarUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUserRole?: 'user' | 'admin';
}

export function AvatarUploadModal({ isOpen, onClose, targetUserRole = 'user' }: AvatarUploadModalProps) {
  const { user, updateUserProfile, platformSettings, updatePlatformSettings, addToast } = useStore();

  const currentAvatar = targetUserRole === 'admin' 
    ? (platformSettings.admin_avatar_url || user.avatar_url || '')
    : (user.avatar_url || '');

  const [selectedAvatar, setSelectedAvatar] = useState<string>(currentAvatar);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAvatar) {
      addToast('Please select or upload an avatar image', 'warning');
      return;
    }

    if (targetUserRole === 'admin') {
      updatePlatformSettings({ admin_avatar_url: selectedAvatar });
      updateUserProfile({ avatar_url: selectedAvatar });
      addToast('Admin profile image updated successfully!', 'success', 'Admin Updated');
    } else {
      updateUserProfile({ avatar_url: selectedAvatar });
      addToast('Your profile picture has been updated!', 'success', 'Profile Updated');
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-100 relative max-h-[90vh] overflow-y-auto space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg text-slate-900 leading-tight">
                {targetUserRole === 'admin' ? 'Update Super Admin Photo' : 'Update Profile Photo'}
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Drag and drop any picture from your device or pick a neutral avatar
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 hover:text-slate-900 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Active Preview & Dropzone */}
        <div className="flex flex-col sm:flex-row items-center gap-5 p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
          <div className="relative shrink-0">
            <UserAvatar
              src={selectedAvatar}
              alt="Avatar Preview"
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl border-2 border-blue-600 shadow-md shadow-blue-500/10"
            />
            <div className="absolute -bottom-1.5 -right-1.5 bg-blue-600 text-white p-1 rounded-full text-xs shadow-xs">
              <Check className="w-3.5 h-3.5" />
            </div>
          </div>

          <div className="flex-1 w-full space-y-1 text-center sm:text-left">
            <span className="text-xs font-bold text-slate-900 block">
              {targetUserRole === 'admin' ? platformSettings.admin_name : user.full_name}
            </span>
            <span className="text-[11px] font-medium text-slate-500 block">
              Location: Ankpa, Kogi State, Nigeria
            </span>
            <span className="inline-flex items-center text-[10px] font-bold text-blue-700 bg-blue-100/80 px-2 py-0.5 rounded-full mt-1">
              <Sparkles className="w-3 h-3 mr-1" />
              Instant Drag & Drop Enabled
            </span>
          </div>
        </div>

        {/* Drag & Drop File Upload Area */}
        <div className="space-y-2">
          <ImageDropzone
            value={selectedAvatar}
            onChange={(url) => setSelectedAvatar(url)}
            label="Upload Custom Photo (Drag & Drop or Click)"
            aspectRatio="banner"
            placeholderText="Drop any image here from your computer or phone"
            helperText="Drag PNG, JPG, or WEBP file here or click to open file picker"
          />
        </div>

        {/* Natural / Neutral Preset Avatars */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Or Choose a Neutral Natural Avatar
            </span>
            <span className="text-[10px] font-medium text-slate-400">1-Click Selection</span>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
            {NEUTRAL_AVATAR_PRESETS.map((preset) => {
              const isSelected = selectedAvatar === preset.url;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => setSelectedAvatar(preset.url)}
                  className={`group flex flex-col items-center p-1.5 rounded-2xl border-2 transition-all text-center relative ${
                    isSelected 
                      ? 'border-blue-600 bg-blue-50/70 shadow-sm' 
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <img
                    src={preset.url}
                    alt={preset.name}
                    className="w-12 h-12 rounded-xl object-cover mb-1 group-hover:scale-105 transition-transform"
                  />
                  <span className="text-[10px] font-medium text-slate-600 line-clamp-1">
                    {preset.name.split(' ')[0]}
                  </span>
                  {isSelected && (
                    <div className="absolute top-1 right-1 bg-blue-600 text-white rounded-full p-0.5">
                      <Check className="w-2.5 h-2.5" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all flex items-center space-x-1.5"
          >
            <Check className="w-4 h-4" />
            <span>Save & Apply Photo</span>
          </button>
        </div>
      </div>
    </div>
  );
}
