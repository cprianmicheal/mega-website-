import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import { formatCurrency } from '../lib/utils';
import { Store, Star, Heart, ShoppingBag, ShieldCheck } from 'lucide-react';
import { useStore } from '../store';

export interface ProductCardProps {
  product: Product;
  showQuickAdd?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, showQuickAdd = true }) => {
  const { wishlist, toggleWishlist, addToCart, currency } = useStore();
  const isBookmarked = wishlist.some(item => item.id === product.id);

  const discountPercent = product.discount_price 
    ? Math.round(((product.price - product.discount_price) / product.price) * 100)
    : null;

  const handleWishlistClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product);
  };

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
  };

  return (
    <div className="group flex flex-col bg-white rounded-2xl overflow-hidden hover:shadow-[0_12px_36px_rgba(37,99,235,0.08)] transition-all duration-300 border border-slate-100 hover:border-blue-300 relative">
      {/* Boosted / Featured Upper Badge */}
      {product.is_boosted && (
        <div className="absolute top-3 left-3 z-10 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-[9px] font-black px-2 py-0.5 rounded-full tracking-wider uppercase shadow-md flex items-center space-x-1">
          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
          <span>TOP FEATURED</span>
        </div>
      )}

      {/* Discount Badge */}
      {!product.is_boosted && discountPercent && (
        <div className="absolute top-3 left-3 z-10 bg-blue-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full tracking-wider uppercase shadow-sm">
          -{discountPercent}% OFF
        </div>
      )}

      {/* Wishlist Bookmark Button */}
      <button
        id={`wishlist-btn-${product.id}`}
        onClick={handleWishlistClick}
        title={isBookmarked ? "Remove from wishlist" : "Add to wishlist"}
        aria-label="Wishlist"
        className={`absolute top-3 right-3 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 ${
          isBookmarked
            ? 'bg-rose-50 text-rose-600 shadow-sm border border-rose-200 scale-105'
            : 'bg-white/90 backdrop-blur-sm text-slate-400 hover:text-rose-500 hover:bg-white shadow-sm'
        }`}
      >
        <Heart className={`w-4 h-4 transition-transform active:scale-125 ${isBookmarked ? 'fill-rose-600' : ''}`} />
      </button>

      {/* Product Image */}
      <Link to={`/product/${product.slug}`} className="aspect-[4/5] overflow-hidden bg-slate-50 relative block">
        <img 
          src={product.images[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=600'} 
          alt={product.title}
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=600';
          }}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          loading="lazy"
        />
        {product.stock <= 5 && product.stock > 0 && (
          <span className="absolute bottom-2 left-2 bg-amber-500/90 text-white text-[9px] font-bold px-2 py-0.5 rounded-md backdrop-blur-xs">
            Only {product.stock} left
          </span>
        )}
      </Link>
      
      {/* Card Body */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1">
        {/* Store & Category */}
        <div className="flex items-center justify-between mb-1.5 text-[11px] text-slate-500">
          <div className="flex items-center space-x-1 truncate max-w-[70%]">
            <Store className="w-3 h-3 text-blue-600 shrink-0" />
            <span className="truncate font-medium text-slate-600">{product.store?.name || 'Mega Verified Seller'}</span>
            {product.store?.is_verified && (
              <ShieldCheck className="w-3 h-3 text-blue-600 shrink-0" />
            )}
          </div>
          {product.category && (
            <span className="text-[10px] px-1.5 py-0.5 bg-blue-50 text-blue-700 font-semibold rounded">
              {product.category}
            </span>
          )}
        </div>
        
        {/* Title */}
        <Link to={`/product/${product.slug}`} className="block mb-2">
          <h3 className="font-bold text-xs sm:text-sm line-clamp-2 leading-snug text-slate-900 group-hover:text-blue-600 transition-colors">
            {product.title}
          </h3>
        </Link>
        
        {/* Rating */}
        <div className="flex items-center space-x-1 text-xs text-amber-500 mb-3">
          <Star className="w-3.5 h-3.5 fill-current" />
          <span className="text-slate-800 font-semibold text-[11px] ml-0.5">{product.rating || '4.8'}</span>
          <span className="text-slate-400 text-[10px]">({product.reviews_count || '84'})</span>
        </div>
        
        {/* Price & Action */}
        <div className="mt-auto flex items-center justify-between pt-2 border-t border-slate-100">
          <div className="flex flex-col">
            {product.discount_price ? (
              <>
                <span className="font-black text-sm sm:text-base text-slate-900 leading-tight">
                  {formatCurrency(product.discount_price, currency)}
                </span>
                <span className="text-[11px] text-slate-400 line-through">
                  {formatCurrency(product.price, currency)}
                </span>
              </>
            ) : (
              <span className="font-black text-sm sm:text-base text-slate-900 leading-tight">
                {formatCurrency(product.price, currency)}
              </span>
            )}
          </div>

          {showQuickAdd && (
            <button
              id={`quick-add-${product.id}`}
              onClick={handleQuickAdd}
              title="Add to cart"
              className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white flex items-center justify-center transition-all duration-200 active:scale-95 shadow-xs"
            >
              <ShoppingBag className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
