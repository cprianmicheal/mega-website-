import React, { useState } from 'react';
import { ImageDropzone } from './ImageDropzone';
import { useStore } from '../store';
import { 
  User, 
  Mail, 
  Phone, 
  Lock, 
  Store, 
  ArrowRight, 
  ShieldCheck, 
  KeyRound, 
  X, 
  CheckCircle2, 
  AlertCircle,
  Building,
  Sparkles,
  Shield,
  Eye,
  EyeOff,
  Check,
  Zap,
  Globe
} from 'lucide-react';
import { 
  evaluatePasswordSecurity, 
  isValidEmail, 
  isValidPhone, 
  checkRateLimitStatus, 
  recordFailedAuthAttempt, 
  clearAuthAttempts 
} from '../lib/security';
import { supabase } from '../lib/supabase';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'signup' | 'recover';
  initialRole?: 'customer' | 'seller';
}

export const AuthModal: React.FC<AuthModalProps> = ({ 
  isOpen, 
  onClose, 
  initialMode = 'login',
  initialRole = 'customer'
}) => {
  const { loginUser, signupUser, sendOtpCode, verifyOtpAndReset, addToast, platformSettings } = useStore();

  const [mode, setMode] = useState<'login' | 'signup' | 'recover'>(initialMode);
  const [role, setRole] = useState<'customer' | 'seller'>(initialRole);

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // Signup form state
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [signupBusinessName, setSignupBusinessName] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [signupAvatar, setSignupAvatar] = useState('');

  // OTP recovery form state
  const [recoverTarget, setRecoverTarget] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [otpGeneratedDemo, setOtpGeneratedDemo] = useState<string | null>(null);

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const defaultDropPhone = platformSettings?.official_drop_phone || platformSettings?.admin_whatsapp_number || '0704409544';

  if (!isOpen) return null;

  // Real-time password evaluation
  const passwordSecurity = evaluatePasswordSecurity(signupPassword);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Rate-limiting brute force check
    const rateStatus = checkRateLimitStatus(loginIdentifier);
    if (rateStatus.isLocked) {
      setErrorMsg(`Security Lockout: Too many failed login attempts. Please wait ${rateStatus.remainingSeconds}s for protection.`);
      return;
    }

    if (!loginIdentifier.trim()) {
      setErrorMsg('Please enter your email address or phone number.');
      return;
    }

    if (!loginPassword.trim()) {
      setErrorMsg('Please enter your account password.');
      return;
    }

    const res = loginUser(loginIdentifier, role);
    if (res.success) {
      clearAuthAttempts(loginIdentifier);
      addToast(`Welcome back, ${res.user?.full_name || 'Member'}!`, 'success', 'Signed In Securely');
      onClose();
    } else {
      const attempt = recordFailedAuthAttempt(loginIdentifier);
      if (attempt.isLocked) {
        setErrorMsg('Security Alert: 5 consecutive invalid attempts detected. Account temporarily locked for 45s for protection.');
      } else {
        setErrorMsg(res.message);
      }
    }
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // 1. Legal Name check
    if (!signupName.trim() || signupName.trim().length < 2) {
      setErrorMsg('Please provide your full legal name.');
      return;
    }

    // 2. Strict Email Validation
    if (!isValidEmail(signupEmail)) {
      setErrorMsg('Please enter a valid email address (e.g., name@domain.com).');
      return;
    }

    // 3. Strict Phone Number Validation
    if (!isValidPhone(signupPhone)) {
      setErrorMsg('Please enter a valid phone number (10 to 14 digits).');
      return;
    }

    // 4. Strict Password Security Evaluation
    if (passwordSecurity.level === 'weak') {
      setErrorMsg(`Password is too weak. ${passwordSecurity.feedback[0] || 'Must be at least 8 characters with numbers and special symbols'}.`);
      return;
    }

    // 5. Create Protected Account
    const res = signupUser({
      full_name: signupName.trim(),
      email: signupEmail.trim(),
      phone: signupPhone.trim(),
      role: role,
      business_name: role === 'seller' ? signupBusinessName.trim() : undefined,
      avatar_url: signupAvatar || undefined
    });

    if (res.success) {
      clearAuthAttempts(signupEmail);
      addToast('Account created with bank-grade security! 3 times free trial post bonus unlocked!', 'success', 'Bonus Claimed 🎁');
      onClose();
    } else {
      setErrorMsg(res.message);
    }
  };

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!recoverTarget) {
      setErrorMsg('Please enter your registered email or phone number.');
      return;
    }

    const res = sendOtpCode(recoverTarget);
    if (res.success) {
      setOtpSent(true);
      setOtpGeneratedDemo(res.code);
      setSuccessMsg(`Verification code sent to ${recoverTarget}`);
    }
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const res = verifyOtpAndReset(recoverTarget, otpCode);
    if (res.success) {
      setSuccessMsg('Account recovered successfully! You can now log in.');
      setTimeout(() => {
        setMode('login');
        setOtpSent(false);
        setOtpCode('');
        setSuccessMsg(null);
      }, 1500);
    } else {
      setErrorMsg(res.message);
    }
  };

  return (
    <div 
      id="auth-modal-backdrop" 
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in"
    >
      <div 
        id="auth-modal-card" 
        className="bg-white w-full max-w-md rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95 my-auto max-h-[92vh] overflow-y-auto"
      >
        {/* Header with Close */}
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
          <div className="flex items-center space-x-2">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black text-lg shadow-md shadow-blue-600/30">
              M
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="font-extrabold text-lg text-slate-900 tracking-tight">
                  MEGA<span className="text-blue-600">.</span>
                </span>
                <span className="px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[9px] font-black uppercase flex items-center">
                  <ShieldCheck className="w-2.5 h-2.5 mr-0.5" /> 256-Bit
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-semibold">High-Security Marketplace Access</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 hover:bg-slate-200 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher (Sign In vs Create Account vs OTP Recovery) */}
        <div className="flex bg-slate-100 p-1 rounded-2xl mb-5 text-xs font-bold">
          <button
            onClick={() => { setMode('login'); setErrorMsg(null); }}
            className={`flex-1 py-2.5 rounded-xl transition-all ${
              mode === 'login' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Sign In
          </button>
          <button
            onClick={() => { setMode('signup'); setErrorMsg(null); }}
            className={`flex-1 py-2.5 rounded-xl transition-all relative ${
              mode === 'signup' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Create Account
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-amber-500 rounded-full animate-ping" />
          </button>
          <button
            onClick={() => { setMode('recover'); setErrorMsg(null); }}
            className={`flex-1 py-2.5 rounded-xl transition-all ${
              mode === 'recover' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Recover (OTP)
          </button>
        </div>

        {/* BANK-GRADE 256-BIT ENCRYPTED ACCOUNT PORTAL */}
        <div className="mb-4 bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white p-3.5 rounded-2xl border border-blue-500/30 flex items-center justify-between shadow-xs">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600/30 border border-blue-400/40 flex items-center justify-center text-blue-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-xs font-black text-white">Bank-Grade Encrypted Portal</span>
                <span className="text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded font-mono font-bold">256-BIT SSL</span>
              </div>
              <p className="text-[10px] text-slate-300">Direct secured credentials • Anti-tamper protection • Escrow safe</p>
            </div>
          </div>
          <Lock className="w-4 h-4 text-blue-300 shrink-0 opacity-70 hidden sm:block" />
        </div>

        {/* Error / Success Feedback */}
        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="mb-4 p-3 rounded-xl bg-green-50 border border-green-200 text-green-700 text-xs font-semibold flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* MODE: SIGN IN */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">Email or Phone Number</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  placeholder={`e.g. cyprian@megamarket.ng or ${defaultDropPhone}`}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="font-bold text-slate-700">Account Password</label>
                <button
                  type="button"
                  onClick={() => setMode('recover')}
                  className="text-blue-600 font-bold hover:underline text-[11px]"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showLoginPassword ? "text" : "password"}
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-10 py-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowLoginPassword(!showLoginPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Quick Demo Pre-fills */}
            <div className="pt-1">
              <span className="text-[11px] text-slate-400 block mb-1 font-medium">Quick Demo Profiles:</span>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setLoginIdentifier('cyprian@megamarket.ng');
                    setRole('seller');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold"
                >
                  Admin / Seller: Cyprian O.
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLoginIdentifier('emeka.nwankwo@gmail.com');
                    setRole('customer');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold"
                >
                  Customer: Emeka N.
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl shadow-md shadow-blue-600/20 active:scale-95 transition-all text-xs flex items-center justify-center space-x-2 mt-2"
            >
              <span>Sign In to Mega Marketplace</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* MODE: CREATE ACCOUNT (CUSTOMER OR BUSINESS/SELLER) */}
        {mode === 'signup' && (
          <form onSubmit={handleSignup} className="space-y-3.5 text-xs">
            {/* Role Switcher */}
            <div>
              <label className="font-bold text-slate-700 block mb-1">Account Purpose</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setRole('customer')}
                  className={`p-3 rounded-xl border text-left flex items-center space-x-2.5 transition-all ${
                    role === 'customer'
                      ? 'border-blue-600 bg-blue-50/70 text-blue-900 font-bold'
                      : 'border-slate-200 text-slate-600 font-medium'
                  }`}
                >
                  <User className="w-4 h-4 text-blue-600 shrink-0" />
                  <div>
                    <span className="block text-xs font-bold">Buyer / Customer</span>
                    <span className="text-[10px] opacity-75">Shop verified goods</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setRole('seller')}
                  className={`p-3 rounded-xl border text-left flex items-center space-x-2.5 transition-all ${
                    role === 'seller'
                      ? 'border-blue-600 bg-blue-50/70 text-blue-900 font-bold'
                      : 'border-slate-200 text-slate-600 font-medium'
                  }`}
                >
                  <Store className="w-4 h-4 text-blue-600 shrink-0" />
                  <div>
                    <span className="block text-xs font-bold">Business / Seller</span>
                    <span className="text-[10px] opacity-75">Sell & receive payouts</span>
                  </div>
                </button>
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Full Legal Name *</label>
              <input
                type="text"
                required
                value={signupName}
                onChange={(e) => setSignupName(e.target.value)}
                placeholder="e.g. Cyprian Nwosu"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>

            {role === 'seller' && (
              <div>
                <label className="font-bold text-slate-700 block mb-1">Registered Business / Brand Name</label>
                <div className="relative">
                  <Building className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={signupBusinessName}
                    onChange={(e) => setSignupBusinessName(e.target.value)}
                    placeholder="e.g. Apex Gadgets Ltd"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>
            )}
            {/* Profile Avatar / Logo Drag & Drop */}
            <div>
              <label className="font-bold text-slate-700 block mb-1">Profile / Logo Photo (Drag & Drop)</label>
              <ImageDropzone
                value={signupAvatar}
                onChange={(url) => setSignupAvatar(url)}
                label="Drag & drop your profile photo or logo here"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Email Address *</label>
                <input
                  type="email"
                  required
                  value={signupEmail}
                  onChange={(e) => setSignupEmail(e.target.value)}
                  placeholder="name@email.com"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">Phone Number *</label>
                <input
                  type="tel"
                  required
                  value={signupPhone}
                  onChange={(e) => setSignupPhone(e.target.value)}
                  placeholder={defaultDropPhone}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>
            </div>

            {/* PASSWORD WITH STRONG SECURITY VALIDATION */}
            <div>
              <label className="font-bold text-slate-700 block mb-1">Set Account Password *</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showSignupPassword ? "text" : "password"}
                  required
                  value={signupPassword}
                  onChange={(e) => setSignupPassword(e.target.value)}
                  placeholder="Min 8 chars with uppercase, number & symbol"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-10 py-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowSignupPassword(!showSignupPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showSignupPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* LIVE PASSWORD STRENGTH METER */}
              {signupPassword.length > 0 && (
                <div className="mt-2 p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2 animate-in fade-in">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-slate-600">Password Security:</span>
                    <span className={`font-black ${
                      passwordSecurity.level === 'strong' ? 'text-emerald-600' :
                      passwordSecurity.level === 'good' ? 'text-blue-600' :
                      passwordSecurity.level === 'fair' ? 'text-amber-600' : 'text-rose-600'
                    }`}>
                      {passwordSecurity.label} ({passwordSecurity.score}%)
                    </span>
                  </div>

                  {/* Colored Progress Bar */}
                  <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-300 rounded-full ${
                        passwordSecurity.level === 'strong' ? 'bg-emerald-500' :
                        passwordSecurity.level === 'good' ? 'bg-blue-600' :
                        passwordSecurity.level === 'fair' ? 'bg-amber-500' : 'bg-rose-500'
                      }`}
                      style={{ width: `${passwordSecurity.score}%` }}
                    />
                  </div>

                  {/* Requirements Pills */}
                  <div className="grid grid-cols-2 gap-1 text-[10px] text-slate-600 pt-1">
                    <div className={`flex items-center space-x-1 ${passwordSecurity.checks.minLength ? 'text-emerald-600 font-bold' : 'text-slate-400'}`}>
                      {passwordSecurity.checks.minLength ? <Check className="w-3 h-3 text-emerald-600" /> : <span className="w-3 h-3 text-center">•</span>}
                      <span>8+ Characters</span>
                    </div>
                    <div className={`flex items-center space-x-1 ${passwordSecurity.checks.hasUppercase ? 'text-emerald-600 font-bold' : 'text-slate-400'}`}>
                      {passwordSecurity.checks.hasUppercase ? <Check className="w-3 h-3 text-emerald-600" /> : <span className="w-3 h-3 text-center">•</span>}
                      <span>Uppercase (A-Z)</span>
                    </div>
                    <div className={`flex items-center space-x-1 ${passwordSecurity.checks.hasNumber ? 'text-emerald-600 font-bold' : 'text-slate-400'}`}>
                      {passwordSecurity.checks.hasNumber ? <Check className="w-3 h-3 text-emerald-600" /> : <span className="w-3 h-3 text-center">•</span>}
                      <span>Number (0-9)</span>
                    </div>
                    <div className={`flex items-center space-x-1 ${passwordSecurity.checks.hasSpecial ? 'text-emerald-600 font-bold' : 'text-slate-400'}`}>
                      {passwordSecurity.checks.hasSpecial ? <Check className="w-3 h-3 text-emerald-600" /> : <span className="w-3 h-3 text-center">•</span>}
                      <span>Special Symbol (!@#)</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* BONUS BADGE */}
            <div className="bg-amber-50 border border-amber-200/80 rounded-xl p-2.5 flex items-center space-x-2 text-amber-900 text-[11px] font-bold">
              <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Special Bonus: 3 Times Free Trial Post Bonus included with new registration!</span>
            </div>

            {/* EXACT REQUESTED BUTTON COPY */}
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black py-3.5 px-4 rounded-xl shadow-lg shadow-blue-600/25 active:scale-[0.98] transition-all text-xs flex items-center justify-center space-x-2 mt-2"
            >
              <Zap className="w-4 h-4 text-amber-300 shrink-0" />
              <span className="text-center leading-tight">Create Account and get 3 times free trial post bonus</span>
            </button>
          </form>
        )}

        {/* MODE: RECOVER ACCOUNT VIA OTP */}
        {mode === 'recover' && (
          <div className="space-y-4 text-xs">
            <div className="text-center pb-2">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-2">
                <KeyRound className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">Account Recovery & OTP</h4>
              <p className="text-slate-500 text-[11px]">
                We'll dispatch a 6-digit security OTP directly to your email or mobile phone.
              </p>
            </div>

            {!otpSent ? (
              <form onSubmit={handleSendOtp} className="space-y-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Registered Email or Phone</label>
                  <input
                    type="text"
                    required
                    value={recoverTarget}
                    onChange={(e) => setRecoverTarget(e.target.value)}
                    placeholder={`e.g. ${defaultDropPhone} or cyprian@megamarket.ng`}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center space-x-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Send 6-Digit OTP Code</span>
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-3">
                {otpGeneratedDemo && (
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-[11px] font-bold">
                    Demo Code Generated: <span className="font-mono text-blue-700 text-sm">{otpGeneratedDemo}</span>
                  </div>
                )}

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Enter 6-Digit OTP</label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    placeholder="e.g. 849201"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-mono text-center tracking-widest text-lg font-bold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Set New Password</label>
                  <input
                    type="password"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>

                <div className="flex space-x-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setOtpSent(false)}
                    className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 rounded-xl transition-all"
                  >
                    Resend Code
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-md transition-all active:scale-95"
                  >
                    Verify & Reset
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* Security badge at bottom */}
        <div className="mt-6 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center space-x-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span>256-bit SSL Protected</span>
          </div>
          <div className="flex items-center space-x-1.5 text-emerald-600 font-bold">
            <Globe className="w-3 h-3 shrink-0" />
            <span>Global Supabase Sync</span>
          </div>
        </div>
      </div>
    </div>
  );
};
