import React, { useState } from 'react';
import { useStore } from '../store';
import { 
  Megaphone, 
  Video, 
  Upload, 
  Play, 
  Calendar, 
  Clock, 
  Sparkles, 
  CheckCircle2, 
  Trash2, 
  DollarSign, 
  Globe, 
  ExternalLink,
  Layers,
  Pause,
  Share2
} from 'lucide-react';
import { CurrencyCode } from '../types';

export function VideoLabStudio() {
  const { videoAds, addVideoAd, deleteVideoAd, tickerNews, addTickerNews, removeTickerNews, currency } = useStore();

  const [activeTab, setActiveTab] = useState<'create_ad' | 'manage_ads' | 'ticker_news'>('create_ad');

  // Ad Form State
  const [adTitle, setAdTitle] = useState('');
  const [adDescription, setAdDescription] = useState('');
  const [videoUrl, setVideoUrl] = useState('https://assets.mixkit.co/videos/preview/mixkit-solar-panels-in-a-solar-power-plant-40617-large.mp4');
  const [posterUrl, setPosterUrl] = useState('https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&q=80&w=600');
  const [creatorName, setCreatorName] = useState('Mega Tech Client');
  const [targetUrl, setTargetUrl] = useState('/explore');
  const [socialMediaLink, setSocialMediaLink] = useState('https://instagram.com/megabrand');
  const [durationDays, setDurationDays] = useState('14');
  const [budgetAmount, setBudgetAmount] = useState('50000');
  const [adCurrency, setAdCurrency] = useState<CurrencyCode>('NGN');
  const [dailyAutoPost, setDailyAutoPost] = useState(true);

  // Flowing News Ticker state
  const [tickerTitle, setTickerTitle] = useState('');
  const [tickerContent, setTickerContent] = useState('');
  const [tickerCategory, setTickerCategory] = useState<'announcement' | 'deals' | 'flash_update' | 'financial'>('announcement');

  // Sample quick video templates for 1-click convenience
  const VIDEO_PRESETS = [
    {
      name: 'Solar & Clean Energy Commercial',
      video: 'https://assets.mixkit.co/videos/preview/mixkit-solar-panels-in-a-solar-power-plant-40617-large.mp4',
      poster: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&q=80&w=600'
    },
    {
      name: 'Smart Gadget & Smartphone Showcase',
      video: 'https://assets.mixkit.co/videos/preview/mixkit-hands-holding-a-smartphone-with-a-green-screen-40546-large.mp4',
      poster: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&q=80&w=600'
    },
    {
      name: 'Fashion & Luxury Collection',
      video: 'https://assets.mixkit.co/videos/preview/mixkit-fashion-model-in-a-photoshoot-40228-large.mp4',
      poster: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=600'
    }
  ];

  const handleCreateAd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adTitle.trim() || !videoUrl.trim()) return;

    const days = parseInt(durationDays) || 7;
    const today = new Date();
    const endDate = new Date();
    endDate.setDate(today.getDate() + days);

    addVideoAd({
      title: adTitle.trim(),
      description: adDescription.trim() || 'Verified merchant advertisement broadcasted across Mega Marketplace.',
      video_url: videoUrl.trim(),
      poster_url: posterUrl.trim(),
      creator_name: creatorName.trim() || 'Marketplace Sponsor',
      target_url: targetUrl.trim() || '/explore',
      social_media_link: socialMediaLink.trim() || undefined,
      duration_days: days,
      start_date: today.toISOString().split('T')[0],
      end_date: endDate.toISOString().split('T')[0],
      status: 'active',
      daily_auto_post: dailyAutoPost,
      budget: parseFloat(budgetAmount) || 20000,
      currency: adCurrency
    });

    setAdTitle('');
    setAdDescription('');
    setSocialMediaLink('');
    setActiveTab('manage_ads');
  };

  const handleAddTickerNews = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tickerContent.trim()) return;

    addTickerNews({
      title: tickerTitle.trim() || '⚡ BREAKING NEWS',
      content: tickerContent.trim(),
      category: tickerCategory,
      is_active: true
    });

    setTickerTitle('');
    setTickerContent('');
  };

  return (
    <div className="space-y-6">
      {/* Tab Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center space-x-2">
            <Megaphone className="w-6 h-6 text-blue-600" />
            <span>Ad Manager & Video Lab Studio</span>
          </h2>
          <p className="text-xs text-slate-500">
            Create video commercials, automate scheduled daily posting & broadcast live flowing ticker news.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-slate-100 p-1 rounded-2xl text-xs font-bold">
          <button
            onClick={() => setActiveTab('create_ad')}
            className={`px-3.5 py-2 rounded-xl transition ${
              activeTab === 'create_ad' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Create Video Ad
          </button>
          <button
            onClick={() => setActiveTab('manage_ads')}
            className={`px-3.5 py-2 rounded-xl transition ${
              activeTab === 'manage_ads' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Live Campaigns ({videoAds.length})
          </button>
          <button
            onClick={() => setActiveTab('ticker_news')}
            className={`px-3.5 py-2 rounded-xl transition ${
              activeTab === 'ticker_news' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Flowing Ticker News ({tickerNews.length})
          </button>
        </div>
      </div>

      {/* TAB 1: CREATE AD / VIDEO LAB */}
      {activeTab === 'create_ad' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Ad Form Form */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center space-x-2">
                <Video className="w-4 h-4 text-blue-600" />
                <span>Video Lab Ad Builder</span>
              </span>
              <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                Automated Auto-Post Ready
              </span>
            </div>

            <form onSubmit={handleCreateAd} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Ad Campaign Headline *</label>
                <input
                  type="text"
                  required
                  value={adTitle}
                  onChange={(e) => setAdTitle(e.target.value)}
                  placeholder="e.g. 5KVA Solar Inverter System 40% Off Mega Deal"
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Description & Value Proposition</label>
                <textarea
                  rows={3}
                  value={adDescription}
                  onChange={(e) => setAdDescription(e.target.value)}
                  placeholder="Describe offer details, discount terms, nationwide warranty, and contact numbers..."
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-medium"
                />
              </div>

              {/* Video URL & Quick Presets */}
              <div className="space-y-2">
                <label className="block font-bold text-slate-700">Video Source URL (MP4 / WebM / CDN)</label>
                <input
                  type="url"
                  required
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  placeholder="https://assets.mixkit.co/videos/preview/sample.mp4"
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-mono text-xs"
                />
                
                {/* 1-Click Template Selector */}
                <div className="pt-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Or select pre-rendered video sample:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {VIDEO_PRESETS.map((preset) => (
                      <button
                        key={preset.name}
                        type="button"
                        onClick={() => {
                          setVideoUrl(preset.video);
                          setPosterUrl(preset.poster);
                          if (!adTitle) setAdTitle(preset.name);
                        }}
                        className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 text-[11px] font-semibold transition border border-slate-200"
                      >
                        {preset.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Thumbnail URL */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">Poster Thumbnail Image URL</label>
                <input
                  type="url"
                  value={posterUrl}
                  onChange={(e) => setPosterUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-mono text-xs"
                />
              </div>

              {/* Sponsor & Target link */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Client / Sponsor Business Name</label>
                  <input
                    type="text"
                    value={creatorName}
                    onChange={(e) => setCreatorName(e.target.value)}
                    placeholder="Mega Energy Tech Ltd"
                    className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Destination URL / Product Slug</label>
                  <input
                    type="text"
                    value={targetUrl}
                    onChange={(e) => setTargetUrl(e.target.value)}
                    placeholder="/explore or https://clientbrand.com"
                    className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-medium"
                  />
                </div>
              </div>

              {/* Customer Social Media Link */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Customer / Sponsor Social Media Link (Instagram, TikTok, WhatsApp, Facebook, X)
                </label>
                <input
                  type="url"
                  value={socialMediaLink}
                  onChange={(e) => setSocialMediaLink(e.target.value)}
                  placeholder="https://instagram.com/clientbusiness or https://tiktok.com/@client"
                  className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-medium text-xs bg-slate-50"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Enables users to click through directly to the client's social profile from the ad feed.
                </span>
              </div>

              {/* Schedule, Currency & Agreement */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Campaign Duration (Days agreed)</label>
                  <select
                    value={durationDays}
                    onChange={(e) => setDurationDays(e.target.value)}
                    className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-bold"
                  >
                    <option value="3">3 Days Blast</option>
                    <option value="7">7 Days Standard</option>
                    <option value="14">14 Days Pro</option>
                    <option value="30">30 Days Month-long</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Currency</label>
                  <select
                    value={adCurrency}
                    onChange={(e) => setAdCurrency(e.target.value as CurrencyCode)}
                    className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-bold"
                  >
                    <option value="NGN">NGN (₦)</option>
                    <option value="USD">USD ($)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="EUR">EUR (€)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Client Paid Budget</label>
                  <input
                    type="number"
                    value={budgetAmount}
                    onChange={(e) => setBudgetAmount(e.target.value)}
                    placeholder="50000"
                    className="w-full p-3 rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-none font-bold"
                  />
                </div>
              </div>

              {/* Auto Post Toggle */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 block">Automate Daily Self-Posting</span>
                  <span className="text-[11px] text-slate-500">
                    System will automatically refresh and stream this ad across homepage feeds daily for {durationDays} days.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={dailyAutoPost}
                  onChange={(e) => setDailyAutoPost(e.target.checked)}
                  className="w-5 h-5 accent-blue-600 rounded cursor-pointer"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-3.5 rounded-2xl text-xs sm:text-sm shadow-lg shadow-blue-600/30 active:scale-95 transition-all flex items-center justify-center space-x-2"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Publish Commercial & Stream Live to Frontend</span>
              </button>
            </form>
          </div>

          {/* Interactive Live Preview */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-wider text-slate-700">
                Live Frontend Device Mockup
              </span>
              <span className="text-[11px] text-blue-600 font-bold">Real-time Stream Preview</span>
            </div>

            <div className="bg-slate-900 rounded-3xl p-4 shadow-2xl border border-slate-800 text-white space-y-3">
              <div className="relative aspect-video rounded-2xl overflow-hidden bg-black flex items-center justify-center">
                {videoUrl ? (
                  <video
                    src={videoUrl}
                    poster={posterUrl}
                    controls
                    autoPlay
                    muted
                    loop
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-slate-500 p-6">
                    <Video className="w-8 h-8 mb-2" />
                    <span>Video player will initialize here</span>
                  </div>
                )}
                <div className="absolute top-2 left-2 bg-rose-600 text-white text-[9px] font-black uppercase px-2 py-0.5 rounded-full flex items-center space-x-1 shadow-md">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                  <span>SPONSORED AD</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider block">
                  {creatorName || 'Mega Verified Merchant'}
                </span>
                <h4 className="font-black text-sm text-white line-clamp-1">
                  {adTitle || 'Your Ad Headline Here'}
                </h4>
                <p className="text-xs text-slate-400 line-clamp-2">
                  {adDescription || 'Your ad description will be streamed to customer feeds with direct conversion checkout.'}
                </p>
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-slate-800 text-xs">
                <div className="flex items-center space-x-2 text-slate-400 text-[11px]">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>{durationDays} Days Auto-Schedule</span>
                </div>
                <span className="bg-blue-600 text-white px-3 py-1.5 rounded-xl font-bold text-xs flex items-center space-x-1">
                  <span>Visit Offer</span>
                  <ExternalLink className="w-3 h-3 ml-1" />
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MANAGE ADS */}
      {activeTab === 'manage_ads' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-slate-700 uppercase tracking-wider">
              Active Video Campaigns ({videoAds.length})
            </span>
            <button
              onClick={() => setActiveTab('create_ad')}
              className="bg-blue-600 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold hover:bg-blue-700"
            >
              + Create New Ad
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {videoAds.map((ad) => (
              <div
                key={ad.id}
                className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="aspect-video rounded-2xl overflow-hidden bg-black relative">
                    <video
                      src={ad.video_url}
                      poster={ad.poster_url}
                      controls
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute top-2 left-2 bg-emerald-600 text-white text-[9px] font-bold px-2 py-0.5 rounded-full uppercase">
                      {ad.status}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-blue-600 uppercase block">{ad.creator_name}</span>
                    <h3 className="font-black text-slate-900 text-sm mt-0.5">{ad.title}</h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">{ad.description}</p>
                    {ad.social_media_link && (
                      <a
                        href={ad.social_media_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center space-x-1 text-[11px] text-pink-600 hover:text-pink-700 font-bold mt-1.5 bg-pink-50 px-2 py-0.5 rounded-lg border border-pink-200/60"
                      >
                        <Share2 className="w-3 h-3" />
                        <span className="truncate max-w-[200px]">Client Social: {ad.social_media_link}</span>
                        <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                      </a>
                    )}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <div className="space-y-0.5">
                    <span className="text-[10px] text-slate-400 block">Duration & Clicks</span>
                    <span className="font-bold text-slate-700">
                      {ad.duration_days} Days • {ad.views_count || 120} Views
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      deleteVideoAd(ad.id);
                    }}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl font-bold transition text-xs border border-rose-200"
                    title="Delete Video Ad"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Video</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: FLOWING TICKER NEWS */}
      {activeTab === 'ticker_news' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-sm font-black text-slate-900 flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Broadcast Announcement to Website Ticker</span>
            </h3>

            <form onSubmit={handleAddTickerNews} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Headline Badge</label>
                <input
                  type="text"
                  value={tickerTitle}
                  onChange={(e) => setTickerTitle(e.target.value)}
                  placeholder="e.g. ⚡ FLASH NOTICE or 📢 MEGA REWARD"
                  className="w-full p-2.5 rounded-xl border border-slate-300 focus:border-blue-600 font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Flowing Message Body *</label>
                <textarea
                  rows={3}
                  required
                  value={tickerContent}
                  onChange={(e) => setTickerContent(e.target.value)}
                  placeholder="Message flowing across top banner for all users to see..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 focus:border-blue-600 font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Category</label>
                <select
                  value={tickerCategory}
                  onChange={(e) => setTickerCategory(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 focus:border-blue-600 font-bold"
                >
                  <option value="announcement">Announcement</option>
                  <option value="deals">Deals & Flash Sales</option>
                  <option value="financial">Financial & Bank Notices</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl text-xs transition"
              >
                Broadcast to Flowing News Ticker
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 space-y-4">
            <span className="text-xs font-black text-slate-700 uppercase tracking-wider block">
              Currently Flowing Ticker Items ({tickerNews.length})
            </span>

            <div className="space-y-3">
              {tickerNews.map((item) => (
                <div
                  key={item.id}
                  className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-start justify-between gap-3 text-xs"
                >
                  <div className="space-y-1">
                    <span className="font-black text-blue-600">{item.title}</span>
                    <p className="text-slate-600">{item.content}</p>
                    <span className="text-[10px] text-slate-400 block">
                      Posted: {new Date(item.created_at).toLocaleDateString()}
                    </span>
                  </div>

                  <button
                    onClick={() => removeTickerNews(item.id)}
                    className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
