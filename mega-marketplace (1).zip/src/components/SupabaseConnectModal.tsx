import React, { useState, useEffect } from 'react';
import { 
  Database, 
  CheckCircle2, 
  AlertCircle, 
  Copy, 
  ExternalLink, 
  Clipboard, 
  RefreshCw, 
  Zap, 
  Eye, 
  EyeOff, 
  X,
  ShieldCheck,
  Server,
  Code
} from 'lucide-react';
import { 
  DEFAULT_SUPABASE_URL, 
  DEFAULT_SUPABASE_ANON_KEY, 
  getSavedCredentials, 
  getCurrentSupabaseConfig, 
  testSupabaseConnection, 
  applySupabaseCredentialsGlobally 
} from '../lib/supabase';
import { useStore } from '../store';

interface SupabaseConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RECOMMENDED_SUPABASE_SQL = `-- MEGA MARKETPLACE GLOBAL SUPABASE SCHEMA
-- Run this in your Supabase Dashboard -> SQL Editor to initialize all tables

-- 1. Profiles & Users
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  email TEXT UNIQUE,
  full_name TEXT,
  phone TEXT,
  avatar_url TEXT,
  role TEXT DEFAULT 'buyer',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Stores / Vendors
CREATE TABLE IF NOT EXISTS public.stores (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  owner_id UUID REFERENCES auth.users ON DELETE CASCADE,
  name TEXT NOT NULL,
  slug TEXT UNIQUE,
  logo TEXT,
  description TEXT,
  category TEXT,
  is_verified BOOLEAN DEFAULT FALSE,
  is_approved BOOLEAN DEFAULT FALSE,
  rating NUMERIC DEFAULT 5.0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Products
CREATE TABLE IF NOT EXISTS public.products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID REFERENCES public.stores ON DELETE SET NULL,
  title TEXT NOT NULL,
  slug TEXT UNIQUE,
  description TEXT,
  price NUMERIC NOT NULL,
  original_price NUMERIC,
  category TEXT NOT NULL,
  images TEXT[] DEFAULT '{}',
  stock INTEGER DEFAULT 10,
  is_published BOOLEAN DEFAULT TRUE,
  rating NUMERIC DEFAULT 5.0,
  reviews_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Orders
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users ON DELETE SET NULL,
  total_amount NUMERIC NOT NULL,
  status TEXT DEFAULT 'pending',
  shipping_address JSONB,
  items JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;

-- Allow public read access
CREATE POLICY IF NOT EXISTS "Allow public read products" ON public.products FOR SELECT USING (true);
CREATE POLICY IF NOT EXISTS "Allow public read stores" ON public.stores FOR SELECT USING (true);
`;

export function SupabaseConnectModal({ isOpen, onClose }: SupabaseConnectModalProps) {
  const { addToast, updatePlatformSettings } = useStore();
  const saved = getSavedCredentials();
  
  const [url, setUrl] = useState(saved.url);
  const [anonKey, setAnonKey] = useState(saved.anonKey);
  const [showKey, setShowKey] = useState(false);
  const [activeTab, setActiveTab] = useState<'credentials' | 'sql' | 'env'>('credentials');
  
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{
    tested: boolean;
    success: boolean;
    latencyMs: number;
    message: string;
    projectRef?: string;
  } | null>(null);

  const [isApplying, setIsApplying] = useState(false);
  const [appliedSuccess, setAppliedSuccess] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const current = getSavedCredentials();
      setUrl(current.url);
      setAnonKey(current.anonKey);
      setTestResult(null);
      setAppliedSuccess(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const currentConfig = getCurrentSupabaseConfig();

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const result = await testSupabaseConnection(url, anonKey);
      setTestResult({
        tested: true,
        success: result.success,
        latencyMs: result.latencyMs,
        message: result.message,
        projectRef: result.projectRef
      });
      if (result.success) {
        addToast(`Supabase reachable! Latency: ${result.latencyMs}ms`, 'success', 'Connection Verified');
      } else {
        addToast(result.message, 'error', 'Connection Test Failed');
      }
    } catch (err: any) {
      setTestResult({
        tested: true,
        success: false,
        latencyMs: 0,
        message: err?.message || 'Failed to ping Supabase endpoint'
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handlePasteUrl = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setUrl(text.trim());
        addToast('Pasted Supabase Project URL', 'info', 'Clipboard');
      }
    } catch {
      addToast('Please paste manually using Ctrl+V or right click', 'info');
    }
  };

  const handlePasteKey = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setAnonKey(text.trim());
        addToast('Pasted Supabase Anon Key', 'info', 'Clipboard');
      }
    } catch {
      addToast('Please paste manually using Ctrl+V or right click', 'info');
    }
  };

  const handleResetToProvided = () => {
    setUrl(DEFAULT_SUPABASE_URL);
    setAnonKey(DEFAULT_SUPABASE_ANON_KEY);
    addToast('Restored provided Supabase project credentials', 'info', 'Reset');
  };

  const handleApplyGlobally = () => {
    if (!url.trim() || !anonKey.trim()) {
      addToast('Please provide both Supabase Project URL and Anon Key', 'error', 'Missing Credentials');
      return;
    }

    setIsApplying(true);
    try {
      // 1. Apply credentials to Supabase client & direct localStorage
      const result = applySupabaseCredentialsGlobally(url, anonKey);

      // 2. Synchronize to Zustand store
      updatePlatformSettings({
        supabase_url: url.trim(),
        supabase_anon_key: anonKey.trim()
      });

      setAppliedSuccess(true);
      addToast('Supabase credentials successfully connected globally to your website!', 'success', 'Globally Connected');

      // Auto close after brief celebration
      setTimeout(() => {
        setIsApplying(false);
      }, 600);
    } catch (err: any) {
      setIsApplying(false);
      addToast(err?.message || 'Failed to apply credentials', 'error', 'Configuration Error');
    }
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(RECOMMENDED_SUPABASE_SQL);
    setCopiedCode(true);
    addToast('SQL schema copied to clipboard! Paste in Supabase SQL Editor.', 'success', 'Copied');
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const envSnippet = `# .env Configuration
VITE_SUPABASE_URL="${url.trim()}"
VITE_SUPABASE_ANON_KEY="${anonKey.trim()}"`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 p-6 text-white relative">
          <button 
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex items-center space-x-3 mb-2">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
              <Database className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-tight">Supabase Global Connection Setup</h2>
              <p className="text-xs text-white/80 font-medium">Connect & sync your entire website globally with your Supabase account</p>
            </div>
          </div>

          {/* Current Active Status Indicator */}
          <div className="mt-4 bg-black/20 backdrop-blur-xs rounded-2xl p-3 border border-white/15 flex items-center justify-between">
            <div className="flex items-center space-x-2.5">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-300"></span>
              </span>
              <div className="text-left">
                <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-200">Global Connection Status</div>
                <div className="text-xs font-semibold text-white truncate max-w-[280px] sm:max-w-md">
                  Active Project: <strong className="font-mono text-emerald-300">{currentConfig.projectRef}</strong> ({currentConfig.url})
                </div>
              </div>
            </div>
            <span className="hidden sm:inline-flex items-center space-x-1 text-[11px] bg-white/20 font-bold px-2.5 py-1 rounded-full text-white">
              <Zap className="w-3 h-3 text-emerald-300" />
              <span>Globally Active</span>
            </span>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-200 bg-slate-50/80 px-6 pt-3 space-x-2">
          <button
            onClick={() => setActiveTab('credentials')}
            className={`pb-3 px-3 text-xs font-bold border-b-2 flex items-center space-x-1.5 transition-colors ${
              activeTab === 'credentials'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Server className="w-4 h-4" />
            <span>Paste & Apply Credentials</span>
          </button>
          <button
            onClick={() => setActiveTab('sql')}
            className={`pb-3 px-3 text-xs font-bold border-b-2 flex items-center space-x-1.5 transition-colors ${
              activeTab === 'sql'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Code className="w-4 h-4" />
            <span>Supabase SQL Tables Schema</span>
          </button>
          <button
            onClick={() => setActiveTab('env')}
            className={`pb-3 px-3 text-xs font-bold border-b-2 flex items-center space-x-1.5 transition-colors ${
              activeTab === 'env'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>.env Configuration</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeTab === 'credentials' && (
            <div className="space-y-5">
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-xs text-emerald-900 flex items-start space-x-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-bold">Paste your Supabase credentials below and click "Apply & Connect Globally".</p>
                  <p className="text-emerald-800/90">
                    This dynamically updates your app's live database client, stores the keys securely in local browser storage, and binds all queries across the marketplace to your project.
                  </p>
                </div>
              </div>

              {/* Supabase URL field */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-extrabold text-slate-700 uppercase tracking-wider flex items-center space-x-1.5">
                    <span>1. Supabase Project URL</span>
                    <span className="text-rose-500">*</span>
                  </label>
                  <div className="flex items-center space-x-2">
                    <button
                      type="button"
                      onClick={handlePasteUrl}
                      className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 flex items-center space-x-1 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200"
                    >
                      <Clipboard className="w-3 h-3" />
                      <span>Paste URL</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleResetToProvided}
                      className="text-[11px] font-semibold text-slate-500 hover:text-slate-700 underline"
                    >
                      Use Provided Default
                    </button>
                  </div>
                </div>
                <div className="relative">
                  <input
                    type="url"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://ugkvfehugcakdqbikdyx.supabase.co"
                    className="w-full text-xs font-mono px-3.5 py-3 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all pr-10"
                  />
                  {url && (
                    <button
                      onClick={() => setUrl('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      title="Clear"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
                <p className="text-[11px] text-slate-500">
                  Find in your Supabase Dashboard: <strong>Project Settings → API → Project URL</strong>
                </p>
              </div>

              {/* Supabase Anon Key field */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-extrabold text-slate-700 uppercase tracking-wider flex items-center space-x-1.5">
                    <span>2. Supabase Anon / Public API Key</span>
                    <span className="text-rose-500">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={handlePasteKey}
                    className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 flex items-center space-x-1 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200"
                  >
                    <Clipboard className="w-3 h-3" />
                    <span>Paste Key</span>
                  </button>
                </div>
                <div className="relative">
                  <textarea
                    rows={3}
                    value={anonKey}
                    onChange={(e) => setAnonKey(e.target.value)}
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                    className={`w-full text-xs font-mono px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all pr-10 ${
                      !showKey ? 'filter blur-[1.5px] hover:blur-none transition-all' : ''
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowKey(!showKey)}
                    className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                    title={showKey ? 'Hide key' : 'Show key'}
                  >
                    {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  Find in your Supabase Dashboard: <strong>Project Settings → API → Project API keys (anon public)</strong>
                </p>
              </div>

              {/* Live Connection Test Feedback */}
              {testResult && (
                <div
                  className={`rounded-2xl p-4 border text-xs flex items-start space-x-3 animate-in fade-in duration-200 ${
                    testResult.success 
                      ? 'bg-emerald-50/90 border-emerald-300 text-emerald-950' 
                      : 'bg-rose-50/90 border-rose-300 text-rose-950'
                  }`}
                >
                  {testResult.success ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  )}
                  <div className="space-y-1">
                    <div className="font-bold flex items-center space-x-2">
                      <span>{testResult.success ? 'Supabase Connection Live & Healthy' : 'Connection Failed'}</span>
                      {testResult.latencyMs > 0 && (
                        <span className="bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded-full text-[10px] font-mono">
                          {testResult.latencyMs}ms latency
                        </span>
                      )}
                    </div>
                    <p className="opacity-90">{testResult.message}</p>
                  </div>
                </div>
              )}

              {appliedSuccess && (
                <div className="bg-emerald-600 text-white rounded-2xl p-4 text-xs flex items-center space-x-3 shadow-md">
                  <CheckCircle2 className="w-5 h-5 text-white shrink-0" />
                  <div>
                    <strong className="block font-bold">Successfully Connected Globally!</strong>
                    <span>Your entire website is now actively using this Supabase project.</span>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={handleTestConnection}
                  disabled={isTesting || !url.trim() || !anonKey.trim()}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                  <span>{isTesting ? 'Testing Latency...' : 'Test Connection'}</span>
                </button>

                <div className="flex items-center space-x-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={onClose}
                    className="w-1/2 sm:w-auto px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-semibold"
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    onClick={handleApplyGlobally}
                    disabled={isApplying || !url.trim() || !anonKey.trim()}
                    className="w-1/2 sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
                  >
                    <Zap className="w-4 h-4 text-emerald-200" />
                    <span>{isApplying ? 'Applying Globally...' : 'Apply & Connect Globally'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'sql' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-slate-900">Recommended Supabase Database Schema</h3>
                  <p className="text-[11px] text-slate-500">Run this in your Supabase SQL Editor if setting up tables from scratch.</p>
                </div>
                <button
                  onClick={handleCopySql}
                  className="text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white px-3 py-1.5 rounded-xl flex items-center space-x-1.5 transition-colors shadow-xs"
                >
                  {copiedCode ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Copied SQL!' : 'Copy SQL Script'}</span>
                </button>
              </div>

              <div className="relative bg-slate-950 rounded-2xl p-4 overflow-x-auto border border-slate-800 max-h-96">
                <pre className="text-[11px] font-mono text-emerald-400 leading-relaxed">
                  {RECOMMENDED_SUPABASE_SQL}
                </pre>
              </div>
            </div>
          )}

          {activeTab === 'env' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-xs font-bold text-slate-900">Root .env File Configuration</h3>
                <p className="text-[11px] text-slate-500">You can also copy these into your project's .env file directly.</p>
              </div>

              <div className="relative bg-slate-950 rounded-2xl p-4 border border-slate-800">
                <pre className="text-xs font-mono text-emerald-400 leading-relaxed overflow-x-auto">
                  {envSnippet}
                </pre>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(envSnippet);
                    addToast('Copied .env values to clipboard', 'success', 'Copied');
                  }}
                  className="absolute top-3 right-3 text-slate-400 hover:text-white p-1.5 rounded-lg bg-slate-800 transition-colors"
                  title="Copy .env values"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs text-slate-600 space-y-2">
                <p className="font-bold text-slate-800">Where to find these in Supabase:</p>
                <ol className="list-decimal list-inside space-y-1 text-slate-600 text-[11px]">
                  <li>Go to your dashboard at <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" className="text-emerald-600 underline font-semibold">supabase.com</a></li>
                  <li>Click on your project</li>
                  <li>Go to <strong>Project Settings</strong> (gear icon at the bottom left)</li>
                  <li>Click on <strong>API</strong> in the sidebar</li>
                  <li>Copy <strong>Project URL</strong> and <strong>Project API Keys (anon / public)</strong></li>
                </ol>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
