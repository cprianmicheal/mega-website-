import React from 'react';
import { useStore } from '../store';
import { CURRENCIES } from '../lib/utils';
import { CurrencyCode } from '../types';
import { Globe, Check, X } from 'lucide-react';

interface CurrencyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CurrencyModal: React.FC<CurrencyModalProps> = ({ isOpen, onClose }) => {
  const currentCurrency = useStore((state) => state.currency);
  const setCurrency = useStore((state) => state.setCurrency);

  if (!isOpen) return null;

  const currencyList = Object.values(CURRENCIES);

  const handleSelect = (code: CurrencyCode) => {
    setCurrency(code);
    onClose();
  };

  return (
    <div 
      id="currency-modal-backdrop" 
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
    >
      <div 
        id="currency-modal-card" 
        className="bg-white w-full max-w-lg rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95 max-h-[90vh] flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900">Select Global Currency</h3>
              <p className="text-xs text-slate-500">Live prices auto-convert across the whole marketplace</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 hover:bg-slate-200 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Currency List */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 overflow-y-auto pr-1 flex-1 py-1">
          {currencyList.map((cur) => {
            const isSelected = currentCurrency === cur.code;
            return (
              <button
                key={cur.code}
                id={`currency-btn-${cur.code}`}
                onClick={() => handleSelect(cur.code)}
                className={`p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/80 text-blue-900 shadow-xs'
                    : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50 text-slate-800'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{cur.flag}</span>
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="font-black text-sm">{cur.code}</span>
                      <span className="text-xs font-bold text-slate-400 font-mono">({cur.symbol})</span>
                    </div>
                    <span className="text-[11px] text-slate-500 block truncate max-w-[140px]">{cur.name}</span>
                  </div>
                </div>

                {isSelected && (
                  <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer Note */}
        <div className="mt-4 pt-3 border-t border-slate-100 text-center">
          <p className="text-[11px] text-slate-400">
            Real-time interbank conversion rates synchronized against NGN base.
          </p>
        </div>
      </div>
    </div>
  );
};
