import React, { useState } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { 
  Shield, 
  BookOpen, 
  DollarSign, 
  Megaphone, 
  LayoutDashboard, 
  ArrowLeft, 
  Users, 
  Key, 
  ExternalLink, 
  Lock, 
  Activity, 
  Briefcase,
  ChevronLeft,
  ChevronRight,
  Pin,
  Menu,
  X
} from 'lucide-react';
import { useStore } from '../store';

interface AdminSidebarProps {
  activeRole?: 'super_admin' | 'bookkeeper' | 'money_checker' | 'ad_manager';
}

export function AdminSidebar({ activeRole }: AdminSidebarProps) {
  const navigate = useNavigate();
  const { teamApplications, adminRevenueNgn, logoutStaff, logoutAdmin } = useStore();
  const pendingApps = teamApplications.filter(a => a.status === 'pending').length;

  const [isLocked, setIsLocked] = useState(true); // Clip / lock the panel navlist
  const [mobileOpen, setMobileOpen] = useState(false);

  const links = [
    { 
      to: '/admin/super', 
      aliasPath: '/#admin', 
      label: 'Super Admin', 
      badge: 'Master', 
      icon: Shield, 
      desc: '/#admin' 
    },
    { 
      to: '/@admin', 
      aliasPath: '/admin/bookkeeper', 
      label: 'Bookkeeper', 
      icon: BookOpen, 
      desc: '/@admin' 
    },
    { 
      to: '/$admin', 
      aliasPath: '/admin/money', 
      label: 'Money Checker', 
      icon: DollarSign, 
      desc: '/$admin' 
    },
    { 
      to: '/%admin', 
      aliasPath: '/admin/ads', 
      label: 'Ad Manager', 
      icon: Megaphone, 
      desc: '/%admin' 
    },
  ];

  const handleSignOut = () => {
    logoutStaff();
    logoutAdmin();
    navigate('/');
  };

  return (
    <>
      {/* Mobile Trigger Button */}
      <div className="lg:hidden fixed top-3 left-3 z-50">
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="bg-slate-900/90 text-white p-2.5 rounded-xl border border-slate-700 shadow-xl flex items-center space-x-1.5 backdrop-blur-md"
          title="Toggle Navigation"
        >
          {mobileOpen ? <X className="w-5 h-5 text-rose-400" /> : <Menu className="w-5 h-5 text-blue-400" />}
          <span className="text-xs font-bold">{mobileOpen ? 'Close' : 'Admin Menu'}</span>
        </button>
      </div>

      {/* Backdrop for Mobile */}
      {mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          className="lg:hidden fixed inset-0 bg-black/60 backdrop-blur-xs z-40 transition-opacity"
        />
      )}

      {/* Main Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 left-0 z-40 h-screen transition-all duration-300 ease-in-out bg-slate-950 text-white border-r border-slate-800 flex flex-col justify-between shrink-0 select-none overflow-y-auto ${
          mobileOpen ? 'translate-x-0 w-72' : '-translate-x-full lg:translate-x-0'
        } ${isLocked ? 'lg:w-64 xl:w-72 p-4 sm:p-5' : 'lg:w-20 p-3'}`}
      >
        <div className="space-y-5">
          {/* Brand Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <Link to="/" className="flex items-center space-x-2.5 group overflow-hidden">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center font-black text-white shadow-md shadow-blue-500/20 shrink-0">
                M
              </div>
              {isLocked && (
                <div className="truncate">
                  <span className="font-black text-sm tracking-tight text-white block">Mega Control</span>
                  <span className="text-[10px] text-blue-400 font-bold uppercase tracking-wider">Multi-Role Admin</span>
                </div>
              )}
            </Link>

            {/* Clip / Lock navlist button */}
            <button
              onClick={() => setIsLocked(!isLocked)}
              className={`p-1.5 rounded-lg border transition hidden lg:flex items-center justify-center ${
                isLocked
                  ? 'bg-blue-600/20 text-blue-400 border-blue-500/40 hover:bg-blue-600/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
              }`}
              title={isLocked ? 'Clip lock active (Click to collapse sidebar)' : 'Expand sidebar and lock'}
            >
              <Pin className={`w-3.5 h-3.5 transition-transform ${isLocked ? 'rotate-45 text-blue-400' : 'text-slate-400'}`} />
            </button>
          </div>

          {/* Super Hand Indicator */}
          {isLocked ? (
            <div className="bg-gradient-to-r from-amber-950/60 to-slate-900 border border-amber-500/30 rounded-2xl p-3 flex items-center space-x-3">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <Activity className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center space-x-1.5">
                  <span className="text-[11px] font-black text-amber-300">Super Hand Active</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                </div>
                <p className="text-[10px] text-slate-400 truncate">Monitoring all 4 role portals</p>
              </div>
            </div>
          ) : (
            <div className="flex justify-center" title="Super Hand Active">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                <Activity className="w-4 h-4" />
              </div>
            </div>
          )}

          {/* Direct Access Routes Navigation */}
          <div className="space-y-1.5">
            {isLocked && (
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2 block">
                Role Portals & Routes
              </span>
            )}
            <nav className="space-y-1.5">
              {links.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  onClick={() => setMobileOpen(false)}
                  title={link.label}
                  className={({ isActive }) =>
                    `flex items-center ${isLocked ? 'justify-between p-3' : 'justify-center p-2.5'} rounded-2xl text-xs font-bold transition-all ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 font-black'
                        : 'text-slate-300 hover:bg-slate-900 hover:text-white border border-transparent hover:border-slate-800'
                    }`
                  }
                >
                  <div className="flex items-center space-x-3 min-w-0">
                    <link.icon className="w-4 h-4 shrink-0 text-blue-400" />
                    {isLocked && (
                      <div className="truncate">
                        <span className="block truncate">{link.label}</span>
                        <span className="text-[10px] font-mono text-slate-400 block">{link.desc}</span>
                      </div>
                    )}
                  </div>
                  {isLocked && link.badge && (
                    <span className="text-[9px] bg-amber-400 text-slate-950 font-black px-1.5 py-0.5 rounded-full uppercase">
                      {link.badge}
                    </span>
                  )}
                </NavLink>
              ))}
            </nav>
          </div>

          {/* Quick Management Shortcuts */}
          {isLocked && (
            <div className="space-y-2 pt-2 border-t border-slate-900">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2 block">
                Ecosystem Modules
              </span>

              <Link
                to="/apply"
                onClick={() => setMobileOpen(false)}
                className="flex items-center justify-between p-2.5 rounded-xl text-xs text-slate-300 hover:bg-slate-900 transition-colors"
              >
                <div className="flex items-center space-x-2.5">
                  <Briefcase className="w-4 h-4 text-emerald-400" />
                  <span>Team Applications</span>
                </div>
                {pendingApps > 0 && (
                  <span className="bg-emerald-500 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                    {pendingApps}
                  </span>
                )}
              </Link>

              <Link
                to="/sell"
                onClick={() => setMobileOpen(false)}
                className="flex items-center space-x-2.5 p-2.5 rounded-xl text-xs text-slate-300 hover:bg-slate-900 transition-colors"
              >
                <ExternalLink className="w-4 h-4 text-purple-400" />
                <span>Marketplace Listing Studio</span>
              </Link>

              <div className="p-3 bg-slate-900/90 rounded-2xl border border-slate-800 text-xs">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">₦50 Platform Revenue</span>
                <div className="text-base font-black text-emerald-400 mt-0.5">
                  ₦{adminRevenueNgn.toLocaleString()}
                </div>
                <span className="text-[9px] text-slate-400 block mt-0.5 font-medium">UBA 2311406173 (CYPRIAN MICHAEL O.)</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer / Switch / Exit */}
        <div className={`pt-4 border-t border-slate-800 space-y-2 text-xs ${!isLocked && 'flex flex-col items-center'}`}>
          <Link
            to="/"
            title="Exit to Customer Store"
            className={`flex items-center space-x-2 text-slate-400 hover:text-white transition-colors p-2 rounded-xl hover:bg-slate-900 ${
              !isLocked && 'justify-center w-full'
            }`}
          >
            <ArrowLeft className="w-4 h-4" />
            {isLocked && <span>Exit to Customer Store</span>}
          </Link>

          <button
            onClick={handleSignOut}
            title="Lock Staff Session"
            className={`w-full flex items-center justify-center space-x-2 bg-rose-950/40 hover:bg-rose-900 text-rose-300 hover:text-white p-2.5 rounded-xl font-bold transition-colors border border-rose-900/40 text-xs ${
              !isLocked && 'px-2'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            {isLocked && <span>Lock Staff Session</span>}
          </button>
        </div>
      </aside>
    </>
  );
}
