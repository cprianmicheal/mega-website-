import React from 'react';
import { useStore } from '../store';
import { CheckCircle2, AlertCircle, AlertTriangle, Info, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const toasts = useStore((state) => state.toasts);
  const removeToast = useStore((state) => state.removeToast);

  if (toasts.length === 0) return null;

  return (
    <div 
      id="toast-notifications-container" 
      className="fixed bottom-20 md:bottom-6 right-4 z-50 flex flex-col space-y-2.5 max-w-sm w-full pointer-events-none"
    >
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';
        const isWarning = toast.type === 'warning';
        const isInfo = toast.type === 'info' || !toast.type;

        return (
          <div
            key={toast.id}
            id={`toast-${toast.id}`}
            className={`pointer-events-auto flex items-start space-x-3 p-3.5 rounded-2xl shadow-xl border backdrop-blur-md transition-all duration-300 animate-in slide-in-from-right-5 fade-in ${
              isSuccess
                ? 'bg-slate-900/95 text-white border-green-500/40 shadow-green-950/20'
                : isError
                ? 'bg-rose-950/95 text-white border-rose-500/50 shadow-rose-950/30'
                : isWarning
                ? 'bg-amber-950/95 text-white border-amber-500/50 shadow-amber-950/30'
                : 'bg-slate-900/95 text-white border-blue-500/40 shadow-blue-950/20'
            }`}
          >
            {/* Icon */}
            <div className="shrink-0 mt-0.5">
              {isSuccess && <CheckCircle2 className="w-5 h-5 text-green-400" />}
              {isError && <AlertCircle className="w-5 h-5 text-rose-400" />}
              {isWarning && <AlertTriangle className="w-5 h-5 text-amber-400" />}
              {isInfo && <Info className="w-5 h-5 text-blue-400" />}
            </div>

            {/* Content */}
            <div className="flex-1 text-xs">
              {toast.title && (
                <h4 className="font-bold text-white leading-tight mb-0.5">{toast.title}</h4>
              )}
              <p className="text-slate-200 leading-snug font-medium">{toast.message}</p>
            </div>

            {/* Dismiss Button */}
            <button
              onClick={() => removeToast(toast.id)}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
              aria-label="Dismiss notification"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
