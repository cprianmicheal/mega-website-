import React, { useState } from 'react';
import { useStore } from '../store';
import { 
  Bell, 
  BellRing, 
  Smartphone, 
  MessageSquare, 
  Check, 
  X, 
  ShieldCheck, 
  Sparkles, 
  Radio, 
  MapPin, 
  ExternalLink,
  Clock,
  Send
} from 'lucide-react';
import { Link } from 'react-router-dom';

export function PhoneNotificationModal() {
  const { 
    user, 
    phoneNotificationPermission, 
    setPhoneNotificationPermission, 
    phoneDropAlerts,
    broadcastPhoneDropAlert,
    addToast 
  } = useStore();

  const [isOpenPrompt, setIsOpenPrompt] = useState(phoneNotificationPermission === 'prompt');
  const [showInboxModal, setShowInboxModal] = useState(false);

  // If permission has not been asked yet and prompt is open
  const userPhone = user.phone || '0704409544';

  const handleAllow = () => {
    setPhoneNotificationPermission('granted');
    setIsOpenPrompt(false);
  };

  const handleDeny = () => {
    setPhoneNotificationPermission('denied');
    setIsOpenPrompt(false);
  };

  const handleSendTestDrop = () => {
    broadcastPhoneDropAlert({
      title: '⚡ FLASH DROP: Apple iPhone 15 Pro Max (256GB)',
      message: 'New verified batch just arrived in Ankpa Central warehouse. ₦1,750,000 with same-day Ankpa delivery & 1-yr Apple Care.',
      recipientPhone: userPhone,
      channel: 'WHATSAPP',
      productTitle: 'iPhone 15 Pro Max',
      productPrice: 1750000,
      productSlug: 'macbook-pro-m3-max-16',
      productImage: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&q=80&w=300',
      locationTag: 'Ankpa, Kogi State, Nigeria'
    });
    addToast('Test live drop message sent to phone alert stream!', 'success');
  };

  return (
    <>
      {/* 1. INITIAL PERMISSION PROMPT MODAL (When prompt is pending) */}
      {isOpenPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-300">
          <div 
            className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-7 shadow-2xl border border-slate-100 relative text-center space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Animated Ring Icon */}
            <div className="relative mx-auto w-16 h-16 rounded-3xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/30">
              <Smartphone className="w-8 h-8" />
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 rounded-full flex items-center justify-center text-white text-[10px] font-black animate-pulse">
                !
              </span>
            </div>

            <div className="space-y-1.5">
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-full">
                Instant Phone Alerts
              </span>
              <h3 className="text-xl font-extrabold text-slate-900 leading-tight">
                Allow SMS & WhatsApp Drop Notifications?
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto">
                Receive instant phone notifications on <strong className="text-slate-800">{userPhone}</strong> when verified vendors in <strong className="text-slate-800">Ankpa, Kogi State</strong> and nationwide drop new gadgets, flash deals, and order updates.
              </p>
            </div>

            {/* Notification Feature Highlights */}
            <div className="bg-slate-50 rounded-2xl p-3.5 text-left text-xs space-y-2 border border-slate-200/70">
              <div className="flex items-center space-x-2 text-slate-700">
                <Check className="w-4 h-4 text-green-600 shrink-0" />
                <span>Instant product drops & new inventory arrivals</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-700">
                <Check className="w-4 h-4 text-green-600 shrink-0" />
                <span>Live order dispatch & delivery SMS tracking</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-700">
                <Check className="w-4 h-4 text-green-600 shrink-0" />
                <span>Local vendor alerts for Ankpa & Kogi region</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-1">
              <button
                type="button"
                onClick={handleDeny}
                className="w-full sm:w-1/2 py-3 rounded-2xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors"
              >
                Deny / Later
              </button>
              <button
                type="button"
                onClick={handleAllow}
                className="w-full sm:w-1/2 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold shadow-md shadow-blue-500/25 transition-all flex items-center justify-center space-x-1.5"
              >
                <Bell className="w-4 h-4" />
                <span>Allow Notifications</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. FLOATING PHONE DROP ALERTS TRIGGER (Always visible in bottom corner or navbar) */}
      <div className="fixed bottom-20 right-4 md:bottom-6 md:right-6 z-40">
        <button
          onClick={() => setShowInboxModal(true)}
          className="group flex items-center space-x-2 bg-slate-900/90 hover:bg-slate-900 text-white px-3.5 py-2.5 rounded-2xl shadow-xl shadow-slate-900/20 border border-slate-800 backdrop-blur-md transition-all hover:scale-105"
          title="Phone Notification Drop Stream"
        >
          <div className="relative">
            <Smartphone className="w-4 h-4 text-blue-400 group-hover:text-white transition-colors" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-green-500 animate-ping" />
          </div>
          <span className="text-xs font-extrabold tracking-tight">Phone Drops</span>
          <span className="bg-blue-600 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full">
            {phoneDropAlerts.length}
          </span>
        </button>
      </div>

      {/* 3. PHONE DROPS INBOX MODAL */}
      {showInboxModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div 
            className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 relative max-h-[85vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 shrink-0">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
                  <BellRing className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-base">Phone Drop Alerts</h3>
                  <p className="text-xs text-slate-500 font-medium">
                    Delivered to <strong className="text-slate-800">{userPhone}</strong>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowInboxModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 hover:text-slate-900 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Permission Status Banner */}
            <div className="py-3 px-3.5 my-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between shrink-0">
              <div className="flex items-center space-x-2 text-xs">
                <span className={`w-2.5 h-2.5 rounded-full ${phoneNotificationPermission === 'granted' ? 'bg-green-500 animate-pulse' : 'bg-amber-500'}`} />
                <span className="font-bold text-slate-700">
                  Status: {phoneNotificationPermission === 'granted' ? 'Live Alerts Active' : 'Permission Pending/Muted'}
                </span>
              </div>
              {phoneNotificationPermission !== 'granted' ? (
                <button
                  onClick={handleAllow}
                  className="text-xs font-bold text-blue-600 hover:underline"
                >
                  Enable Now
                </button>
              ) : (
                <span className="text-[11px] text-green-700 font-bold bg-green-100 px-2 py-0.5 rounded-full">
                  SMS & WhatsApp Active
                </span>
              )}
            </div>

            {/* Scrollable Alerts List */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1 py-1">
              {phoneDropAlerts.length === 0 ? (
                <div className="text-center py-10 space-y-2">
                  <Smartphone className="w-10 h-10 text-slate-300 mx-auto" />
                  <p className="text-xs font-bold text-slate-500">No drop alerts yet</p>
                  <p className="text-[11px] text-slate-400">When sellers post new items in Ankpa, you will be notified here!</p>
                </div>
              ) : (
                phoneDropAlerts.map((alert) => (
                  <div 
                    key={alert.id} 
                    className="p-3.5 rounded-2xl bg-slate-50 hover:bg-blue-50/40 border border-slate-200/80 transition-all space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-bold text-slate-900 leading-tight">
                        {alert.title}
                      </span>
                      <span className="text-[10px] font-bold uppercase bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full shrink-0">
                        {alert.channel}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      {alert.message}
                    </p>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-200/40">
                      <span className="flex items-center space-x-1">
                        <MapPin className="w-3 h-3 text-rose-500" />
                        <span>{alert.locationTag || 'Ankpa, Kogi State'}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>{alert.timestamp}</span>
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Modal Footer with Send Test Drop Button */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3 shrink-0">
              <button
                type="button"
                onClick={handleSendTestDrop}
                className="text-xs font-bold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-3 py-2 rounded-xl transition-colors flex items-center space-x-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Simulate Drop Alert</span>
              </button>
              <button
                type="button"
                onClick={() => setShowInboxModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
