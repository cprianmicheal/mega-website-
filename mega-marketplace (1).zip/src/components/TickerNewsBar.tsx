import React, { useState } from 'react';
import { useStore } from '../store';
import { Sparkles, Bell, ArrowRight, X } from 'lucide-react';
import { Link } from 'react-router-dom';

export function TickerNewsBar() {
  const { tickerNews } = useStore();
  const [dismissed, setDismissed] = useState(false);

  if (dismissed || !tickerNews || tickerNews.length === 0) return null;

  return (
    <div className="bg-gradient-to-r from-slate-950 via-blue-950 to-slate-950 text-white border-b border-blue-900/40 py-2 px-3 sm:px-4 text-xs relative overflow-hidden select-none z-30">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Left Live Indicator Badge */}
        <div className="flex items-center space-x-2 shrink-0">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-[10px] font-black uppercase tracking-wider bg-blue-600/30 text-blue-300 px-2 py-0.5 rounded-full border border-blue-500/40 flex items-center space-x-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>LIVE TICKER</span>
          </span>
        </div>

        {/* Marquee Flowing Content */}
        <div className="overflow-hidden flex-1 relative mask-fade-edges">
          <div className="animate-marquee whitespace-nowrap flex items-center space-x-12 font-medium text-slate-200 hover:[animation-play-state:paused]">
            {tickerNews.map((item) => (
              <span key={item.id} className="inline-flex items-center space-x-2 text-xs">
                <span className="font-black text-amber-400 uppercase tracking-tight">[{item.title}]</span>
                <span className="text-slate-200">{item.content}</span>
                <span className="text-blue-400 font-bold">•</span>
              </span>
            ))}
            {/* Duplicated for smooth loop */}
            {tickerNews.map((item) => (
              <span key={`dup-${item.id}`} className="inline-flex items-center space-x-2 text-xs">
                <span className="font-black text-amber-400 uppercase tracking-tight">[{item.title}]</span>
                <span className="text-slate-200">{item.content}</span>
                <span className="text-blue-400 font-bold">•</span>
              </span>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center space-x-3 shrink-0 text-[11px]">
          <Link
            to="/apply"
            className="hidden sm:inline-flex items-center space-x-1 text-emerald-400 hover:text-emerald-300 font-bold"
          >
            <span>Remote Team Slots</span>
            <ArrowRight className="w-3 h-3" />
          </Link>
          <button
            onClick={() => setDismissed(true)}
            className="text-slate-400 hover:text-white transition p-1"
            title="Dismiss bar"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
