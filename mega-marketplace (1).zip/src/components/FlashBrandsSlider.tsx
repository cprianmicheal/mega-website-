import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { 
  Flame, 
  ChevronLeft, 
  ChevronRight, 
  ShieldCheck, 
  ShoppingBag, 
  ExternalLink, 
  Sparkles, 
  Timer,
  Tag
} from 'lucide-react';
import { formatCurrency } from '../lib/utils';

export const FlashBrandsSlider: React.FC = () => {
  const products = useStore((state) => state.products);
  const stores = useStore((state) => state.stores);
  const addToCart = useStore((state) => state.addToCart);
  const addToast = useStore((state) => state.addToast);
  const sliderRef = useRef<HTMLDivElement>(null);

  // Real Brand Flash Deals with genuine TikTok accounts
  const flashDeals = [
    {
      id: 'prod-1',
      brandName: 'Apple Official',
      brandHandle: '@apple',
      tiktokUrl: 'https://www.tiktok.com/@apple',
      tiktokFollowers: '4.5M',
      title: 'MacBook Pro M3 Max 16" (48GB RAM, 1TB SSD)',
      image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&q=80&w=800',
      price: 3450000,
      originalPrice: 3850000,
      discountPct: 10,
      badge: 'Official Apple Care',
      stockRemaining: 3
    },
    {
      id: 'prod-4',
      brandName: 'Nike Athletics',
      brandHandle: '@nike',
      tiktokUrl: 'https://www.tiktok.com/@nike',
      tiktokFollowers: '6.8M',
      title: 'Nike Air Jordan 1 Retro High OG "Chicago Lost & Found"',
      image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80&w=800',
      price: 240000,
      originalPrice: 290000,
      discountPct: 17,
      badge: '100% Verified Authentic',
      stockRemaining: 5
    },
    {
      id: 'prod-2',
      brandName: 'Samsung Electronics',
      brandHandle: '@samsung',
      tiktokUrl: 'https://www.tiktok.com/@samsung',
      tiktokFollowers: '4.1M',
      title: 'Samsung Galaxy S24 Ultra 5G (512GB Titanium Black)',
      image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&q=80&w=800',
      price: 1850000,
      originalPrice: 2100000,
      discountPct: 12,
      badge: '24-Month Warranty',
      stockRemaining: 7
    },
    {
      id: 'prod-solar-1',
      brandName: 'Oraimo Official',
      brandHandle: '@oraimoclub',
      tiktokUrl: 'https://www.tiktok.com/@oraimoclub',
      tiktokFollowers: '1.8M',
      title: 'Oraimo PowerStation 3.5kVA Clean Solar Hybrid Inverter',
      image: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&q=80&w=800',
      price: 1450000,
      originalPrice: 1750000,
      discountPct: 17,
      badge: '365-Day Guarantee',
      stockRemaining: 4
    },
    {
      id: 'prod-3',
      brandName: 'Zara Luxury Atelier',
      brandHandle: '@zara',
      tiktokUrl: 'https://www.tiktok.com/@zara',
      tiktokFollowers: '9.2M',
      title: 'Zara Tailored Full-Grain Italian Leather Chelsea Boot',
      image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=800',
      price: 165000,
      originalPrice: 195000,
      discountPct: 15,
      badge: 'Bespoke European Cut',
      stockRemaining: 6
    }
  ];

  // Live countdown clock
  const [timeLeft, setTimeLeft] = useState({ hours: 4, minutes: 28, seconds: 45 });
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 6, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const scrollLeft = () => {
    if (sliderRef.current) {
      sliderRef.current.scrollBy({ left: -320, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (sliderRef.current) {
      sliderRef.current.scrollBy({ left: 320, behavior: 'smooth' });
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 p-6 sm:p-8 rounded-3xl border border-blue-500/30 text-white shadow-2xl relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 right-1/4 w-72 h-72 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-60 h-60 bg-red-600/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header with Title & Flash Countdown */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-white/10">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 to-amber-500 text-white flex items-center justify-center shadow-lg shadow-red-600/30 animate-pulse">
            <Flame className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">Flash Slider Feature</h2>
              <span className="bg-red-500 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-full tracking-wider animate-bounce">
                BRAND FLASH
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Limited-time verified brand flash discounts. Click TikTok handles to view official accounts directly!
            </p>
          </div>
        </div>

        {/* Live Flash Timer & Navigation */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-black/40 backdrop-blur-md px-3.5 py-1.5 rounded-2xl border border-white/15 text-xs font-mono font-bold text-amber-300">
            <Timer className="w-4 h-4 text-amber-400" />
            <span>
              {String(timeLeft.hours).padStart(2, '0')}h : {String(timeLeft.minutes).padStart(2, '0')}m : {String(timeLeft.seconds).padStart(2, '0')}s
            </span>
          </div>

          <div className="flex items-center space-x-1.5">
            <button
              onClick={scrollLeft}
              aria-label="Scroll left"
              className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition active:scale-95 border border-white/15"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={scrollRight}
              aria-label="Scroll right"
              className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition active:scale-95 border border-white/15"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Horizontal Sliding Cards */}
      <div 
        ref={sliderRef}
        className="relative z-10 flex space-x-4 overflow-x-auto no-scrollbar scroll-smooth pb-2"
        style={{ scrollSnapType: 'x mandatory' }}
      >
        {flashDeals.map((deal) => {
          const matchingProduct = products.find(p => p.id === deal.id);
          return (
            <div
              key={deal.id}
              className="min-w-[270px] sm:min-w-[310px] max-w-[320px] bg-slate-900/90 rounded-2xl border border-white/10 hover:border-blue-400/50 p-4 flex flex-col justify-between transition-all hover:shadow-xl group shrink-0"
              style={{ scrollSnapAlign: 'start' }}
            >
              <div>
                {/* Image and Badges */}
                <div className="relative aspect-[4/3] rounded-xl overflow-hidden mb-3 bg-slate-950">
                  <img
                    src={deal.image}
                    alt={deal.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-2.5 left-2.5 bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow-md">
                    -{deal.discountPct}% OFF
                  </div>

                  <div className="absolute top-2.5 right-2.5 bg-black/70 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded-full border border-white/20">
                    {deal.stockRemaining} left
                  </div>
                </div>

                {/* REAL BRAND TIKTOK LINK PILL (Direct entry to TikTok account) */}
                <div className="mb-2.5">
                  <a
                    href={deal.tiktokUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-1.5 bg-black hover:bg-zinc-900 border border-pink-500/40 hover:border-pink-400 px-2.5 py-1 rounded-xl text-[11px] font-bold text-white transition-all shadow-xs group/tiktok w-full justify-between"
                    title={`Open verified ${deal.brandName} TikTok account: ${deal.brandHandle}`}
                  >
                    <div className="flex items-center space-x-1.5 truncate">
                      <span className="w-4 h-4 rounded-md bg-gradient-to-tr from-[#00f2fe] to-[#fe0979] flex items-center justify-center text-[9px] font-black group-hover/tiktok:scale-110 transition-transform shrink-0">
                        ♪
                      </span>
                      <span className="truncate">{deal.brandName}</span>
                      <span className="text-[10px] text-pink-400 font-mono hidden sm:inline">{deal.brandHandle}</span>
                    </div>
                    <span className="text-[10px] bg-pink-500/20 text-pink-300 px-1.5 py-0.2 rounded shrink-0">
                      {deal.tiktokFollowers}
                    </span>
                  </a>
                </div>

                {/* Title */}
                <Link
                  to={`/product/${deal.id}`}
                  className="font-bold text-xs sm:text-sm text-white hover:text-blue-300 transition-colors line-clamp-2 leading-snug mb-2 block"
                >
                  {deal.title}
                </Link>

                <div className="flex items-center space-x-1 text-[11px] text-emerald-400 font-medium mb-3">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{deal.badge}</span>
                </div>
              </div>

              {/* Price & Action */}
              <div className="pt-3 border-t border-white/10 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400 line-through block">
                    {formatCurrency(deal.originalPrice)}
                  </span>
                  <span className="text-base font-black text-amber-400">
                    {formatCurrency(deal.price)}
                  </span>
                </div>

                <div className="flex items-center space-x-1.5">
                  <Link
                    to={`/product/${deal.id}`}
                    className="bg-white/10 hover:bg-white/20 text-white text-xs font-bold px-3 py-2 rounded-xl transition"
                  >
                    View
                  </Link>
                  {matchingProduct && (
                    <button
                      onClick={() => {
                        addToCart(matchingProduct);
                        addToast(`Added ${deal.title} to cart!`, 'success');
                      }}
                      className="bg-blue-600 hover:bg-blue-500 text-white p-2 rounded-xl transition shadow-md active:scale-95"
                      title="Add to Cart"
                    >
                      <ShoppingBag className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
