import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

export function ScrollToTop() {
  const { pathname, search } = useLocation();

  useEffect(() => {
    // Immediately jump straight to top of the page (header) on every navigation
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    
    // Also reset any scrollable main wrapper if present
    const mainEl = document.querySelector('main');
    if (mainEl) mainEl.scrollTop = 0;
    
    const rootEl = document.getElementById('root');
    if (rootEl) rootEl.scrollTop = 0;
  }, [pathname, search]);

  return null;
}
