import React, { useState } from 'react';
import { X, Sparkles, Send, ArrowRight, ShoppingBag } from 'lucide-react';
import { useStore } from '../store';
import { Product } from '../types';
import { formatCurrency } from '../lib/utils';
import { Link } from 'react-router-dom';

interface AIShoppingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  sender: 'ai' | 'user';
  text: string;
  recommendedProducts?: Product[];
}

export function AIShoppingModal({ isOpen, onClose }: AIShoppingModalProps) {
  const products = useStore(state => state.products);
  const addToCart = useStore(state => state.addToCart);

  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'ai',
      text: "Hello! I'm your Mega Marketplace AI shopping concierge. Tell me what you're looking for (e.g. 'I need a laptop for programming under ₦4,500,000' or 'Show me comfortable footwear for events').",
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);

  if (!isOpen) return null;

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim()) return;

    const userText = input.trim();
    const newMessages: Message[] = [...messages, { sender: 'user', text: userText }];
    setMessages(newMessages);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      // Smart matching against live marketplace items
      const queryLower = userText.toLowerCase();
      
      // Parse budget if mentioned
      const matches = products.filter(p => {
        const titleMatch = p.title.toLowerCase().includes(queryLower);
        const descMatch = p.description.toLowerCase().includes(queryLower);
        const catMatch = p.category?.toLowerCase().includes(queryLower);
        const tagMatch = p.tags?.some(t => queryLower.includes(t.toLowerCase()) || t.toLowerCase().includes(queryLower));
        
        // Keywords check
        const words = queryLower.split(' ');
        const anyWordMatch = words.some(w => w.length > 3 && (p.title.toLowerCase().includes(w) || p.tags?.some(t => t.includes(w))));

        return titleMatch || descMatch || catMatch || tagMatch || anyWordMatch;
      });

      let responseText = "";
      let matchedItems = matches.slice(0, 3);

      if (matchedItems.length > 0) {
        responseText = `I found ${matchedItems.length} verified item${matchedItems.length > 1 ? 's' : ''} in our marketplace that match your criteria:`;
      } else {
        matchedItems = products.slice(0, 2);
        responseText = `I couldn't find an exact match for "${userText}", but here are our top trending verified recommendations:`;
      }

      setMessages([
        ...newMessages,
        {
          sender: 'ai',
          text: responseText,
          recommendedProducts: matchedItems,
        }
      ]);
      setIsTyping(false);
    }, 600);
  };

  const handleQuickPrompt = (prompt: string) => {
    setInput(prompt);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-600 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-amber-300" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">AI Shopping Assistant</h3>
              <p className="text-xs text-blue-100">Live marketplace product search</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50 min-h-[300px]">
          {messages.map((m, idx) => (
            <div key={idx} className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}>
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-blue-600 text-white rounded-br-xs shadow-xs'
                    : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-xs shadow-xs'
                }`}
              >
                {m.text}
              </div>

              {/* Render product recommendation cards */}
              {m.recommendedProducts && m.recommendedProducts.length > 0 && (
                <div className="mt-3 w-full space-y-2">
                  {m.recommendedProducts.map((prod) => (
                    <div key={prod.id} className="bg-white p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between shadow-xs hover:border-blue-300 transition-all">
                      <div className="flex items-center space-x-3">
                        <img src={prod.images[0]} alt={prod.title} className="w-12 h-12 object-cover rounded-xl bg-slate-100" />
                        <div>
                          <h4 className="font-semibold text-xs text-slate-900 line-clamp-1">{prod.title}</h4>
                          <span className="font-bold text-xs text-blue-600">
                            {formatCurrency(prod.discount_price || prod.price)}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1.5">
                        <button
                          onClick={() => addToCart(prod, 1)}
                          title="Add to cart"
                          className="p-2 rounded-xl bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white transition-colors"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                        </button>
                        <Link
                          to={`/product/${prod.slug}`}
                          onClick={onClose}
                          className="p-2 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors"
                        >
                          <ArrowRight className="w-3.5 h-3.5" />
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center space-x-1.5 text-xs text-slate-400 bg-white px-3 py-2 rounded-xl border border-slate-200 w-fit">
              <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce"></span>
              <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.2s]"></span>
              <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.4s]"></span>
              <span className="ml-1 text-slate-500 font-medium">Searching live stock...</span>
            </div>
          )}
        </div>

        {/* Suggested Prompts */}
        <div className="px-4 py-2 bg-white border-t border-slate-100 flex space-x-2 overflow-x-auto no-scrollbar">
          {['MacBook for programming', 'Shoes under ₦50,000', 'Noise cancelling headphones', 'Office chair'].map((tag) => (
            <button
              key={tag}
              onClick={() => handleQuickPrompt(tag)}
              className="text-[11px] font-medium whitespace-nowrap px-3 py-1 bg-slate-100 hover:bg-blue-50 hover:text-blue-600 text-slate-600 rounded-full transition-colors"
            >
              {tag}
            </button>
          ))}
        </div>

        {/* Input Footer */}
        <form onSubmit={handleSend} className="p-3 bg-white border-t border-slate-100 flex items-center space-x-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask AI shopping assistant..."
            className="flex-1 bg-slate-100 text-sm px-4 py-2.5 rounded-xl border border-transparent focus:border-blue-500 focus:bg-white focus:outline-none"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="bg-blue-600 text-white p-2.5 rounded-xl hover:bg-blue-700 disabled:opacity-40 transition-all"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
