import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { Store } from '../types';
import { 
  ShieldCheck, 
  Star, 
  ChevronLeft, 
  ChevronRight, 
  ArrowRight, 
  Sparkles, 
  Users, 
  MapPin, 
  CheckCircle2 
} from 'lucide-react';

interface VerifiedBrandsSliderProps {
  autoPlayInterval?: number;
}

export const VerifiedBrandsSlider: React.FC<VerifiedBrandsSliderProps> = ({ autoPlayInterval = 5000 }) => {
  const stores = useStore((state) => state.stores);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Real verified brand profiles with authentic TikTok accounts
  const brandsList: Array<Store & { highlight: string; accentColor: string; tags: string[] }> = [
    {
      ...stores[0] || {
        id: 'store-1',
        owner_id: 'usr-2',
        name: 'Apple Official Store',
        description: 'Direct authorized distributor of Apple Inc. Flagship iPhone 16 Pro, M3 Max MacBooks, iPads & AirPods Max with 1-year global Apple Care warranty.',
        logo_url: 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&q=80&w=300',
        cover_url: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&q=80&w=1200',
        is_verified: true,
        rating: 4.95,
        reviews_count: 1420,
        followers_count: 4500000,
        tiktok_url: 'https://www.tiktok.com/@apple',
        tiktok_handle: '@apple',
        tiktok_followers: '4.5M',
        location: 'Apple Authorized Hub, Victoria Island, Lagos & Ankpa Tech Plaza',
        status: 'active',
        created_at: '2026-01-15T08:00:00Z',
      },
      name: stores[0]?.name || 'Apple Official Store',
      description: stores[0]?.description || 'Direct authorized distributor of Apple Inc. Flagship iPhone 16 Pro, M3 Max MacBooks, iPads & AirPods Max with 1-year global Apple Care warranty.',
      logo_url: stores[0]?.logo_url || 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&q=80&w=300',
      tiktok_url: stores[0]?.tiktok_url || 'https://www.tiktok.com/@apple',
      tiktok_handle: stores[0]?.tiktok_handle || '@apple',
      tiktok_followers: stores[0]?.tiktok_followers || '4.5M',
      location: stores[0]?.location || 'Apple Authorized Hub, Victoria Island, Lagos & Ankpa Tech Plaza',
      brand_color: 'from-slate-950 via-zinc-900 to-slate-900',
      accentColor: 'text-zinc-300 border-zinc-500/40 bg-zinc-500/10',
      highlight: 'Official Apple Authorized Partner • 1-Year Global Warranty',
      tags: ['iPhone 16 Pro Max', 'MacBook Pro M3', 'AirPods Max', 'Apple Care']
    },
    {
      ...stores[1] || {
        id: 'store-2',
        owner_id: 'usr-3',
        name: 'Nike Official Athletics',
        description: 'Official Nike Sports & Athletics Distributor. Authentic Air Jordan 1 Retros, Nike Dunk Lows, Dri-FIT running gear & performance footwear with zero counterfeit guarantee.',
        logo_url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=300',
        cover_url: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80&w=1200',
        is_verified: true,
        rating: 4.9,
        reviews_count: 980,
        followers_count: 6800000,
        tiktok_url: 'https://www.tiktok.com/@nike',
        tiktok_handle: '@nike',
        tiktok_followers: '6.8M',
        location: 'Palms Mall, Lekki & Commercial Avenue, Ankpa, Nigeria',
        status: 'active',
        created_at: '2026-02-01T10:00:00Z',
      },
      name: stores[1]?.name || 'Nike Official Athletics',
      description: stores[1]?.description || 'Official Nike Sports & Athletics Distributor. Authentic Air Jordan 1 Retros, Nike Dunk Lows, Dri-FIT running gear & performance footwear with zero counterfeit guarantee.',
      logo_url: stores[1]?.logo_url || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=300',
      tiktok_url: stores[1]?.tiktok_url || 'https://www.tiktok.com/@nike',
      tiktok_handle: stores[1]?.tiktok_handle || '@nike',
      tiktok_followers: stores[1]?.tiktok_followers || '6.8M',
      location: stores[1]?.location || 'Palms Mall, Lekki & Commercial Avenue, Ankpa, Nigeria',
      brand_color: 'from-slate-950 via-red-950 to-neutral-900',
      accentColor: 'text-red-400 border-red-500/40 bg-red-500/10',
      highlight: '100% Verified Authentic Nike & Air Jordan Partner',
      tags: ['Air Jordan 1', 'Nike Dunks', 'Dri-FIT Pro', 'Verified Genuine']
    },
    {
      ...stores[2] || {
        id: 'store-3',
        owner_id: 'usr-1',
        name: 'Samsung Electronics Experience',
        description: 'Direct Authorized Samsung Experience Store. Galaxy S24 Ultra AI, Galaxy Z Fold 6, Neo QLED Smart TVs & Smart Home appliances with 24-month manufacturer warranty.',
        logo_url: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&q=80&w=300',
        cover_url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=1200',
        is_verified: true,
        rating: 4.88,
        reviews_count: 730,
        followers_count: 4100000,
        tiktok_url: 'https://www.tiktok.com/@samsung',
        tiktok_handle: '@samsung',
        tiktok_followers: '4.1M',
        location: 'Samsung Experience Center, Ikeja City Mall & Otukpo Road, Ankpa',
        status: 'active',
        created_at: '2026-02-10T12:00:00Z',
      },
      name: stores[2]?.name || 'Samsung Electronics Experience',
      description: stores[2]?.description || 'Direct Authorized Samsung Experience Store. Galaxy S24 Ultra AI, Galaxy Z Fold 6, Neo QLED Smart TVs & Smart Home appliances with 24-month manufacturer warranty.',
      logo_url: stores[2]?.logo_url || 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&q=80&w=300',
      tiktok_url: stores[2]?.tiktok_url || 'https://www.tiktok.com/@samsung',
      tiktok_handle: stores[2]?.tiktok_handle || '@samsung',
      tiktok_followers: stores[2]?.tiktok_followers || '4.1M',
      location: stores[2]?.location || 'Samsung Experience Center, Ikeja City Mall & Otukpo Road, Ankpa',
      brand_color: 'from-slate-950 via-blue-950 to-slate-900',
      accentColor: 'text-blue-400 border-blue-500/40 bg-blue-500/10',
      highlight: 'Official Samsung Experience • 24-Month Warranty',
      tags: ['Galaxy S24 Ultra', 'Z Fold 6', 'Galaxy Buds3 Pro', '2-Year Warranty']
    },
    {
      ...stores[3] || {
        id: 'store-4',
        owner_id: 'usr-1',
        name: 'Oraimo Official Brand Store',
        description: 'Official Oraimo Sound, Smart Energy & Clean Solar Distributor. FreePods 4, 30,000mAh Power Banks, Smart Inverter Solar stations & phone accessories with 365-day warranty.',
        logo_url: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&q=80&w=300',
        cover_url: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&q=80&w=1200',
        is_verified: true,
        rating: 4.85,
        reviews_count: 620,
        followers_count: 1800000,
        tiktok_url: 'https://www.tiktok.com/@oraimoclub',
        tiktok_handle: '@oraimoclub',
        tiktok_followers: '1.8M',
        location: 'Computer Village, Ikeja & Main Market Square, Ankpa, Nigeria',
        status: 'active',
        created_at: '2026-02-18T12:00:00Z',
      },
      name: stores[3]?.name || 'Oraimo Official Brand Store',
      description: stores[3]?.description || 'Official Oraimo Sound, Smart Energy & Clean Solar Distributor. FreePods 4, 30,000mAh Power Banks, Smart Inverter Solar stations & phone accessories with 365-day warranty.',
      logo_url: stores[3]?.logo_url || 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&q=80&w=300',
      tiktok_url: stores[3]?.tiktok_url || 'https://www.tiktok.com/@oraimoclub',
      tiktok_handle: stores[3]?.tiktok_handle || '@oraimoclub',
      tiktok_followers: stores[3]?.tiktok_followers || '1.8M',
      location: stores[3]?.location || 'Computer Village, Ikeja & Main Market Square, Ankpa, Nigeria',
      brand_color: 'from-slate-950 via-emerald-950 to-teal-950',
      accentColor: 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10',
      highlight: 'Official Oraimo Sound & Smart Solar Energy Hub',
      tags: ['FreePods 4 Pro', 'Power Banks 30k', 'Solar Inverter', 'Animate Audio']
    },
    {
      ...stores[4] || {
        id: 'store-5',
        owner_id: 'usr-3',
        name: 'Zara Fashion & Luxury Atelier',
        description: 'Contemporary European Haute Couture, tailored Italian blazers, full-grain leather goods, designer footwear & bespoke luxury streetwear.',
        logo_url: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=300',
        cover_url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=1200',
        is_verified: true,
        rating: 4.92,
        reviews_count: 1150,
        followers_count: 9200000,
        tiktok_url: 'https://www.tiktok.com/@zara',
        tiktok_handle: '@zara',
        tiktok_followers: '9.2M',
        location: 'Luxury Galleria, Victoria Island / Fast Express Dispatch',
        status: 'active',
        created_at: '2026-02-25T12:00:00Z',
      },
      name: stores[4]?.name || 'Zara Fashion & Luxury Atelier',
      description: stores[4]?.description || 'Contemporary European Haute Couture, tailored Italian blazers, full-grain leather goods, designer footwear & bespoke luxury streetwear.',
      logo_url: stores[4]?.logo_url || 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=300',
      tiktok_url: stores[4]?.tiktok_url || 'https://www.tiktok.com/@zara',
      tiktok_handle: stores[4]?.tiktok_handle || '@zara',
      tiktok_followers: stores[4]?.tiktok_followers || '9.2M',
      location: stores[4]?.location || 'Luxury Galleria, Victoria Island / Fast Express Dispatch',
      brand_color: 'from-slate-950 via-purple-950 to-rose-950',
      accentColor: 'text-purple-400 border-purple-500/40 bg-purple-500/10',
      highlight: 'Curated European High-Fashion & Bespoke Wardrobe',
      tags: ['Italian Leather', 'Bespoke Blazers', 'Luxury Footwear', 'Same-Day Dispatch']
    }
  ];

  // Auto-play timer
  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % brandsList.length);
    }, autoPlayInterval);
    return () => clearInterval(timer);
  }, [isPaused, autoPlayInterval, brandsList.length]);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? brandsList.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % brandsList.length);
  };

  const currentBrand = brandsList[currentIndex];

  return (
    <div 
      id="verified-brands-slider"
      className="relative rounded-3xl overflow-hidden shadow-2xl transition-all duration-700 select-none"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Background Gradient Container with Dynamic Brand Theme */}
      <div className={`w-full bg-gradient-to-r ${currentBrand.brand_color} text-white p-6 sm:p-10 md:p-12 relative overflow-hidden transition-all duration-700 min-h-[360px] sm:min-h-[380px] flex flex-col justify-between`}>
        {/* Ambient glow effects */}
        <div className="absolute -top-16 -right-16 w-80 h-80 bg-white/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-80 h-80 bg-white/5 rounded-full blur-2xl pointer-events-none" />

        {/* Top Tag & Store Switcher Indicators */}
        <div className="relative z-10 flex items-center justify-between gap-4">
          <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-md border border-white/20 px-3.5 py-1.5 rounded-full text-xs font-bold">
            <ShieldCheck className="w-4 h-4 text-amber-300" />
            <span className="text-amber-200">Verified Brand Spotlight • #{currentIndex + 1} of {brandsList.length}</span>
          </div>

          {/* Slide Indicators / Navigation Pills */}
          <div className="flex items-center space-x-2">
            {brandsList.map((_, idx) => (
              <button
                key={idx}
                id={`brand-dot-${idx}`}
                onClick={() => setCurrentIndex(idx)}
                aria-label={`Go to brand ${idx + 1}`}
                className={`h-2 rounded-full transition-all duration-300 ${
                  currentIndex === idx ? 'w-8 bg-white shadow-sm' : 'w-2 bg-white/30 hover:bg-white/60'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Brand Body Info */}
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center my-4">
          <div className="lg:col-span-8 space-y-4">
            <div className="flex items-center space-x-4">
              <img
                src={currentBrand.logo_url}
                alt={currentBrand.name}
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = 'https://ui-avatars.com/api/?name=Brand&background=random';
                }}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-white/30 shadow-xl bg-white shrink-0"
              />
              <div>
                <div className="flex items-center space-x-2">
                  <h3 className="text-2xl sm:text-3xl font-black tracking-tight text-white">{currentBrand.name}</h3>
                  {currentBrand.is_verified && (
                    <span className="bg-blue-500 text-white p-1 rounded-full text-xs shadow-xs">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 mt-1">
                  <span className="flex items-center text-amber-400 font-bold">
                    <Star className="w-3.5 h-3.5 fill-current mr-1" />
                    {currentBrand.rating || '4.9'} ({currentBrand.reviews_count || '250+'} Reviews)
                  </span>
                  <span>•</span>
                  <span className="flex items-center text-slate-300">
                    <Users className="w-3.5 h-3.5 mr-1" />
                    {currentBrand.followers_count || '1,200'} Followers
                  </span>
                  <span>•</span>
                  <span className="flex items-center text-slate-300">
                    <MapPin className="w-3.5 h-3.5 mr-1" />
                    {currentBrand.location || 'Lagos, Nigeria'}
                  </span>
                </div>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-200/90 leading-relaxed max-w-2xl font-medium">
              {currentBrand.description}
            </p>

            {/* Brand Tags */}
            <div className="flex flex-wrap gap-2 pt-1">
              {currentBrand.tags.map((tag, tIdx) => (
                <span
                  key={tIdx}
                  className="bg-white/10 backdrop-blur-xs border border-white/15 text-[11px] font-semibold px-2.5 py-1 rounded-lg text-white"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Action Column with TikTok & Store Entry */}
          <div className="lg:col-span-4 flex flex-col space-y-3">
            {/* TikTok Account Connection Button */}
            {currentBrand.tiktok_url && (
              <a
                href={currentBrand.tiktok_url}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-black/90 hover:bg-black text-white font-black px-6 py-3.5 rounded-2xl text-xs sm:text-sm transition-all shadow-xl active:scale-95 flex items-center justify-center space-x-2.5 border border-pink-500/40 hover:border-pink-500 text-center group"
                title={`Follow ${currentBrand.name} on TikTok: ${currentBrand.tiktok_handle}`}
              >
                <span className="w-5 h-5 rounded-lg bg-gradient-to-tr from-[#00f2fe] to-[#fe0979] flex items-center justify-center text-white text-[10px] font-black group-hover:scale-110 transition-transform">
                  ♪
                </span>
                <span>Follow on TikTok ({currentBrand.tiktok_followers || '1K+'})</span>
                <span className="text-[10px] text-pink-400 font-mono hidden sm:inline">{currentBrand.tiktok_handle}</span>
              </a>
            )}

            <Link
              to={`/explore?store=${currentBrand.id}`}
              className="bg-white hover:bg-slate-100 text-slate-900 font-extrabold px-6 py-3.5 rounded-2xl text-xs sm:text-sm transition-all shadow-xl active:scale-95 flex items-center justify-center space-x-2 text-center"
            >
              <span>Explore Official Store</span>
              <ArrowRight className="w-4 h-4" />
            </Link>

            <Link
              to="/account?mode=signup&role=seller&action=register_brand"
              className="bg-white/15 hover:bg-white/25 text-white font-bold px-6 py-3 rounded-2xl text-xs border border-white/20 transition-all active:scale-95 flex items-center justify-center space-x-2 text-center"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Register Your Brand & Begin Sales</span>
            </Link>
          </div>
        </div>

        {/* Bottom Slide Controller Buttons */}
        <div className="relative z-10 flex items-center justify-between pt-2 border-t border-white/10">
          <div className="text-[11px] text-slate-300/80 font-medium">
            <strong className="text-white">{currentBrand.highlight}</strong>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrev}
              aria-label="Previous verified brand"
              className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all active:scale-95 border border-white/15 backdrop-blur-xs"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleNext}
              aria-label="Next verified brand"
              className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all active:scale-95 border border-white/15 backdrop-blur-xs"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
