import { UserAvatar } from './UserAvatar';
import React, { useState, useEffect } from 'react';
import { Outlet, NavLink, Link, useNavigate, useLocation } from 'react-router-dom';
import { ScrollToTop } from './ScrollToTop';
import { 
  Home, 
  Compass, 
  PlusCircle, 
  ShoppingCart, 
  User as UserIcon, 
  Heart, 
  Sparkles, 
  Shield, 
  Search, 
  Globe, 
  LogIn, 
  LogOut,
  ChevronDown,
  Camera,
  MapPin
} from 'lucide-react';
import { useStore } from '../store';
import { cn, CURRENCIES } from '../lib/utils';
import { AIShoppingModal } from './AIShoppingModal';
import { ToastContainer } from './ToastContainer';
import { CurrencyModal } from './CurrencyModal';
import { AuthModal } from './AuthModal';
import { AvatarUploadModal } from './AvatarUploadModal';
import { PhoneNotificationModal } from './PhoneNotificationModal';
import { Footer } from './Footer';

export function Layout() {
  const navigate = useNavigate();
  const location = useLocation();
  const cart = useStore((state) => state.cart);
  const wishlist = useStore((state) => state.wishlist);
  const user = useStore((state) => state.user);
  const isAuthenticated = useStore((state) => state.isAuthenticated);
  const currency = useStore((state) => state.currency);
  const logoutUser = useStore((state) => state.logoutUser);

  const [isAiOpen, setIsAiOpen] = useState(false);
  const [isCurrencyModalOpen, setIsCurrencyModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup'>('login');
  const [headerSearch, setHeaderSearch] = useState('');

  // Handle /#admin secret URL access
  useEffect(() => {
    const handleHashCheck = () => {
      const hash = window.location.hash.toLowerCase();
      if (hash === '#admin' || hash === '#/admin') {
        navigate('/admin/super');
      }
    };

    handleHashCheck();
    window.addEventListener('hashchange', handleHashCheck);
    return () => window.removeEventListener('hashchange', handleHashCheck);
  }, [navigate, location]);

  const cartItemCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const wishlistCount = wishlist.length;
  const currentCurrencyConfig = CURRENCIES[currency] || CURRENCIES.NGN;

  const handleHeaderSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (headerSearch.trim()) {
      navigate(`/explore?q=${encodeURIComponent(headerSearch.trim())}`);
    }
  };

  const openSignIn = () => {
    setAuthModalMode('login');
    setIsAuthModalOpen(true);
  };

  const openSignUp = () => {
    setAuthModalMode('signup');
    setIsAuthModalOpen(true);
  };

  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: Compass, label: 'Explore', path: '/explore' },
    { icon: PlusCircle, label: 'Sell', path: '/sell', isHighlight: true },
    { icon: Heart, label: 'Wishlist', path: '/wishlist', badge: wishlistCount > 0 ? wishlistCount : undefined },
    { icon: ShoppingCart, label: 'Cart', path: '/cart', badge: cartItemCount > 0 ? cartItemCount : undefined },
    { icon: UserIcon, label: 'Account', path: '/account' },
  ];

  return (
    <div className="min-h-screen app-world-class-bg flex flex-col font-sans text-slate-900 selection:bg-blue-600 selection:text-white relative overflow-x-hidden">
      <ScrollToTop />
      {/* Ambient World-Class Background Lighting Decor */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden" aria-hidden="true">
        <div className="absolute -top-40 left-1/4 w-[650px] h-[650px] bg-blue-400/10 rounded-full blur-[140px]" />
        <div className="absolute top-1/3 -right-40 w-[550px] h-[550px] bg-indigo-300/10 rounded-full blur-[120px]" />
        <div className="absolute -bottom-20 left-1/3 w-[600px] h-[600px] bg-sky-200/15 rounded-full blur-[140px]" />
      </div>


      {/* Clean Header Top Bar */}
      <div className="relative z-10 bg-slate-900 text-white text-xs py-2 px-4 text-center font-medium flex items-center justify-between border-b border-slate-800 shadow-xs">
        <div className="hidden sm:flex items-center space-x-2 text-[11px] text-slate-300">
          <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0" />
          <span>Hub: <strong>Ankpa, Kogi State, Nigeria</strong> (Nationwide Courier Transit)</span>
        </div>
        <div className="flex-1 flex items-center justify-center space-x-2 text-center text-xs">
          <span className="bg-blue-600/30 text-blue-300 border border-blue-500/40 text-[10px] uppercase font-bold px-2 py-0.5 rounded-full">Official Notice</span>
          <span className="text-slate-200">Official Settlement Account: <strong>UBA 2311406173</strong> (CYPRIAN MICHAEL OJOCHOGWU)</span>
        </div>
        <div className="hidden sm:flex items-center space-x-2">
          <button
            onClick={() => setIsCurrencyModalOpen(true)}
            className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors border border-slate-700 text-slate-200"
          >
            <span>{currentCurrencyConfig.flag}</span>
            <span>{currentCurrencyConfig.code} ({currentCurrencyConfig.symbol})</span>
            <ChevronDown className="w-3 h-3 opacity-70" />
          </button>
        </div>
      </div>

      {/* Desktop Header */}
      <header className="hidden md:flex h-20 bg-white/95 backdrop-blur-md border-b border-slate-200/80 items-center justify-between px-8 sticky top-0 z-40">
        <div className="flex items-center space-x-8">
          <Link to="/" className="flex items-center space-x-2.5 group">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-700 to-blue-500 flex items-center justify-center text-white font-black text-xl shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              M
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-2xl tracking-tighter text-slate-900 leading-none">
                MEGA<span className="text-blue-600">.</span>
              </span>
              <span className="text-[10px] font-bold uppercase tracking-widest text-blue-600">Marketplace</span>
            </div>
          </Link>

          {/* Search bar inside desktop header */}
          <form onSubmit={handleHeaderSearch} className="relative w-72 lg:w-88">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={headerSearch}
              onChange={(e) => setHeaderSearch(e.target.value)}
              placeholder="Search gadgets, sneakers, solar..."
              className="w-full bg-slate-100/90 text-xs font-medium pl-10 pr-4 py-2.5 rounded-xl border border-transparent focus:border-blue-500 focus:bg-white focus:outline-none transition-all"
            />
          </form>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-4 lg:space-x-6">
          {/* Currency Trigger */}
          <button
            onClick={() => setIsCurrencyModalOpen(true)}
            className="flex items-center space-x-1.5 text-xs font-bold px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-all"
            title="Switch Global Currency"
          >
            <span className="text-base">{currentCurrencyConfig.flag}</span>
            <span>{currentCurrencyConfig.code}</span>
            <Globe className="w-3.5 h-3.5 text-slate-400 ml-0.5" />
          </button>



          {/* AI Shopping Assistant Button */}
          <button
            onClick={() => setIsAiOpen(true)}
            className="flex items-center space-x-1.5 text-xs font-bold px-3.5 py-2 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 transition-all shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>AI Assistant</span>
          </button>

          {/* Navigation Links */}
          <nav className="flex space-x-4 lg:space-x-6 items-center">
            {navItems.slice(0, 3).map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  cn(
                    "flex items-center space-x-1.5 text-xs lg:text-sm font-semibold transition-colors relative py-1",
                    isActive ? "text-blue-600 font-bold" : "text-slate-600 hover:text-blue-600"
                  )
                }
              >
                <item.icon className={cn("w-4 h-4", item.isHighlight ? "text-blue-600" : "")} />
                <span>{item.label}</span>
              </NavLink>
            ))}

            {/* Wishlist Nav Button */}
            <NavLink
              to="/wishlist"
              className={({ isActive }) =>
                cn(
                  "flex items-center space-x-1.5 text-xs lg:text-sm font-semibold transition-colors relative py-1",
                  isActive ? "text-blue-600 font-bold" : "text-slate-600 hover:text-blue-600"
                )
              }
            >
              <Heart className="w-4 h-4 text-rose-500" />
              <span>Wishlist</span>
              {wishlistCount > 0 && (
                <span className="bg-rose-500 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                  {wishlistCount}
                </span>
              )}
            </NavLink>

            {/* Cart Nav Button */}
            <NavLink
              to="/cart"
              className={({ isActive }) =>
                cn(
                  "flex items-center space-x-1.5 text-xs lg:text-sm font-semibold transition-colors relative py-1",
                  isActive ? "text-blue-600 font-bold" : "text-slate-600 hover:text-blue-600"
                )
              }
            >
              <ShoppingCart className="w-4 h-4 text-blue-600" />
              <span>Cart</span>
              {cartItemCount > 0 && (
                <span className="bg-blue-600 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                  {cartItemCount}
                </span>
              )}
            </NavLink>

            {/* User Account / Auth Trigger */}
            {isAuthenticated ? (
              <div className="flex items-center space-x-2 pl-2 border-l border-slate-200">
                {/* Clickable Profile Avatar to trigger Instant Drag & Drop Avatar Modal */}
                <button
                  onClick={() => setIsAvatarModalOpen(true)}
                  className="relative group cursor-pointer"
                  title="Click to Drag & Drop or Change Photo"
                >
                  <UserAvatar
                    src={user.avatar_url}
                    alt={user.full_name}
                    className="w-9 h-9 rounded-full border-2 border-blue-500 shadow-xs group-hover:ring-2 ring-blue-400 group-hover:scale-105 transition-all"
                  />
                  <span className="absolute -bottom-1 -right-1 bg-blue-600 text-white p-0.5 rounded-full text-[9px] shadow-xs">
                    <Camera className="w-2.5 h-2.5" />
                  </span>
                </button>

                <Link
                  to="/account"
                  className="flex flex-col text-left group"
                >
                  <span className="text-xs font-bold text-slate-900 group-hover:text-blue-600 truncate max-w-[90px]">
                    {user.full_name.split(' ')[0]}
                  </span>
                  <span className="text-[10px] text-blue-600 font-semibold uppercase">{user.role}</span>
                </Link>
              </div>
            ) : (
              <div className="flex items-center space-x-2 pl-2 border-l border-slate-200">
                <button
                  onClick={openSignIn}
                  className="text-xs font-bold text-slate-700 hover:text-blue-600 px-2 py-1"
                >
                  Log In
                </button>
                <button
                  onClick={openSignUp}
                  className="text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 rounded-xl shadow-xs transition-all"
                >
                  Create Account
                </button>
              </div>
            )}
          </nav>
        </div>
      </header>

      {/* Mobile Top Header */}
      <div className="md:hidden bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 py-3 sticky top-0 z-40 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white font-black text-sm">
            M
          </div>
          <div className="flex flex-col">
            <span className="font-extrabold text-base text-slate-900 tracking-tight leading-none">
              MEGA<span className="text-blue-600">.</span>
            </span>
            <span className="text-[9px] text-slate-500 font-bold">Ankpa, Kogi</span>
          </div>
        </Link>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsCurrencyModalOpen(true)}
            className="p-1.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-bold flex items-center space-x-1"
          >
            <span>{currentCurrencyConfig.flag}</span>
            <span>{currentCurrencyConfig.code}</span>
          </button>



          <button
            onClick={() => setIsAiOpen(true)}
            className="p-2 rounded-xl bg-blue-50 text-blue-700 text-xs font-bold"
          >
            <Sparkles className="w-4 h-4" />
          </button>

          {!isAuthenticated ? (
            <button
              onClick={openSignIn}
              className="bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-xl shadow-xs"
            >
              Log In
            </button>
          ) : (
            <button 
              onClick={() => setIsAvatarModalOpen(true)}
              className="relative"
              title="Change Profile Photo"
            >
              <UserAvatar
                src={user.avatar_url}
                alt={user.full_name}
                className="w-8 h-8 rounded-full border border-blue-600"
              />
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-12 relative">
        <Outlet />
      </main>

      {/* Massive Footer Section */}
      <Footer 
        onOpenCurrencyModal={() => setIsCurrencyModalOpen(true)} 
        onOpenAuthModal={openSignIn}
      />

      {/* Mobile Floating AI Assistant Trigger */}
      <button
        onClick={() => setIsAiOpen(true)}
        className="md:hidden fixed bottom-20 right-4 z-40 bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-3 rounded-full shadow-lg shadow-blue-600/30 flex items-center justify-center active:scale-95 transition-transform"
        aria-label="Open AI Shopping Assistant"
      >
        <Sparkles className="w-5 h-5 animate-pulse" />
      </button>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="md:hidden fixed bottom-0 w-full bg-white/95 backdrop-blur-md border-t border-slate-200 flex justify-around items-center h-16 pb-safe z-40 shadow-[0_-4px_24px_rgba(0,0,0,0.06)]">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              cn(
                "flex flex-col items-center justify-center w-full h-full space-y-1 relative transition-colors",
                isActive ? "text-blue-600 font-bold" : "text-slate-400 hover:text-slate-600 font-medium"
              )
            }
          >
            <div className="relative">
              <item.icon className={cn("w-5 h-5 stroke-[2.2px]", item.isHighlight ? "text-blue-600 scale-110" : "")} />
              {item.badge ? (
                <span className="absolute -top-1.5 -right-2.5 bg-blue-600 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold border-2 border-white">
                  {item.badge}
                </span>
              ) : null}
            </div>
            <span className="text-[10px] tracking-tight">{item.label}</span>
          </NavLink>
        ))}
      </nav>

      {/* Modals & Portals */}
      <AIShoppingModal isOpen={isAiOpen} onClose={() => setIsAiOpen(false)} />
      <CurrencyModal isOpen={isCurrencyModalOpen} onClose={() => setIsCurrencyModalOpen(false)} />
      <AvatarUploadModal 
        isOpen={isAvatarModalOpen} 
        onClose={() => setIsAvatarModalOpen(false)} 
      />
      <PhoneNotificationModal />
      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
        initialMode={authModalMode}
      />

      <ToastContainer />
    </div>
  );
}
