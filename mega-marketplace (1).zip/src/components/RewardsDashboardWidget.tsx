import React, { useState } from 'react';
import { useStore } from '../store';
import { formatCurrency } from '../lib/utils';
import { 
  Gift, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Share2, 
  Copy, 
  Check, 
  Sparkles, 
  ArrowUpRight, 
  Building2, 
  CreditCard, 
  Award, 
  Flame, 
  CheckCircle2, 
  Clock, 
  ChevronRight, 
  MessageSquare, 
  QrCode,
  Zap,
  ShieldCheck,
  Percent,
  Download
} from 'lucide-react';
import { BankAccountDetails } from '../types';

export default function RewardsDashboardWidget() {
  const { 
    user, 
    orders, 
    rewardActivities, 
    claimReward, 
    claimAllRewards, 
    claimDailyStreakReward, 
    requestDirectBankCashout, 
    currency, 
    addToast 
  } = useStore();

  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [filterType, setFilterType] = useState<'all' | 'referral' | 'sales' | 'cashback'>('all');
  const [showCashoutModal, setShowCashoutModal] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);

  // Bank Cashout Form State
  const [cashoutAmount, setCashoutAmount] = useState('');
  const [bankName, setBankName] = useState(user.bank_details?.bank_name || 'Guaranty Trust Bank (GTBank)');
  const [accountNumber, setAccountNumber] = useState(user.bank_details?.account_number || '');
  const [accountName, setAccountName] = useState(user.bank_details?.account_name || user.full_name);

  // Referral Calculations
  const referralCount = user.referral_count || 0;
  const baseReferralEarnings = referralCount * 1000;
  const userActivities = rewardActivities.filter(r => r.user_id === user.id || !r.user_id || r.user_id === 'usr-1');
  
  const referralCommissionTotal = userActivities
    .filter(r => r.type === 'referral_signup' || r.type === 'referral_order_commission')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalReferralRewards = Math.max(baseReferralEarnings, referralCommissionTotal);

  // Sales Activity Calculations (for merchant / store owners)
  const salesEarningsFromActivities = userActivities
    .filter(r => r.type === 'sales_payout')
    .reduce((acc, curr) => acc + curr.amount, 0);

  // Calculate from user's store orders if applicable
  const userStoreSales = orders
    .filter(o => o.status === 'delivered' || o.status === 'paid' || o.status === 'in_transit')
    .reduce((acc, curr) => acc + (curr.seller_payout_amount || curr.total_amount * 0.95), 0);

  const totalSalesRewards = (user.sales_earnings || 0) + salesEarningsFromActivities + (user.role === 'seller' ? Math.round(userStoreSales * 0.1) : 0);

  // Cashback and Daily Streak Rewards
  const cashbackTotal = (user.cashback_earnings || 0) + userActivities
    .filter(r => r.type === 'cashback' || r.type === 'daily_streak' || r.type === 'vip_milestone')
    .reduce((acc, curr) => acc + curr.amount, 0);

  // Total Cumulative Rewards
  const totalCumulativeRewards = totalReferralRewards + totalSalesRewards + cashbackTotal;

  // Available (Unclaimed) Rewards in the pool
  const availableUnclaimed = userActivities
    .filter(r => r.status === 'available')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalClaimedSoFar = (user.claimed_rewards || 0) + userActivities
    .filter(r => r.status === 'claimed')
    .reduce((acc, curr) => acc + curr.amount, 0);

  // Referral Link
  const referralCode = user.referral_code || 'CYPRIAN2026';
  const referralLink = `${window.location.origin}/join?ref=${referralCode}`;

  // Affiliate VIP Tier Calculation
  const getVipTier = (count: number) => {
    if (count >= 30) return { name: 'Diamond VIP', commission: '7.5%', nextTier: 'Max Tier', needed: 0, progress: 100, color: 'from-purple-600 to-indigo-600' };
    if (count >= 15) return { name: 'Gold Affiliate', commission: '5.0%', nextTier: 'Diamond VIP', needed: 30 - count, progress: Math.round((count / 30) * 100), color: 'from-amber-500 to-amber-700' };
    if (count >= 5) return { name: 'Silver Partner', commission: '3.5%', nextTier: 'Gold Affiliate', needed: 15 - count, progress: Math.round((count / 15) * 100), color: 'from-slate-400 to-slate-600' };
    return { name: 'Bronze Explorer', commission: '2.0%', nextTier: 'Silver Partner', needed: 5 - count, progress: Math.round((count / 5) * 100), color: 'from-orange-500 to-amber-600' };
  };

  const vipInfo = getVipTier(referralCount);

  // Copy Handlers
  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    addToast(`Referral code "${referralCode}" copied!`, 'success');
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    addToast('Referral invite link copied to clipboard!', 'success');
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleShareWhatsapp = () => {
    const text = encodeURIComponent(`Shop verified luxury goods and top electronics on Mega Marketplace with escrow protection! Sign up with my link and get ₦50,000 shopping balance + ₦1,000 instant discount: ${referralLink}`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handleShareTwitter = () => {
    const text = encodeURIComponent(`Join me on Mega Marketplace Nigeria! Buy and sell with 100% escrow protection: ${referralLink}`);
    window.open(`https://twitter.com/intent/tweet?text=${text}`, '_blank');
  };

  const handleBankCashoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(cashoutAmount);
    if (!amount || amount <= 0) {
      addToast('Please enter a valid cashout amount.', 'error');
      return;
    }

    const details: BankAccountDetails = {
      bank_name: bankName,
      account_number: accountNumber,
      account_name: accountName,
      is_verified: true
    };

    const res = requestDirectBankCashout(amount, details);
    if (res.success) {
      setShowCashoutModal(false);
      setCashoutAmount('');
    }
  };

  // Filtered Activities
  const filteredActivities = userActivities.filter(item => {
    if (filterType === 'referral') return item.type === 'referral_signup' || item.type === 'referral_order_commission';
    if (filterType === 'sales') return item.type === 'sales_payout';
    if (filterType === 'cashback') return item.type === 'cashback' || item.type === 'daily_streak' || item.type === 'vip_milestone';
    return true;
  });

  return (
    <div id="rewards-dashboard-widget" className="space-y-6">
      {/* TOP HERO BENTO GRID: REWARDS & SALES CALCULATOR WIDGET */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-6">
        
        {/* Main Combined Earnings Calculator Card (7 Cols on Desktop) */}
        <div className="lg:col-span-7 bg-gradient-to-br from-blue-900 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-xl border border-blue-800/40 flex flex-col justify-between">
          {/* Subtle Background Glow */}
          <div className="absolute -right-16 -top-16 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -left-16 -bottom-16 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="p-2 rounded-2xl bg-blue-500/20 border border-blue-400/30 text-blue-300">
                  <Gift className="w-5 h-5" />
                </span>
                <div>
                  <span className="text-xs font-bold text-blue-200 uppercase tracking-wider block">
                    Rewards & Sales Activity Calculator
                  </span>
                  <h3 className="text-sm font-semibold text-slate-300">
                    Total Cumulative Rewards Earned
                  </h3>
                </div>
              </div>

              <span className="px-3 py-1 rounded-full bg-blue-500/30 text-blue-200 border border-blue-400/30 text-xs font-bold flex items-center space-x-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                <span>Live Calculator</span>
              </span>
            </div>

            {/* Big Prominent Total Amount */}
            <div className="py-2">
              <div className="flex items-baseline space-x-2">
                <span className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white">
                  {formatCurrency(totalCumulativeRewards, currency)}
                </span>
                <span className="text-xs font-bold text-green-400 bg-green-500/20 px-2 py-0.5 rounded-lg border border-green-500/30">
                  +18.4% this week
                </span>
              </div>
              <p className="text-xs text-blue-200/80 mt-1">
                Calculated dynamically from your verified referral links, buyer orders, and merchant sales activity.
              </p>
            </div>

            {/* 3 Metric Pillars Breakdown */}
            <div className="grid grid-cols-3 gap-2 sm:gap-3 pt-3 border-t border-white/10">
              <div className="bg-white/5 backdrop-blur-xs p-3 rounded-2xl border border-white/10">
                <div className="flex items-center space-x-1 text-blue-300 text-[11px] font-bold">
                  <Users className="w-3.5 h-3.5" />
                  <span>Referrals</span>
                </div>
                <span className="text-base sm:text-lg font-black text-white block mt-1">
                  {formatCurrency(totalReferralRewards, currency)}
                </span>
                <span className="text-[10px] text-slate-400">{referralCount} Invites</span>
              </div>

              <div className="bg-white/5 backdrop-blur-xs p-3 rounded-2xl border border-white/10">
                <div className="flex items-center space-x-1 text-green-400 text-[11px] font-bold">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Sales Volume</span>
                </div>
                <span className="text-base sm:text-lg font-black text-white block mt-1">
                  {formatCurrency(totalSalesRewards, currency)}
                </span>
                <span className="text-[10px] text-slate-400">Escrow Payouts</span>
              </div>

              <div className="bg-white/5 backdrop-blur-xs p-3 rounded-2xl border border-white/10">
                <div className="flex items-center space-x-1 text-amber-400 text-[11px] font-bold">
                  <Percent className="w-3.5 h-3.5" />
                  <span>Cashback & VIP</span>
                </div>
                <span className="text-base sm:text-lg font-black text-white block mt-1">
                  {formatCurrency(cashbackTotal, currency)}
                </span>
                <span className="text-[10px] text-slate-400">Loyalty Drops</span>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="relative z-10 pt-6 mt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
            <div className="text-xs">
              <span className="text-slate-400 block text-[11px]">Unclaimed Ready Balance:</span>
              <span className="font-bold text-amber-400 text-sm sm:text-base">
                {formatCurrency(availableUnclaimed, currency)}
              </span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => claimAllRewards()}
                disabled={availableUnclaimed === 0}
                className={`px-4 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center space-x-1.5 shadow-md ${
                  availableUnclaimed > 0
                    ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 active:scale-95 shadow-amber-400/20'
                    : 'bg-white/10 text-white/50 cursor-not-allowed'
                }`}
              >
                <Zap className="w-4 h-4 text-amber-900 fill-amber-900" />
                <span>Claim All to Mega Wallet</span>
              </button>

              <button
                onClick={() => setShowCashoutModal(true)}
                className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-3.5 py-2.5 rounded-xl font-bold text-xs transition-colors flex items-center space-x-1.5"
              >
                <Building2 className="w-4 h-4" />
                <span>Bank Cashout</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Side: VIP Affiliate Tier & Daily Login Streak (5 Cols on Desktop) */}
        <div className="lg:col-span-5 space-y-4 flex flex-col justify-between">
          {/* VIP Affiliate Tier Card */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className={`w-10 h-10 rounded-2xl bg-gradient-to-tr ${vipInfo.color} text-white flex items-center justify-center font-black shadow-sm`}>
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-black text-slate-900 text-sm">{vipInfo.name}</h4>
                  <span className="text-[11px] text-blue-600 font-bold">Earn {vipInfo.commission} Direct Commission</span>
                </div>
              </div>

              <span className="text-xs font-mono font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-lg">
                {referralCount} Invites
              </span>
            </div>

            {/* Progress Bar to next Tier */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-[11px] font-bold text-slate-600">
                <span>Tier Progress</span>
                <span>{vipInfo.nextTier === 'Max Tier' ? 'Highest Tier' : `${vipInfo.needed} more invites to ${vipInfo.nextTier}`}</span>
              </div>
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className={`h-full bg-gradient-to-r ${vipInfo.color} transition-all duration-500 rounded-full`}
                  style={{ width: `${Math.min(vipInfo.progress, 100)}%` }}
                />
              </div>
            </div>

            <p className="text-[11px] text-slate-500">
              Every friend who registers with your link gives you ₦1,000 instant bonus plus a lifetime commission on all their purchases.
            </p>
          </div>

          {/* Daily Streak Check-in Widget */}
          <div className="bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10 border border-amber-200/80 rounded-3xl p-5 sm:p-6 shadow-xs flex items-center justify-between gap-4">
            <div className="flex items-center space-x-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 text-white flex items-center justify-center font-black shadow-md shadow-amber-500/30">
                <Flame className="w-6 h-6 animate-bounce" />
              </div>
              <div>
                <div className="flex items-center space-x-1.5">
                  <span className="font-black text-slate-900 text-sm">
                    {user.daily_streak || 1}-Day Active Streak!
                  </span>
                  <span className="bg-amber-200 text-amber-900 text-[10px] font-extrabold px-1.5 py-0.5 rounded-md">
                    +₦{(Math.min(1000 + ((user.daily_streak || 1) * 250), 5000)).toLocaleString()}
                  </span>
                </div>
                <p className="text-xs text-slate-600 mt-0.5">
                  Claim daily bonus points every 24 hours.
                </p>
              </div>
            </div>

            <button
              onClick={() => claimDailyStreakReward()}
              className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow-md shadow-amber-600/20 active:scale-95 transition-all whitespace-nowrap"
            >
              Claim Today ⚡
            </button>
          </div>
        </div>
      </div>

      {/* REFERRAL LINK SHARE & PROMOTION CENTER */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-black text-slate-900 flex items-center space-x-2">
              <Share2 className="w-5 h-5 text-blue-600" />
              <span>Your Personal Affiliate Referral Hub</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Share your referral link on social networks. When someone buys or lists an item, rewards are credited automatically.
            </p>
          </div>

          <button
            onClick={() => setShowQrModal(true)}
            className="self-start md:self-auto bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-3.5 py-2 rounded-xl flex items-center space-x-1.5 transition-colors"
          >
            <QrCode className="w-4 h-4 text-blue-600" />
            <span>Show QR Code</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Referral Code Box (4 cols) */}
          <div className="lg:col-span-4 bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col justify-between space-y-3">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Referral Invite Code
            </span>
            <div className="flex items-center justify-between bg-white px-3.5 py-2.5 rounded-xl border border-slate-200">
              <span className="text-lg font-mono font-black text-blue-600 tracking-wider">
                {referralCode}
              </span>
              <button
                onClick={handleCopyCode}
                className="p-1.5 text-slate-500 hover:text-blue-600 transition-colors"
                title="Copy Code"
              >
                {copiedCode ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
            <button
              onClick={handleCopyCode}
              className="w-full bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold py-2 rounded-xl text-xs transition-colors"
            >
              {copiedCode ? 'Code Copied!' : 'Copy Code'}
            </button>
          </div>

          {/* Direct Link & 1-Click Social Sharing (8 cols) */}
          <div className="lg:col-span-8 bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col justify-between space-y-3">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Full Referral Web Link
            </span>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                readOnly
                value={referralLink}
                className="flex-1 bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-mono font-semibold text-slate-700 select-all truncate"
              />
              <button
                onClick={handleCopyLink}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow-xs active:scale-95 transition-all flex items-center space-x-1 shrink-0"
              >
                {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedLink ? 'Copied' : 'Copy Link'}</span>
              </button>
            </div>

            {/* Social 1-Click Share Buttons */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-[11px] font-bold text-slate-500 mr-1">1-Click Share:</span>
              <button
                onClick={handleShareWhatsapp}
                className="bg-green-600 hover:bg-green-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl shadow-xs flex items-center space-x-1.5 transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp Share</span>
              </button>

              <button
                onClick={handleShareTwitter}
                className="bg-slate-900 hover:bg-black text-white text-xs font-bold px-3 py-1.5 rounded-xl shadow-xs flex items-center space-x-1.5 transition-colors"
              >
                <span>Twitter / X</span>
              </button>

              <button
                onClick={() => {
                  const text = encodeURIComponent(`Join Mega Marketplace Nigeria! Sign up with my link for ₦50,000 balance: ${referralLink}`);
                  window.open(`https://t.me/share/url?url=${referralLink}&text=${text}`, '_blank');
                }}
                className="bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold px-3 py-1.5 rounded-xl shadow-xs flex items-center space-x-1.5 transition-colors"
              >
                <span>Telegram</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ITEMIZED EARNINGS ACTIVITY & SETTLEMENT LEDGER */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="font-black text-slate-900 text-base">Rewards & Payout Activity Ledger</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Live record of all referral commissions, sales escrow releases, and loyalty drops.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold space-x-1">
            <button
              onClick={() => setFilterType('all')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterType === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              All ({userActivities.length})
            </button>
            <button
              onClick={() => setFilterType('referral')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterType === 'referral' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Referrals
            </button>
            <button
              onClick={() => setFilterType('sales')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterType === 'sales' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Sales Payouts
            </button>
            <button
              onClick={() => setFilterType('cashback')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterType === 'cashback' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Cashback & Streaks
            </button>
          </div>
        </div>

        {/* List of Activities */}
        <div className="divide-y divide-slate-100 text-xs">
          {filteredActivities.length === 0 ? (
            <div className="p-8 text-center text-slate-400">
              <Gift className="w-8 h-8 mx-auto mb-2 text-slate-300" />
              <p className="font-semibold">No reward records in this category yet.</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Share your link to generate instant commissions!</p>
            </div>
          ) : (
            filteredActivities.map((act) => (
              <div key={act.id} className="p-4 sm:p-5 flex items-center justify-between gap-4 hover:bg-slate-50/50 transition-colors">
                <div className="flex items-center space-x-3.5">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${
                    act.type.includes('referral')
                      ? 'bg-blue-50 text-blue-600'
                      : act.type === 'sales_payout'
                      ? 'bg-green-50 text-green-600'
                      : 'bg-amber-50 text-amber-600'
                  }`}>
                    {act.type.includes('referral') ? (
                      <Users className="w-5 h-5" />
                    ) : act.type === 'sales_payout' ? (
                      <TrendingUp className="w-5 h-5" />
                    ) : (
                      <Sparkles className="w-5 h-5" />
                    )}
                  </div>

                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-slate-900">{act.title}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                        act.status === 'claimed'
                          ? 'bg-slate-100 text-slate-600'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {act.status === 'claimed' ? 'Claimed in Wallet' : 'Available to Claim'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">{act.description}</p>
                    <span className="text-[10px] text-slate-400 mt-0.5 block">{act.date} • Ref: {act.reference || act.id}</span>
                  </div>
                </div>

                <div className="text-right flex flex-col items-end shrink-0 space-y-1.5">
                  <span className="font-mono font-bold text-base text-green-600">
                    +{formatCurrency(act.amount, currency)}
                  </span>

                  {act.status === 'available' ? (
                    <button
                      onClick={() => claimReward(act.id)}
                      className="bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold px-3 py-1 rounded-lg shadow-xs active:scale-95 transition-all"
                    >
                      Claim ₦
                    </button>
                  ) : (
                    <span className="text-[10px] text-slate-400 font-medium flex items-center space-x-1">
                      <CheckCircle2 className="w-3 h-3 text-green-600" />
                      <span>Credited</span>
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* DIRECT NUBAN BANK CASHOUT MODAL */}
      {showCashoutModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-base text-slate-900">Direct Bank Cashout</h3>
                  <span className="text-[10px] text-green-600 font-bold">Instant Nigerian NUBAN Settlement</span>
                </div>
              </div>
              <button
                onClick={() => setShowCashoutModal(false)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleBankCashoutSubmit} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Cashout Amount (NGN)</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400">₦</span>
                  <input
                    type="number"
                    required
                    min={1000}
                    value={cashoutAmount}
                    onChange={(e) => setCashoutAmount(e.target.value)}
                    placeholder="e.g. 50000"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-4 py-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none text-sm"
                  />
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Available in Wallet: {formatCurrency(user.wallet_balance || 0, currency)}
                </span>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Destination Bank</label>
                <select
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                >
                  <option value="Guaranty Trust Bank (GTBank)">Guaranty Trust Bank (GTBank)</option>
                  <option value="Zenith Bank Plc">Zenith Bank Plc</option>
                  <option value="Access Bank">Access Bank</option>
                  <option value="United Bank for Africa (UBA)">United Bank for Africa (UBA)</option>
                  <option value="First Bank of Nigeria">First Bank of Nigeria</option>
                  <option value="Kuda Microfinance Bank">Kuda Microfinance Bank</option>
                  <option value="PalmPay">PalmPay</option>
                  <option value="Moniepoint Microfinance Bank">Moniepoint MFB</option>
                  <option value="OPay Digital Services">OPay Digital Services</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">10-Digit Account Number</label>
                  <input
                    type="text"
                    required
                    maxLength={10}
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    placeholder="0123456789"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-mono font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Account Beneficiary Name</label>
                  <input
                    type="text"
                    required
                    value={accountName}
                    onChange={(e) => setAccountName(e.target.value)}
                    placeholder="e.g. Cyprian O."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl flex items-center space-x-2 text-[11px] text-blue-900">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Transfers are processed instantly via automated Nigerian interbank clearing (NIP).</span>
              </div>

              <div className="flex space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCashoutModal(false)}
                  className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-md"
                >
                  Confirm Payout
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QR CODE MODAL */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl border border-slate-200 text-center animate-in zoom-in-95">
            <h3 className="font-black text-base text-slate-900 mb-1">Your Referral QR Code</h3>
            <p className="text-xs text-slate-500 mb-4">Let friends scan this QR with their phone camera to register instantly.</p>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 inline-block mx-auto mb-4">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(referralLink)}`}
                alt="Referral QR Code"
                className="w-48 h-48 mx-auto rounded-xl"
              />
            </div>

            <span className="font-mono font-bold text-blue-600 text-sm block mb-4">
              {referralCode}
            </span>

            <button
              onClick={() => setShowQrModal(false)}
              className="w-full bg-slate-900 text-white font-bold py-2.5 rounded-xl text-xs"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
