import React, { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Activity, 
  ArrowUpRight, 
  Zap, 
  ShoppingCart, 
  Package, 
  Megaphone, 
  Users, 
  DollarSign, 
  ShieldCheck 
} from 'lucide-react';
import { useStore } from '../store';

interface BarDataPoint {
  day: string;
  label: string;
  orders: number;
  listings: number;
  ads: number;
  payouts: number;
  users: number;
  totalSignals: number;
}

export function ApplicationSignalsBarChart() {
  const { orders, products, videoAds, registeredUsers, adminRevenueNgn } = useStore();
  const [timeframe, setTimeframe] = useState<'24h' | '7d' | '30d'>('7d');
  const [activeMetric, setActiveMetric] = useState<'all' | 'orders' | 'listings' | 'ads' | 'payouts'>('all');
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  // Dynamic signal points representing application moves across days
  const signalData: BarDataPoint[] = [
    { day: 'Mon', label: 'Monday Signals', orders: 14, listings: 6, ads: 8, payouts: 12, users: 5, totalSignals: 45 },
    { day: 'Tue', label: 'Tuesday Signals', orders: 22, listings: 11, ads: 14, payouts: 18, users: 9, totalSignals: 74 },
    { day: 'Wed', label: 'Wednesday Signals', orders: 19, listings: 8, ads: 12, payouts: 15, users: 7, totalSignals: 61 },
    { day: 'Thu', label: 'Thursday Signals', orders: 31, listings: 14, ads: 20, payouts: 25, users: 12, totalSignals: 102 },
    { day: 'Fri', label: 'Friday Signals', orders: 45, listings: 19, ads: 28, payouts: 38, users: 18, totalSignals: 148 },
    { day: 'Sat', label: 'Saturday Signals', orders: 58, listings: 24, ads: 34, payouts: 42, users: 22, totalSignals: 180 },
    { day: 'Sun', label: 'Sunday Signals', orders: 38, listings: 15, ads: 22, payouts: 28, users: 14, totalSignals: 117 },
  ];

  const getMetricValue = (point: BarDataPoint) => {
    switch (activeMetric) {
      case 'orders': return point.orders;
      case 'listings': return point.listings;
      case 'ads': return point.ads;
      case 'payouts': return point.payouts;
      default: return point.totalSignals;
    }
  };

  const maxVal = Math.max(...signalData.map(getMetricValue), 1);

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
            <span className="text-[10px] font-black uppercase tracking-widest text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
              Live Application Pulse
            </span>
          </div>
          <h3 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight mt-1 flex items-center space-x-2">
            <Activity className="w-5 h-5 text-blue-600" />
            <span>Activity Signal Tracking Matrix</span>
          </h3>
          <p className="text-xs text-slate-500">
            Real-time bar chart signals monitoring all marketplace moves, payouts, listings & ad broadcasts.
          </p>
        </div>

        {/* Timeframe selector */}
        <div className="flex items-center space-x-1.5 bg-slate-100 p-1 rounded-2xl self-start sm:self-auto text-xs font-bold">
          <button
            onClick={() => setTimeframe('24h')}
            className={`px-3 py-1.5 rounded-xl transition ${timeframe === '24h' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'}`}
          >
            24H
          </button>
          <button
            onClick={() => setTimeframe('7d')}
            className={`px-3 py-1.5 rounded-xl transition ${timeframe === '7d' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'}`}
          >
            7 Days
          </button>
          <button
            onClick={() => setTimeframe('30d')}
            className={`px-3 py-1.5 rounded-xl transition ${timeframe === '30d' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'}`}
          >
            30 Days
          </button>
        </div>
      </div>

      {/* Signal Metric Filters */}
      <div className="flex flex-wrap items-center gap-2 pt-1">
        <button
          onClick={() => setActiveMetric('all')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 ${
            activeMetric === 'all'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>All Moves</span>
        </button>

        <button
          onClick={() => setActiveMetric('orders')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 ${
            activeMetric === 'orders'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          <span>Orders ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveMetric('listings')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 ${
            activeMetric === 'listings'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>Listings ({products.length})</span>
        </button>

        <button
          onClick={() => setActiveMetric('ads')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 ${
            activeMetric === 'ads'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <Megaphone className="w-3.5 h-3.5" />
          <span>Ads & Video Lab ({videoAds.length})</span>
        </button>

        <button
          onClick={() => setActiveMetric('payouts')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 ${
            activeMetric === 'payouts'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>₦50 Fee Payouts (₦{adminRevenueNgn.toLocaleString()})</span>
        </button>
      </div>

      {/* SVG & CSS Bar Chart Grid */}
      <div className="pt-4 pb-2">
        <div className="h-56 sm:h-64 flex items-end justify-between gap-3 sm:gap-6 border-b border-slate-200 px-2 sm:px-4 relative">
          {/* Subtle Grid Lines */}
          <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-20">
            <div className="border-b border-dashed border-slate-400 w-full" />
            <div className="border-b border-dashed border-slate-400 w-full" />
            <div className="border-b border-dashed border-slate-400 w-full" />
            <div className="border-b border-dashed border-slate-400 w-full" />
          </div>

          {signalData.map((point, idx) => {
            const val = getMetricValue(point);
            const heightPercent = Math.max(12, Math.round((val / maxVal) * 100));
            const isHovered = hoveredIndex === idx;

            return (
              <div
                key={point.day}
                onMouseEnter={() => setHoveredIndex(idx)}
                onMouseLeave={() => setHoveredIndex(null)}
                className="flex-1 flex flex-col items-center h-full justify-end relative group cursor-pointer z-10"
              >
                {/* Tooltip on hover */}
                {isHovered && (
                  <div className="absolute -top-14 bg-slate-900 text-white p-2.5 rounded-2xl text-[11px] shadow-xl whitespace-nowrap z-30 animate-in fade-in zoom-in-95">
                    <span className="font-black text-amber-400 block">{point.label}</span>
                    <span className="text-white font-mono font-bold">{val} application moves</span>
                    <div className="text-[9px] text-slate-400 flex items-center space-x-2 mt-0.5">
                      <span>Orders: {point.orders}</span>
                      <span>•</span>
                      <span>Payouts: {point.payouts}</span>
                    </div>
                  </div>
                )}

                {/* Animated Signal Bar */}
                <div className="w-full max-w-[42px] flex flex-col items-center justify-end h-full">
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className={`w-full rounded-2xl transition-all duration-300 relative overflow-hidden ${
                      isHovered
                        ? 'bg-gradient-to-t from-blue-700 to-indigo-500 shadow-lg shadow-blue-500/40 ring-2 ring-blue-400'
                        : 'bg-gradient-to-t from-blue-600 via-blue-500 to-sky-400'
                    }`}
                  >
                    {/* Signal top indicator cap */}
                    <div className="absolute top-0 inset-x-0 h-1.5 bg-white/60" />
                  </div>
                </div>

                {/* Day label */}
                <span className="text-xs font-black text-slate-600 mt-3 group-hover:text-blue-600 transition-colors">
                  {point.day}
                </span>
                <span className="text-[10px] font-mono text-slate-400 font-bold">
                  {val}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Metric Signal Badges Footer */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs">
        <div className="p-3 bg-blue-50/60 rounded-2xl border border-blue-100 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-blue-600 font-bold uppercase tracking-wider block">Total Signals</span>
            <span className="text-base font-black text-slate-900">727 Moves</span>
          </div>
          <Zap className="w-5 h-5 text-blue-500" />
        </div>

        <div className="p-3 bg-emerald-50/60 rounded-2xl border border-emerald-100 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider block">₦50 Fee Income</span>
            <span className="text-base font-black text-emerald-700">₦{adminRevenueNgn.toLocaleString()}</span>
          </div>
          <DollarSign className="w-5 h-5 text-emerald-500" />
        </div>

        <div className="p-3 bg-purple-50/60 rounded-2xl border border-purple-100 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-purple-600 font-bold uppercase tracking-wider block">Live Ads Active</span>
            <span className="text-base font-black text-purple-700">{videoAds.length} Campaigns</span>
          </div>
          <Megaphone className="w-5 h-5 text-purple-500" />
        </div>

        <div className="p-3 bg-amber-50/60 rounded-2xl border border-amber-100 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-amber-600 font-bold uppercase tracking-wider block">System Health</span>
            <span className="text-base font-black text-amber-700">99.98% Normal</span>
          </div>
          <ShieldCheck className="w-5 h-5 text-amber-500" />
        </div>
      </div>
    </div>
  );
}
