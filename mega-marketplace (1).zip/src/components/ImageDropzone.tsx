import React, { useState, useRef } from 'react';
import { UploadCloud, Image as ImageIcon, Check, X, Sparkles, RefreshCw } from 'lucide-react';
import { cn } from '../lib/utils';

interface ImageDropzoneProps {
  value?: string;
  onChange: (imageUrl: string) => void;
  label?: string;
  aspectRatio?: 'square' | 'video' | 'banner' | 'avatar';
  placeholderText?: string;
  helperText?: string;
  className?: string;
  showUrlInput?: boolean;
}

export function ImageDropzone({
  value,
  onChange,
  label,
  aspectRatio = 'square',
  placeholderText = 'Drag & drop image here or click to browse',
  helperText = 'Supports PNG, JPG, WEBP, GIF up to 10MB',
  className = '',
  showUrlInput = true
}: ImageDropzoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [urlInput, setUrlInput] = useState('');
  const [showUrlField, setShowUrlField] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload a valid image file (PNG, JPG, WEBP, GIF)');
      return;
    }

    setIsProcessing(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        onChange(result);
      }
      setIsProcessing(false);
    };
    reader.onerror = () => {
      setIsProcessing(false);
      alert('Failed to read image file.');
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      processFile(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      processFile(file);
    }
  };

  const handleApplyUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (urlInput.trim()) {
      onChange(urlInput.trim());
      setUrlInput('');
      setShowUrlField(false);
    }
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    onChange('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const ratioClass = {
    square: 'aspect-square min-h-[160px]',
    video: 'aspect-video min-h-[180px]',
    banner: 'aspect-[3/1] min-h-[140px]',
    avatar: 'w-24 h-24 sm:w-28 sm:h-28 rounded-full'
  }[aspectRatio];

  return (
    <div className={cn("space-y-2 w-full", className)}>
      {label && (
        <div className="flex items-center justify-between">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
            {label}
          </label>
          {showUrlInput && !value && (
            <button
              type="button"
              onClick={() => setShowUrlField(!showUrlField)}
              className="text-[11px] font-semibold text-blue-600 hover:text-blue-700"
            >
              {showUrlField ? 'Upload file instead' : 'Or paste URL'}
            </button>
          )}
        </div>
      )}

      {showUrlField && !value ? (
        <form onSubmit={handleApplyUrl} className="flex gap-2">
          <input
            type="url"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder="https://example.com/image.jpg"
            className="flex-1 text-xs border border-slate-300 rounded-xl px-3 py-2 focus:outline-none focus:border-blue-500"
          />
          <button
            type="submit"
            className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition-colors shrink-0"
          >
            Apply
          </button>
        </form>
      ) : (
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={cn(
            "relative group cursor-pointer border-2 border-dashed rounded-2xl transition-all duration-200 flex flex-col items-center justify-center p-4 text-center overflow-hidden",
            ratioClass,
            isDragging 
              ? "border-blue-500 bg-blue-50/80 scale-[1.01] shadow-md shadow-blue-500/10 ring-2 ring-blue-400" 
              : value 
                ? "border-slate-200 bg-slate-900/5 hover:border-blue-400" 
                : "border-slate-300 hover:border-blue-500 hover:bg-slate-50/80 bg-white"
          )}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />

          {isProcessing ? (
            <div className="flex flex-col items-center space-y-2 text-blue-600">
              <RefreshCw className="w-6 h-6 animate-spin" />
              <span className="text-xs font-bold">Uploading & Optimizing...</span>
            </div>
          ) : value ? (
            <>
              <img
                src={value}
                alt="Uploaded preview"
                className={cn(
                  "w-full h-full object-cover transition-transform group-hover:scale-105 duration-300",
                  aspectRatio === 'avatar' ? 'rounded-full' : 'rounded-xl'
                )}
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=300';
                }}
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 backdrop-blur-xs">
                <span className="text-white text-xs font-bold bg-blue-600/90 px-3 py-1.5 rounded-xl shadow-xs">
                  Change Image
                </span>
                <button
                  type="button"
                  onClick={handleClear}
                  className="text-white text-xs font-bold bg-rose-600/90 hover:bg-rose-700 p-1.5 rounded-xl transition-colors"
                  title="Remove image"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center space-y-2 pointer-events-none p-2">
              <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                <UploadCloud className="w-5 h-5" />
              </div>
              <p className="text-xs font-bold text-slate-700">
                {placeholderText}
              </p>
              <p className="text-[11px] text-slate-400">
                {helperText}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default ImageDropzone;
