import React, { useState } from 'react';
import { useStore } from '../store';
import { 
  Megaphone, 
  Play, 
  Pause, 
  ExternalLink, 
  Sparkles, 
  Eye, 
  ShieldCheck, 
  CheckCircle2 
} from 'lucide-react';
import { Link } from 'react-router-dom';

export function VideoAdsShowcase() {
  const { videoAds } = useStore();
  const [playingId, setPlayingId] = useState<string | null>(null);

  if (!videoAds || videoAds.length === 0) return null;

  return (
    <section className="py-8 max-w-7xl mx-auto space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-1">
        <div>
          <div className="flex items-center space-x-2">
            <span className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full flex items-center space-x-1 shadow-sm">
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>SPONSORED VIDEO LAB SHOWCASE</span>
            </span>
            <span className="text-slate-400 text-xs">• Verified Merchant Broadcasts</span>
          </div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight mt-1">
            Featured Brand & Merchant Commercials
          </h2>
        </div>

        <Link
          to="/sell"
          className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center space-x-1 self-start sm:self-auto"
        >
          <span>Promote Your Brand Here</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </Link>
      </div>

      {/* Video Commercials Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {videoAds.slice(0, 2).map((ad) => {
          const isPlaying = playingId === ad.id;

          return (
            <div
              key={ad.id}
              className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
            >
              {/* Video Player Box */}
              <div className="relative aspect-video bg-black overflow-hidden">
                <video
                  src={ad.video_url}
                  poster={ad.poster_url}
                  controls
                  loop
                  playsInline
                  className="w-full h-full object-cover"
                  onPlay={() => setPlayingId(ad.id)}
                  onPause={() => setPlayingId(null)}
                />

                <div className="absolute top-3 left-3 bg-slate-900/90 backdrop-blur-md text-white text-[10px] font-black uppercase px-2.5 py-1 rounded-full flex items-center space-x-1.5 border border-slate-700/60 shadow-lg pointer-events-none">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>{ad.creator_name}</span>
                </div>

                <div className="absolute top-3 right-3 bg-blue-600/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-full pointer-events-none shadow-sm flex items-center space-x-1">
                  <Eye className="w-3 h-3" />
                  <span>{ad.views_count ? `${ad.views_count.toLocaleString()} Views` : 'Sponsored'}</span>
                </div>
              </div>

              {/* Ad Content Details */}
              <div className="p-5 sm:p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div className="space-y-1.5">
                  <div className="flex items-center space-x-2 text-[11px] text-blue-600 font-bold uppercase tracking-wider">
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                    <span>Certified Escrow Protected Merchant</span>
                  </div>

                  <h3 className="text-base sm:text-lg font-black text-slate-900 leading-snug group-hover:text-blue-600 transition-colors">
                    {ad.title}
                  </h3>

                  <p className="text-xs text-slate-500 leading-relaxed line-clamp-2">
                    {ad.description}
                  </p>
                </div>

                {/* Target link button */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 font-medium">
                    Auto-scheduled daily broadcast
                  </span>

                  {ad.target_url?.startsWith('http') ? (
                    <a
                      href={ad.target_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-blue-600 hover:bg-blue-700 text-white font-black px-4 py-2.5 rounded-xl text-xs transition shadow-md shadow-blue-600/20 active:scale-95 inline-flex items-center space-x-1.5"
                    >
                      <span>Explore Merchant</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  ) : (
                    <Link
                      to={ad.target_url || '/explore'}
                      className="bg-blue-600 hover:bg-blue-700 text-white font-black px-4 py-2.5 rounded-xl text-xs transition shadow-md shadow-blue-600/20 active:scale-95 inline-flex items-center space-x-1.5"
                    >
                      <span>Explore Merchant</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </Link>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
