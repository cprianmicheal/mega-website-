import React from 'react';
import { User } from 'lucide-react';
import { cn } from '../lib/utils';

interface UserAvatarProps {
  src?: string | null;
  alt?: string;
  className?: string;
  iconClassName?: string;
}

export function UserAvatar({ src, alt, className, iconClassName }: UserAvatarProps) {
  if (src) {
    return (
      <img
        src={src}
        alt={alt || 'User'}
        className={cn("object-cover", className)}
      />
    );
  }

  return (
    <div className={cn("bg-slate-200 flex items-center justify-center rounded-full text-slate-500", className)}>
      <User className={cn("w-1/2 h-1/2", iconClassName)} />
    </div>
  );
}
