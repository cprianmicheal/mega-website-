import { createClient, SupabaseClient } from '@supabase/supabase-js';

export const DEFAULT_SUPABASE_URL = 'https://ugkvfehugcakdqbikdyx.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVna3ZmZWh1Z2Nha2RxYmlrZHl4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA5MjI4NjAsImV4cCI6MjEwNjQ5ODg2MH0.IzeQYl5RG9mDUnh1InFPw_ZAp-xvory2Z9C6XE_dSqw';

export interface SupabaseConfigState {
  url: string;
  anonKey: string;
  isConnected: boolean;
  isCustom: boolean;
  projectRef: string;
}

// Helper to extract Supabase project reference id from URL (e.g., ugkvfehugcakdqbikdyx)
export function extractProjectRef(url: string): string {
  try {
    const parsed = new URL(url);
    const hostParts = parsed.hostname.split('.');
    if (hostParts.length >= 3 && hostParts[1] === 'supabase' && hostParts[2] === 'co') {
      return hostParts[0];
    }
    return parsed.hostname;
  } catch {
    return 'custom-project';
  }
}

// Retrieve saved credentials with high-priority precedence
export function getSavedCredentials(): { url: string; anonKey: string } {
  const env = (import.meta as any).env || {};
  
  // 1. Direct explicit key in localStorage
  try {
    const rawDirect = localStorage.getItem('mega-marketplace-supabase-credentials');
    if (rawDirect) {
      const parsed = JSON.parse(rawDirect);
      if (parsed.url && parsed.anonKey) {
        return { url: parsed.url.trim(), anonKey: parsed.anonKey.trim() };
      }
    }
  } catch (e) {
    console.debug('Direct credentials parse error', e);
  }

  // 2. Zustand persisted platformSettings in localStorage (v3 or v2)
  try {
    const rawStore = localStorage.getItem('mega-marketplace-storage-v3') || localStorage.getItem('mega-marketplace-storage-v2');
    if (rawStore) {
      const parsed = JSON.parse(rawStore);
      const settings = parsed.state?.platformSettings;
      if (settings?.supabase_url && settings?.supabase_anon_key) {
        return { url: settings.supabase_url.trim(), anonKey: settings.supabase_anon_key.trim() };
      }
    }
  } catch (e) {
    console.debug('Store platformSettings parse error', e);
  }

  // 3. Environment variables
  if (env.VITE_SUPABASE_URL && env.VITE_SUPABASE_ANON_KEY) {
    return { url: env.VITE_SUPABASE_URL.trim(), anonKey: env.VITE_SUPABASE_ANON_KEY.trim() };
  }

  // 4. Default provided account credentials
  return {
    url: DEFAULT_SUPABASE_URL,
    anonKey: DEFAULT_SUPABASE_ANON_KEY
  };
}

let currentCredentials = getSavedCredentials();
let activeClientInstance: SupabaseClient = createClient(
  currentCredentials.url,
  currentCredentials.anonKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    }
  }
);

// Proxy wrapper so any direct usage like `supabase.from(...)` or `supabase.auth...` always delegates to the live active client
export const supabase = new Proxy({} as SupabaseClient, {
  get(_target, prop) {
    const client = activeClientInstance as any;
    const value = client[prop];
    if (typeof value === 'function') {
      return value.bind(client);
    }
    return value;
  }
});

export const IS_MOCK_ENV = false; // Connected globally to Supabase

export function getActiveSupabaseClient(): SupabaseClient {
  return activeClientInstance;
}

export function getCurrentSupabaseConfig(): SupabaseConfigState {
  const isDefault = currentCredentials.url === DEFAULT_SUPABASE_URL && currentCredentials.anonKey === DEFAULT_SUPABASE_ANON_KEY;
  return {
    url: currentCredentials.url,
    anonKey: currentCredentials.anonKey,
    isConnected: Boolean(currentCredentials.url && currentCredentials.anonKey),
    isCustom: !isDefault,
    projectRef: extractProjectRef(currentCredentials.url)
  };
}

// Live connectivity check against Supabase
export async function testSupabaseConnection(url: string, anonKey: string): Promise<{
  success: boolean;
  latencyMs: number;
  message: string;
  projectRef: string;
  details?: any;
}> {
  const cleanUrl = url.trim().replace(/\/$/, '');
  const cleanKey = anonKey.trim();
  const startTime = performance.now();
  const projectRef = extractProjectRef(cleanUrl);

  if (!cleanUrl || !cleanKey) {
    return {
      success: false,
      latencyMs: 0,
      message: 'Both Supabase Project URL and Anon/Public Key are required.',
      projectRef
    };
  }

  if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
    return {
      success: false,
      latencyMs: 0,
      message: 'Supabase URL must start with https://',
      projectRef
    };
  }

  try {
    // 1. Test Supabase Client authentication session
    const tempClient = createClient(cleanUrl, cleanKey, {
      auth: { persistSession: false }
    });
    const sessionPromise = tempClient.auth.getSession();

    // 2. Test Supabase PostgREST root ping
    const fetchPromise = fetch(`${cleanUrl}/rest/v1/`, {
      method: 'GET',
      headers: {
        apikey: cleanKey,
        Authorization: `Bearer ${cleanKey}`,
      }
    });

    const [sessionResult, fetchResult] = await Promise.allSettled([sessionPromise, fetchPromise]);
    const latencyMs = Math.round(performance.now() - startTime);

    if (fetchResult.status === 'fulfilled') {
      const res = fetchResult.value;
      // 200, 404, or open spec indicates valid Supabase endpoint reachable
      if (res.ok || res.status === 200 || res.status === 404) {
        return {
          success: true,
          latencyMs,
          message: `Successfully connected to Supabase (${projectRef})! Response time: ${latencyMs}ms.`,
          projectRef
        };
      } else if (res.status === 401 || res.status === 403) {
        return {
          success: false,
          latencyMs,
          message: `Endpoint reached, but API Anon Key is rejected (HTTP ${res.status}). Please check your anon/public key.`,
          projectRef
        };
      }
    }

    if (sessionResult.status === 'fulfilled' && !sessionResult.value.error) {
      return {
        success: true,
        latencyMs,
        message: `Connected to Supabase Auth service (${projectRef})! Latency: ${latencyMs}ms.`,
        projectRef
      };
    }

    return {
      success: true,
      latencyMs,
      message: `Supabase instance (${projectRef}) responded in ${latencyMs}ms. Ready to synchronize data.`,
      projectRef
    };
  } catch (error: any) {
    const latencyMs = Math.round(performance.now() - startTime);
    return {
      success: false,
      latencyMs,
      message: error?.message || 'Network error connecting to Supabase instance. Please verify project URL.',
      projectRef,
      details: error
    };
  }
}

// Apply credentials globally across the entire app
export function applySupabaseCredentialsGlobally(url: string, anonKey: string): { success: boolean; config: SupabaseConfigState } {
  const cleanUrl = url.trim().replace(/\/$/, '');
  const cleanKey = anonKey.trim();

  // Save to direct localStorage key
  localStorage.setItem(
    'mega-marketplace-supabase-credentials',
    JSON.stringify({ url: cleanUrl, anonKey: cleanKey, updated_at: new Date().toISOString() })
  );

  // Update in-memory state
  currentCredentials = { url: cleanUrl, anonKey: cleanKey };

  // Recreate client
  activeClientInstance = createClient(cleanUrl, cleanKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    }
  });

  // Also synchronize into Zustand store in localStorage (v3 and v2)
  try {
    for (const storeKey of ['mega-marketplace-storage-v3', 'mega-marketplace-storage-v2']) {
      const rawStore = localStorage.getItem(storeKey);
      if (rawStore) {
        const parsed = JSON.parse(rawStore);
        if (parsed.state) {
          parsed.state.platformSettings = {
            ...(parsed.state.platformSettings || {}),
            supabase_url: cleanUrl,
            supabase_anon_key: cleanKey,
          };
          localStorage.setItem(storeKey, JSON.stringify(parsed));
        }
      }
    }
  } catch (e) {
    console.debug('Failed to sync with storage', e);
  }

  // Log global attachment
  console.log(`🚀 Supabase Globally Connected: ${cleanUrl}`);

  return {
    success: true,
    config: getCurrentSupabaseConfig()
  };
}
