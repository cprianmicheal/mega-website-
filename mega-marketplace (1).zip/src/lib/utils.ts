import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { CurrencyCode, CurrencyConfig } from "../types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const CURRENCIES: Record<CurrencyCode, CurrencyConfig> = {
  NGN: {
    code: 'NGN',
    symbol: '₦',
    name: 'Nigerian Naira',
    rateAgainstNGN: 1.0,
    flag: '🇳🇬'
  },
  USD: {
    code: 'USD',
    symbol: '$',
    name: 'US Dollar',
    rateAgainstNGN: 0.00067, // ~1,500 NGN = $1
    flag: '🇺🇸'
  },
  GBP: {
    code: 'GBP',
    symbol: '£',
    name: 'British Pound',
    rateAgainstNGN: 0.00053, // ~1,900 NGN = £1
    flag: '🇬🇧'
  },
  EUR: {
    code: 'EUR',
    symbol: '€',
    name: 'Euro',
    rateAgainstNGN: 0.00061, // ~1,640 NGN = €1
    flag: '🇪🇺'
  },
  GHS: {
    code: 'GHS',
    symbol: '₵',
    name: 'Ghanaian Cedi',
    rateAgainstNGN: 0.010, // ~100 NGN = ₵1
    flag: '🇬🇭'
  },
  KES: {
    code: 'KES',
    symbol: 'KSh',
    name: 'Kenyan Shilling',
    rateAgainstNGN: 0.086,
    flag: '🇰🇪'
  },
  ZAR: {
    code: 'ZAR',
    symbol: 'R',
    name: 'South African Rand',
    rateAgainstNGN: 0.012,
    flag: '🇿🇦'
  },
  CAD: {
    code: 'CAD',
    symbol: 'CA$',
    name: 'Canadian Dollar',
    rateAgainstNGN: 0.00091,
    flag: '🇨🇦'
  },
  AED: {
    code: 'AED',
    symbol: 'AED',
    name: 'UAE Dirham',
    rateAgainstNGN: 0.00246,
    flag: '🇦🇪'
  },
  JPY: {
    code: 'JPY',
    symbol: '¥',
    name: 'Japanese Yen',
    rateAgainstNGN: 0.101,
    flag: '🇯🇵'
  },
  CNY: {
    code: 'CNY',
    symbol: 'CN¥',
    name: 'Chinese Yuan',
    rateAgainstNGN: 0.00485,
    flag: '🇨🇳'
  },
};

export function formatCurrency(amountInNGN: number, currencyCode: CurrencyCode = 'NGN'): string {
  const config = CURRENCIES[currencyCode] || CURRENCIES.NGN;
  const convertedAmount = amountInNGN * config.rateAgainstNGN;

  if (config.code === 'NGN') {
    return '₦' + Math.round(convertedAmount).toLocaleString('en-NG');
  }

  if (config.code === 'JPY') {
    return '¥' + Math.round(convertedAmount).toLocaleString('ja-JP');
  }

  // 2 decimal places for other international currencies
  return `${config.symbol}${convertedAmount.toLocaleString('en-US', {
    minimumFractionDigits: convertedAmount < 10 ? 2 : (convertedAmount < 1000 ? 2 : 0),
    maximumFractionDigits: 2,
  })}`;
}

export function calculatePlatformFee(priceInNGN: number, baseFee = 500, threshold = 100000, highPercent = 2.5): number {
  if (priceInNGN >= threshold) {
    return Math.max(baseFee, Math.round((priceInNGN * highPercent) / 100));
  }
  return baseFee;
}
