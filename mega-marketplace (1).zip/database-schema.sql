-- Mega Market Supabase Database Schema

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. PROFILES TABLE (Users, Sellers, Admins)
CREATE TABLE public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  role TEXT DEFAULT 'customer' CHECK (role IN ('customer', 'seller', 'admin')),
  avatar_url TEXT,
  paystack_subaccount_code TEXT, -- Added for Seller split payments
  wallet_balance DECIMAL(12,2) DEFAULT 0.0,
  referral_code TEXT UNIQUE,
  referred_by TEXT,
  referral_count INTEGER DEFAULT 0,
  referral_earnings DECIMAL(12,2) DEFAULT 0.0,
  sales_earnings DECIMAL(12,2) DEFAULT 0.0,
  cashback_earnings DECIMAL(12,2) DEFAULT 0.0,
  claimed_rewards DECIMAL(12,2) DEFAULT 0.0,
  daily_streak INTEGER DEFAULT 0,
  last_daily_claim TIMESTAMPTZ,
  business_name TEXT,
  business_address TEXT,
  bank_name TEXT,
  bank_account_number TEXT,
  bank_account_name TEXT,
  delivery_address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. STORES TABLE (Seller store profiles)
CREATE TABLE public.stores (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  logo_url TEXT,
  cover_url TEXT,
  is_verified BOOLEAN DEFAULT FALSE,
  rating DECIMAL(3,2) DEFAULT 0.0,
  reviews_count INTEGER DEFAULT 0,
  followers_count INTEGER DEFAULT 0,
  location TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('active', 'suspended', 'pending')),
  brand_color TEXT,
  featured_category TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. PRODUCTS TABLE
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE NOT NULL,
  category TEXT,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  price DECIMAL(12,2) NOT NULL,
  discount_price DECIMAL(12,2),
  stock INTEGER DEFAULT 0,
  images JSONB DEFAULT '[]'::JSONB,
  is_published BOOLEAN DEFAULT FALSE,
  is_featured BOOLEAN DEFAULT FALSE,
  is_flash_sale BOOLEAN DEFAULT FALSE,
  flash_sale_end TIMESTAMPTZ,
  rating DECIMAL(3,2) DEFAULT 0.0,
  reviews_count INTEGER DEFAULT 0,
  tags JSONB DEFAULT '[]'::JSONB,
  delivery_type TEXT DEFAULT 'nationwide',
  delivery_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. ORDERS TABLE
CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_number TEXT UNIQUE NOT NULL,
  customer_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  customer_name TEXT,
  customer_phone TEXT,
  customer_email TEXT,
  status TEXT DEFAULT 'pending_payment',
  subtotal DECIMAL(12,2),
  total_amount DECIMAL(12,2) NOT NULL,
  delivery_fee DECIMAL(12,2) DEFAULT 0.0,
  discount_amount DECIMAL(12,2) DEFAULT 0.0,
  coupon_code TEXT,
  platform_fee DECIMAL(12,2) DEFAULT 0.0,
  seller_payout_amount DECIMAL(12,2),
  shipping_address JSONB,
  delivery_instructions TEXT,
  payment_method TEXT,
  payment_status TEXT DEFAULT 'pending',
  tracking_number TEXT,
  courier_name TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. ORDER ITEMS (Linking orders to products)
CREATE TABLE public.order_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  quantity INTEGER NOT NULL,
  price_at_time DECIMAL(12,2) NOT NULL,
  selected_variant TEXT,
  buyer_instructions TEXT
);

-- 6. WALLET TRANSACTIONS
CREATE TABLE public.wallet_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  type TEXT CHECK (type IN ('credit', 'debit')),
  amount DECIMAL(12,2) NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  reference TEXT UNIQUE,
  status TEXT DEFAULT 'pending',
  date TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS (Row Level Security)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;

-- Setup Basic Policies (Customize based on exact permissions needed)
CREATE POLICY "Public profiles are viewable by everyone." ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users can insert their own profile." ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile." ON public.profiles FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Public stores are viewable by everyone." ON public.stores FOR SELECT USING (true);
CREATE POLICY "Public products are viewable by everyone." ON public.products FOR SELECT USING (is_published = true);
